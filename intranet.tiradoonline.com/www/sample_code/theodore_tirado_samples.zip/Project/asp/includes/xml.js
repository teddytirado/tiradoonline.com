function loadZipCodes() {
	// *************************
	// *  GRAB VARIABLES FROM XML CONFIGURATION FILE
	// *************************
	if (window.XMLHttpRequest) {// code for IE7 +, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	}
	else {// code for IEMAX_BOXES, IE5
		xmlhttp = new areacodeArraytiveXObject("Microsoft.XMLHTTP");
	}

	// *************************
	// *  OPEN XML FILE
	// *************************
		try {
			xmlhttp.open("GET", "/webservices/workorders.asp", false);
			xmlhttp.send();
			xmlDoc = xmlhttp.responseXML; 	
		}
		catch (e) {
			alert(e);
		}

		try {	
			tagname = "ZipCodes";
			var zipcode_xml = xmlDoc.getElementsByTagName(tagname);
		}
		catch (e) {
			alert(e)
			alert("Could not find <ZipCodes> element.");
		}
	
		//var progressBarWidthAdd	= 580 / zipcode_xml.length;
		//alert(progressBarWidthAdd + "  " + zipcode_xml.length);
		//$('#progressBar').width(0);
		for (x=0; x < zipcode_xml.length; x++) {
			try {
				zipcode = zipcode_xml[x].getElementsByTagName("ZipCode")[0].childNodes[0].nodeValue;
				city = zipcode_xml[x].getElementsByTagName("City")[0].childNodes[0].nodeValue;
				state = zipcode_xml[x].getElementsByTagName("State")[0].childNodes[0].nodeValue;
				county = zipcode_xml[x].getElementsByTagName("County")[0].childNodes[0].nodeValue;
				areacode = zipcode_xml[x].getElementsByTagName("A_C")[0].childNodes[0].nodeValue;
				fips = zipcode_xml[x].getElementsByTagName("FIPS")[0].childNodes[0].nodeValue;
				timezone = zipcode_xml[x].getElementsByTagName("T_Z")[0].childNodes[0].nodeValue;
				dst = zipcode_xml[x].getElementsByTagName("DST")[0].childNodes[0].nodeValue;
				lat = zipcode_xml[x].getElementsByTagName("Lat")[0].childNodes[0].nodeValue;
				vlong = zipcode_xml[x].getElementsByTagName("vLong")[0].childNodes[0].nodeValue;
				vtype = zipcode_xml[x].getElementsByTagName("vType")[0].childNodes[0].nodeValue;

				zipcodeArray[x] = zipcode;
				cityArray[x] = city;
				stateArray[x] = state;
				countyArray[x] = county;
				areacodeArray[x] = areacode;
				fipsArray[x] = fips;
				timezoneArray[x] = timezone;
				dstArray[x] = dst;
				latArray[x] = lat;
				vlongArray[x] = vlong;
				vtypeArray[x] = vtype;
				//$('#progressBar').width(($('#progressBar').width() + progressBarWidthAdd));
	
			}
			catch (e) {
				//alert(x);
				alert(e);
				//alert("Could not find <zipcode> element.");
				//return false;
			}
			
		}
	xmlLoaded = true;
	
	$('#divLoading').fadeOut(2000);
	setTimeout("$('#divZipCode').fadeIn(2000);", 3000);

}
