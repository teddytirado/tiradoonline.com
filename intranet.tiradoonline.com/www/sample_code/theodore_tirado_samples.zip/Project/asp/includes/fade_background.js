<script language="Javascript">
<!--
// please keep these lines on when you copy the source
// made by: Nicolas - http://www.javascript-page.com

var speed = 255

function StringArray (n) {
  this.length = n;
  for (var i =1; i <= n; i++) {
    this[i] = ' '
  }
}

fader = new StringArray(16)

for(var i = 0; i < 10; i++) {
  fader[i] = i
}
fader[10] = "a"
fader[11] = "b"
fader[12] = "c"
fader[13] = "d"
fader[14] = "e"
fader[15] = "f"

function hexadecimal(i) {
    return ("" + fader[Math.floor(i/16)] + fader[i%16])
}
function fade(r2,g2,b2,r1,g1,b1) {
  for(var i = 0; i <= speed; i++) {
var r = hexadecimal(Math.floor(r2 * ((speed-i)/speed) + r1 * (i/speed)))
var g = hexadecimal(Math.floor(g2 * ((speed-i)/speed) + g1 * (i/speed)))
var b = hexadecimal(Math.floor(b2 * ((speed-i)/speed) + b1 * (i/speed)))
document.bgColor = "#" + r + g + b
  }
}

fade(0,0,0,255,255,255);
fade(255,255,255,255,0,0);
fade(255,0,0,0,0,255);
fade(0,0,255,255,255,255);
//-->
</script>
