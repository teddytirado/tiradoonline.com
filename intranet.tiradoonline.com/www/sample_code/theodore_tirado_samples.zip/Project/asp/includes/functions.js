<script language="JavaScript">
<!--
	function RoundNumber(num, dec)
	{
		var result = Math.round(num * Math.pow(10, dec)) / Math.pow(10, dec);
		return result;
	}
	
	function Calculate()
	{
		var TotalAmountForParts = document.getElementById("TotalAmountForParts").innerHTML;
		TotalAmountForParts = TotalAmountForParts.replace(",", "");
		TotalAmountForParts = parseFloat(TotalAmountForParts);
		if(isNaN(TotalAmountForParts)) {
			alert("Not a valid number.");
			return false;
		}

		var LaborHours = document.getElementById("LaborHours").value;
		LaborHours = LaborHours.replace(",", "");
		LaborHours = parseFloat(LaborHours);
		if(isNaN(LaborHours)) {
			alert("Not a valid number.");
			return false;
		}

		var LaborRate = document.getElementById("LaborRate").value;
		LaborRate = LaborRate.replace(",", "");
		LaborRate = parseFloat(LaborRate);
		if(isNaN(LaborRate)) {
			alert("Not a valid number.");
			return false;
		}

		var TravelHours = document.getElementById("TravelHours").value;
		TravelHours = TravelHours.replace(",", "");
		TravelHours = parseFloat(TravelHours);
		if(isNaN(TravelHours)) {
		alert("Not a valid number.");
			return false;
		}

		var TravelRate = document.getElementById("TravelRate").value;
		TravelRate = TravelRate.replace(",", "");
		TravelRate = parseFloat(TravelRate);
		if(isNaN(TravelRate)) {
			alert("Not a valid number.");
			return false;
		}

		var MiscCharges = document.getElementById("MiscCharges").value;
		MiscCharges = MiscCharges.replace(",", "");
		MiscCharges = parseFloat(MiscCharges);
		if(isNaN(MiscCharges)) {
			alert("Not a valid number.");
			return false;
		}

		var Shipping = document.getElementById("Shipping").value;
		Shipping = Shipping.replace(",", "");
		Shipping = parseFloat(Shipping);
		if(isNaN(Shipping)) {
			alert("Not a valid number.");
			return false;
		}
		
		var SalesTax = document.getElementById("SalesTax").value;
		SalesTax = SalesTax.replace(",", "");
		SalesTax = parseFloat(SalesTax);
		
		var Total = (TotalAmountForParts + (LaborRate * LaborHours) + (TravelRate * TravelHours) + MiscCharges + Shipping);
		var TotalAmount = (TotalAmountForParts + (LaborRate * LaborHours) + (TravelRate * TravelHours) + MiscCharges + Shipping) * SalesTax;
		//TotalAmount = parseFloat(Total + TotalAmount).toString();
		TotalAmount = parseFloat(Total + TotalAmount).toString();
		TotalAmount = RoundNumber(TotalAmount, 2)
		//alert (TotalAmount.charAt("."));
		if(document.getElementById("TotalAmount").value != null)
			document.getElementById("TotalAmount").value = TotalAmount;
		else
			document.getElementById("TotalAmount").value = "0.00";
	}
	
	function SearchServiceReport()
	{
		//alert(document.forms[0].SearchServiceReportNumber.value);
		var v_SearchServiceReportNumber = document.forms[0].SearchServiceReportNumber.value
		//alert(v_SearchServiceReportNumber)
		locationURL = '/service/service_report_search.asp?SubmitButton=<%= Server.URLEncode("Search by Service Report Number") %>&ServiceReportNumber=' + v_SearchServiceReportNumber;
		location.href = locationURL;
	}
	
	function ValidateCreditMemo(thisForm)
	{
	
		//alert(isDate('7/7'));
	
		//alert(thisForm.ServiceReportNumber.CompanyType.value);
		
		//CompanyChecked = "old"
		//if (thisForm.CompanyType[1].checked == true)
		//	CompanyChecked = "new"
		
		//alert(CompanyChecked);

		FormValidated = true;
		if(thisForm.CreditMemoNumber.value == '')
		{
			alert("Invalid Credit Memo Number");
			thisForm.CreditMemoNumber.focus()
			FormValidated = false;
		}
		else if(thisForm.CreditMemoDate.value == '')
		{
			alert("Invalid Credit Memo Date");
			thisForm.CreditMemoDate.focus()
			FormValidated = false;
		}
		//else if(thisForm.ServiceReportNumber.value == '')
		//{
		//	alert("Invalid Service Report Number");
		//	thisForm.ServiceReportNumber.focus()
		//	FormValidated = false;
		//}
		//else if(thisForm.ServiceDate.value == '')
		//{
		//	alert("Invalid Date Service Requested Date");
		//	thisForm.ServiceDate.focus()
		//	FormValidated = false;
		//}

		return FormValidated;
		
	}

	function ValidateServiceReport(thisForm)
	{
	
		//alert(isDate('7/7'));
	
		//alert(thisForm.ServiceReportNumber.CompanyType.value);
		
		//CompanyChecked = "old"
		//if (thisForm.CompanyType[1].checked == true)
		//	CompanyChecked = "new"
		
		//alert(CompanyChecked);

		if(thisForm.ServiceReportNumber.value == '')
		{
			alert("Invalid Service Report Number");
			thisForm.ServiceReportNumber.focus()
			return false;
		}
		
		/*
		if(thisForm.CompanyType[1].checked == true)
		{
			if(thisForm.CompanyName.value == '')
			{
				alert("Invalid Company Name");
				thisForm.CompanyName.focus()
				return false;
			}
			else if(thisForm.CompanyAddress.value == '')
			{
				alert("Invalid Company Address");
				thisForm.CompanyAddress.focus()
				return false;
			}
			else if(thisForm.CompanyCity.value == '')
			{
				alert("Invalid Company City");
				thisForm.CompanyCity.focus()
				return false;
			}
			else if(thisForm.CompanyZipCode.value == '')
			{
				alert("Invalid Company Zip Code");
				thisForm.CompanyZipCode.focus()
				return false;
			}
		}
		
		if(thisForm.Contact.value == '')
		{
			alert("Invalid Contact");
			thisForm.Contact.focus()
			return false;
		}
		<% If ServiceReportNumber = "" Then %>
		else if(thisForm.Phone.value == '')
		{
			alert("Invalid Phone");
			thisForm.Phone.focus()
			return false;
		}
		<% End If %>
		if(thisForm.RepairDate.value != '')
		{
			if(!isDate(thisForm.RepairDate.value))
			{
				alert("Invalid Repair Date");
				thisForm.RepairDate.focus()
				return false;
			}
		}
		*/
		if(thisForm.ServiceDate.value == '' || !isDate(thisForm.ServiceDate.value))
		{
			alert("Invalid Date Service Requested Date");
			thisForm.ServiceDate.focus()
			return false;
		}
		
		if(thisForm.ModelNumber.value != '')
		{
			if(thisForm.SerialNumber.value == '')
			{
				alert("Invalid Serial Number");
				thisForm.SerialNumber.focus()
				return false;
			}
		}

		if(thisForm.SerialNumber.value != '')
		{
			if(thisForm.ModelNumber.value == '')
			{
				alert("Invalid Model Number Number");
				thisForm.ModelNumber.focus()
				return false;
			}
		}
		//else if(thisForm.ServiceTime.value == '')
		//{
		//	alert("Invalid Date Service Requested Time");
		//	thisForm.ServiceTime.focus()
		//	return false;
		//}
		//else if(thisForm.PONumber.value == '')
		//{
		//	alert("Invalid PO Number");
		//	thisForm.PONumber.focus()
		//	return false;
		//}
		//else if(thisForm.WONumber.value == '')
		//{
		//	alert("Invalid Work Order#");
		//	thisForm.WONumber.focus()
		//	return false;
		//}

		return true;
		
	}
	
	function disableEnterButton(e)
	{
		//alert("Enter key disabled");
     	var key;     
     	if(window.event)
          	key = window.event.keyCode; //IE
     	else
          	key = e.which; //firefox     

     	return (key != 13);
	}

	function _roundNumber(num,dec) {
		var snum=num.toString()+"000000000000000001";
		var sep=snum.indexOf(".");
		var beg=snum.substring(0,snum.indexOf("."));
		snum=snum.substring(eval(snum.indexOf(".")+1),snum.length);
		var dig=snum.substring(0,eval(dec-1));
		snum=snum.substring(eval(dec-1),dec);
		snum=parseInt(snum);
		gohigher=false;
		if (snum>4) {gohigher=true;}
		if (gohigher) {snum=parseInt(snum);snum++;}
		snum=snum.toString();
		//alert(beg+"."+dig+""+snum);
		num=beg+"."+dig+""+snum;
		return num;
	}

	function MarkupPrice(LineNum)
	{
		Cost = document.getElementById("Cost_" + LineNum).value;
		Cost = Cost.replace(",", "");
		Cost = parseFloat(Cost);
		Markup = document.getElementById("Markup_" + LineNum).value;
		if(isNaN(Markup)) {
			alert("Not a valid number.");
			document.getElementById("Markup_" + LineNum).value = '';
			//document.getElementById("Markup_" + LineNum).focus();
		}
		else 
		{
			if(Markup < 10)
			{
				Markup = parseFloat("1.0" + Markup);
			}
			else			
				Markup = parseFloat("1." + Markup);
			//SellingPrice = parseFloat((Cost * Markup) + Cost);
			SellingPrice = parseFloat(Cost * Markup);
			document.getElementById("Price_" + LineNum).value = _roundNumber(SellingPrice, 2);
		}
	}

	function openAddress(SalesPerson, Customer)
	{
		addressURL = "\/eWorkOrder/shipping_address_book.asp?SalesPersonID=" + SalesPerson + "&CustomerID=" + Customer;
			window.open(addressURL,'AddressWindow', 'width=<%= Application("WindowWidth") %>,height=<%= Application("WindowHeight") %>,toolbar=no,directories=no,status=no, menubar=no,scrollbars=yes, resizable=no,modal=yes');
	}
	
	/*
	function openAddress(SalesPerson, Customer)
	{
		addressURL = "\/eWorkOrder/shipping_address_book.asp?SalesPersonID=" + SalesPerson + "&CustomerID=" + Customer;
		if (window.showModalDialog) {
			window.showModalDialog(addressURL,"new_win","dialogWidth:<%= Application("WindowWidth") %>px;dialogHeight:<%= Application("WindowhHeight") %>px");
		} else {
			window.open(addressURL,'new_win','height=<%= Application("WindowWidth") %>,width=<%= Application("WindowHeight") %>,toolbar=no,directories=no,status=no,linemenubar=no,scrollars=no,resizable=no ,modal=yes');
		}
	}		
		*/

	function openModal(v_url, v_width, v_height)
	{
		if (window.showModalDialog) 
			window.showModalDialog(v_url,"ServiceReportWindow","dialogWidth:" + v_width + "px;dialogHeight:" + v_height + "px;center:yes;location:no;resizable:no;scroll:no;status:no;toolbar:left:100;top:100");
		else
			window.open(v_url,'ServiceReportWindow','width=' + v_width + ',height=' + v_height + ',location=no,toolbar=no,directories=no,status=no,menubar=yes,scrollbars=no,resizable=no,modal=yes,left=100,top=100');
	}
	
	function openPDF(URL)
	{
		if (window.showModalDialog) 
		{
			window.showModalDialog(URL,"name","dialogWidth:900px;dialogHeight:800px;toolbar:yes");
		}
		else
		{
			window.open(URL,'name','height=900,width=800,toolbar=no,directories=no,status=no,menubar=yes,scrollbars=no,resizable=no ,modal=yes');
		}
				//window.open(URL,'PDF', 'width=900,height=800,toolbar=no,directories=no,status=no, menubar=yes,scrollbars=yes, resizable=no,modal=yes');
	}
	
	function openWindow(URL, winWidth, winHeight)
	{
		window.open(URL,'Invoice','height=' + winHeight + ',width=' + winWidth + ',toolbar=no,directories=no,status=no,menubar=yes,scrollbars=yes,resizable=no ,modal=yes');
	}
	
	function openInvoice(Invoice_Number)
	{
		window.open('/accpac/invoice.asp?InvoiceNumber=' + Invoice_Number,'Invoice','height=700,width=800,toolbar=no,directories=no,status=no,menubar=yes,scrollbars=yes,resizable=no ,modal=yes');
	}

	function UseBillingInformation(BillingCustomerName, BillingAddress1, BillingAddress2, BillingAddress3, BillingAddress4, BillingCity, BillingState, BillingZipCode)
	{
		try 
		{
			shipping = document.forms[0];
			shipping.ShippingCustomerName.value = BillingCustomerName;
			shipping.ShippingAddress1.value = BillingAddress1;
			shipping.ShippingAddress2.value = BillingAddress2;
			shipping.ShippingAddress3.value = BillingAddress3;
			shipping.ShippingAddress4.value = BillingAddress4;
			shipping.ShippingCity.value = BillingCity;
			
			var ShippingFound = false;
			for (x = 0; x < shipping.ShippingState.length; x++)
			{
			
				if(shipping.ShippingState.options[x].value == BillingState)
				{
					shipping.ShippingState.selectedIndex = x;
					ShippingFound = true;
				}
			}

			if(!ShippingFound)
				shipping.ShippingState.selectedIndex = 0;
				
			shipping.ShippingZipCode.value = BillingZipCode;
		}
		catch (err)
		{
			alert(err.description);
		}
	}
	
	function DeleteItem(confirm_string, location_url)
	{
		try { 
			if(confirm(confirm_string))
				location.href = location_url;
		}
		catch(err)
		{ 
			alert(err.description);
		}
	}
		
	function DeleteServiceReport(confirm_string, location_url)
	{
		if(confirm(confirm_string))
			CloseServiceReport();
	}

	function CloseServiceReport()
	{
		var InvoiceNumber = prompt('Please enter Invoice Number', '');
		if(InvoiceNumber != '' && InvoiceNumber != null)
		{
			document.forms[0].InvoiceNumber.value = InvoiceNumber;
			url_string = '<%= SCRIPT_NAME %>?SubmitButton=Close&ServiceReportNumber=<%= ServiceReportNumber %>&InvoiceNumber=' + InvoiceNumber;
			location.href = url_string;
		}
		else
		{
			//alert(InvoiceNumber);
			if(InvoiceNumber == '')
				CloseServiceReport();
		}
	}

	function DeletePreQuoteItem(location_url)
	{
		try { 
			if(confirm('Are you sure you want to delete this item?'))
				location.href = location_url;
		}
		catch(err)
		{ 
			alert(err.description);
		}
	}

	function IsNumeric(sText)
	{
   		var ValidChars = "0123456789.,";
   		var IsNumber=true;
   		var Char;
 
   		for (i = 0; i < sText.length && IsNumber == true; i++) 
      	{ 
      		Char = sText.charAt(i); 
      		if (ValidChars.indexOf(Char) == -1) 
         	{
         		IsNumber = false;
         	}
      	}
   		return IsNumber;
   }

	function SubmitQuote(thisForm)
	{
		//alert(thisForm.SubmitButton.value);
		if(thisForm.CheckboxPreQuoteName.checked)
		{		
			if(thisForm.PreQuoteName.value == "")
			{
				alert("Please enter name of new Quote Template");
				thisForm.PreQuoteName.focus();
				return false;
			}
		}
		else if(thisForm.Attention.value == "")
		{
			alert("Please enter an Attention");
			thisForm.Attention.focus();
			return false;
		}
		else
			return true;
	}

	function SubmitForm(vSubmitButton)
	{
		document.forms[0].SubmitButton.value = vSubmitButton;
		
		//document.forms[0].submit();
	}
	
	function CreateQuote(thisForm)
	{
		alert(thisForm.SubmitButton.selectedIndex);
		if(thisForm.SubmitButton.value == "Finalize Quote")
		{
			if(thisForm.ShippingCustomerName.value == "")
			{
				alert("Please enter Shipping Customer Name.");
				thisForm.ShippingCustomerName.focus();
				return false;
			}
			else if(thisForm.ShippingAddress1.value == "")
			{
				alert("Please enter a Shipping Address.");
				thisForm.ShippingAddress1.focus();
				return false;
			}
			else if(thisForm.ShippingCity.value == "")
			{
				alert("Please enter Shipping City.");
				thisForm.ShippingCity.focus();
				return false;
			}
			else if(thisForm.ShippingState.value == "")
			{
				alert("Please enter Shipping State");
				thisForm.ShippingState.focus();
				return false;
			}
			else if(thisForm.ShippingZipCode.value == "")
			{
				alert("Please enter Shipping Zip Code");
				thisForm.ShippingZipCode.focus();
				return false;
			}
			else
				return true;
		}
	}

//NEWS FADE SCRIPT	
var list; // global list variable cache
var tickerObj; // global tickerObj cache
var hex = 255;

function fadeText(divId) {
  if(tickerObj)
  {
    if(hex>0) {
      hex-=5; // increase color darkness
      tickerObj.style.color="rgb("+hex+","+hex+","+hex+")";
      setTimeout("fadeText('" + divId + "')", fadeSpeed); 
    } else
      hex=255; //reset hex value
  }
}

function initialiseList(divId) {
  tickerObj = document.getElementById(divId);
  if(!tickerObj)
    reportError("Could not find a div element with id \"" + divId + "\"");
  list = tickerObj.childNodes;
  if(list.length <= 0)
    reportError("The div element \"" + divId + "\" does not have any children");
  for (var i=0; i<list.length; i++) {
    var node = list[i];
    if (node.nodeType == 3 && !/\S/.test(node.nodeValue)) 
              tickerObj.removeChild(node);
  }
  run(divId, 0);
}

function run(divId, count) {
  fadeText(divId);
  list[count].style.display = "block";
  if(count > 0)
    list[count-1].style.display = "none";
  else
    list[list.length-1].style.display = "none";
  count++;
  if(count == list.length)
    count = 0;
  window.setTimeout("run('" + divId + "', " + count+ ")", interval*1000);
}
function reportError(error) {
  alert("The script could not run because you have errors:\n\n" + error);
  return false;
}

var interval = 7; // interval in seconds
var fadeSpeed = 40; // fade speed, the lower the speed the faster the fade.  40 is normal.


/*
function isDate(dateStr) 
{

	var datePat = /^(\d{1,2})(\/|-)(\d{1,2})(\/|-)(\d{2})$/;
	var matchArray = dateStr.match(datePat); // is the format ok?

	if (matchArray == null) {
		return false;
	}

	month = matchArray[1]; // p@rse date into variables
	day = matchArray[3];
	year = matchArray[5];

	if (month < 1 || month > 12) { // check month range
		return false;
	}

	if (day < 1 || day > 31) {
		return false;
	}

	if ((month==4 || month==6 || month==9 || month==11) && day==31) {
		return false;
	}

	if (month == 2) { // check for february 29th
		var isleap = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
		if (day > 29 || (day==29 && !isleap)) {
			alert("February " + year + " doesn`t have " + day + " days!");
			return false;
		}
	}
	return true; // date is valid
}
*/

var dtCh= "/";
var minYear=1900;
var maxYear=2100;

function isInteger(s){
	var i;
    for (i = 0; i < s.length; i++){   
        // Check that current character is number.
        var c = s.charAt(i);
        if (((c < "0") || (c > "9"))) return false;
    }
    // All characters are numbers.
    return true;
}

function stripCharsInBag(s, bag){
	var i;
    var returnString = "";
    // Search through string's characters one by one.
    // If character is not in bag, append to returnString.
    for (i = 0; i < s.length; i++){   
        var c = s.charAt(i);
        if (bag.indexOf(c) == -1) returnString += c;
    }
    return returnString;
}

function daysInFebruary (year){
	// February has 29 days in any year evenly divisible by four,
    // EXCEPT for centurial years which are not also divisible by 400.
    return (((year % 4 == 0) && ( (!(year % 100 == 0)) || (year % 400 == 0))) ? 29 : 28 );
}
function DaysArray(n) {
	for (var i = 1; i <= n; i++) {
		this[i] = 31
		if (i==4 || i==6 || i==9 || i==11) {this[i] = 30}
		if (i==2) {this[i] = 29}
   } 
   return this
}

function isDate(dtStr){
	var daysInMonth = DaysArray(12)
	var pos1=dtStr.indexOf(dtCh)
	var pos2=dtStr.indexOf(dtCh,pos1+1)
	var strMonth=dtStr.substring(0,pos1)
	var strDay=dtStr.substring(pos1+1,pos2)
	var strYear=dtStr.substring(pos2+1)
	strYr=strYear
	if (strDay.charAt(0)=="0" && strDay.length>1) strDay=strDay.substring(1)
	if (strMonth.charAt(0)=="0" && strMonth.length>1) strMonth=strMonth.substring(1)
	for (var i = 1; i <= 3; i++) {
		if (strYr.charAt(0)=="0" && strYr.length>1) strYr=strYr.substring(1)
	}
	month=parseInt(strMonth)
	day=parseInt(strDay)
	year=parseInt(strYr)
	if (pos1==-1 || pos2==-1){
		//alert("The date format should be : mm/dd/yyyy")
		return false
	}
	if (strMonth.length<1 || month<1 || month>12){
		//alert("Please enter a valid month")
		return false
	}
	if (strDay.length<1 || day<1 || day>31 || (month==2 && day>daysInFebruary(year)) || day > daysInMonth[month]){
		//alert("Please enter a valid day")
		return false
	}
	if (strYear.length != 4 || year==0 || year<minYear || year>maxYear){
		//alert("Please enter a valid 4 digit year between "+minYear+" and "+maxYear)
		return false
	}
	if (dtStr.indexOf(dtCh,pos2+1)!=-1 || isInteger(stripCharsInBag(dtStr, dtCh))==false){
		//alert("Please enter a valid date")
		return false
	}
	return true
}

//-->
</script>


	
