ALTER PROCEDURE sp_Balance_BalanceAccountID
	@BalanceAccountID		INT
AS

	SELECT
		a.BalanceID, 
		a.BalanceDate, 
		a.BankDate,
		a.Payment, 
		a.Comment, 
		b.Description
	FROM 
		Balance a, Transactions b
	WHERE
		a.TransactionID = b.TransactionID AND
		a.BalanceAccountID = @BalanceAccountID
	ORDER BY
		a.BalanceDate;
GO

EXEC sp_Balance_BalanceAccountID 1024