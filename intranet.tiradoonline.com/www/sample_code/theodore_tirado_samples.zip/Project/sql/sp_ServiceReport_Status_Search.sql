IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_ServiceReport_Status_Search' AND TYPE = 'P')
	DROP PROCEDURE sp_ServiceReport_Status_Search;
GO


CREATE PROCEDURE sp_ServiceReport_Status_Search
	@Status			BIT,
	@StartDate 		DATETIME,
	@EndDate 		DATETIME
AS

	SET NOCOUNT ON;

	/***********************************/
	/* SEARCH BY SERVICE REPORT NUMBER */
	/***********************************/

	SELECT 
		LastRepairDate = (SELECT MAX(b.RepairDate) FROM DateServicePerformed b 
				WHERE 
					b.ServiceReportNumber = ServiceReport.ServiceReportNumber AND 
				RepairDate BETWEEN @StartDate AND @EndDate),
		*,
		Customer = (SELECT CompanyName FROM Companies WHERE CompanyID = ServiceReport.CompanyID),
		close_by = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = ServiceReport.close_by),
		update_by = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = ServiceReport.update_by),
		create_by = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = ServiceReport.create_by)
	FROM 
		ServiceReport
	WHERE 
		CompanyID IS NOT NULL AND
		--RepairDate BETWEEN @StartDate AND @EndDate AND 
		Status = @Status
	ORDER BY
		ServiceReportNumber DESC;
		--ServiceReportNumber = @ServiceReportNumber;



GO

sp_ServiceReport_Status_Search 1, '1/1/10', '8/23/2010'