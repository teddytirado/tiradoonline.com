ALTER PROCEDURE sp_Balance_get_sum
	@UserID 	INT
AS
	DECLARE @TotalBalance	INT
	DECLARE @TotalGross	INT
        DECLARE @TotalNet       INT

	SET @TotalBalance = (SELECT ISNULL(SUM(b.Payment), 0) TotalBalance FROM BalanceAccounts a, Balance b WHERE a.UserID = @UserID AND a.BalanceAccountID = b.BalanceAccountID)
	SET @TotalGross = (SELECT SUM(a.Gross) FROM Paychecks a, Companies b WHERE a.CompanyID = b.CompanyID AND DATEPART(year, a.PaymentDate) = DATEPART(year, getdate()) AND b.UserID = @UserID)
	SET @TotalNet = (SELECT SUM(a.Gross) - SUM(a.Federal + a.SocialSecurity + a.Medicare + a.NY_Withholding + a.NY_Disability + a.NY_City) FROM Paychecks a, Companies b WHERE a.CompanyID = b.CompanyID AND DATEPART(year, a.PaymentDate) = DATEPART(year, getdate()) AND b.UserID = @UserID)

	SELECT 
             @TotalBalance TotalBalance, 
             @TotalGross TotalGross,
             @TotalNet TotalNet
