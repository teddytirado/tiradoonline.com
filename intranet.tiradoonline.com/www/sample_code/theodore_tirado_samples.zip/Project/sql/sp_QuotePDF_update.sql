IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_QuotePDF_update' AND TYPE = 'P')
	DROP PROCEDURE sp_QuotePDF_update;
GO


CREATE PROCEDURE sp_QuotePDF_update
	@CompanyAddress		VARCHAR(2000),
	@Agreement		VARCHAR(5000),
	@updated_by		INT
AS

	UPDATE QuotePDF SET
		CompanyAddress = @CompanyAddress,
		Agreement = @Agreement,
		updated_by = @updated_by;


GO