delete from shippingaddressbook

INSERT INTO ShippingAddressBook
	(SalesID, CustomerID, Address1, Address2, Address3, Address4, City, StateID, ZipCode)
select 
	SalesID = CONVERT(VARCHAR, CONVERT(INT, LEFT(a.IDCUST, 2))),
	a.IDCUST AS CustomerID,
	a.TEXTSTRE1 AS Address1,
	a.TEXTSTRE2 AS Address2,
	a.TEXTSTRE3 AS Address3,
	a.TEXTSTRE4 AS Address4,
	a.NAMECITY AS City,
	a.CODESTTE AS StateID,
	a.CODEPSTL AS ZipCode
FROM 
	MISINC..ARCUS a,
	Userz b
WHERE
	CONVERT(VARCHAR, CONVERT(INT, LEFT(a.IDCUST, 2))) = b.SalesID AND
	ISNUMERIC(LEFT(a.IDCUST, 1)) = 1
	
	
SELECT * FROM SHIPPINGADDRESSBOOK

