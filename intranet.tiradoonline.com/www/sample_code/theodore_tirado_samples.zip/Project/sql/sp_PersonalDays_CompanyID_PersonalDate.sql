ALTER PROCEDURE sp_PersonalDays_CompanyID_PersonalDate
	@CompanyID	INT,
	@PersonalDate	SMALLDATETIME
AS
	SELECT 
		PersonalDayID 
	FROM 
		PersonalDays 
	WHERE 
		CompanyID = @CompanyID AND 
		PersonalDate = @PersonalDate
GO
