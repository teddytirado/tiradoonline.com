ALTER PROCEDURE sp_SickDays_insert
	@CompanyID	INT,
	@SickDate	SMALLDATETIME
AS
	INSERT INTO SickDays 
		(CompanyID, SickDate) 
	VALUES 
		(@CompanyID, @SickDate);
GO
