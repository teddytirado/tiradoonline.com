ALTER PROCEDURE sp_SnippetGroups_get
AS
	SELECT
		a.SnippetGroupID, 
		a.SnippetGroup,
		TotalSnippets = (SELECT COUNT(*) FROM Snippets b WHERE b.SnippetGroupID = a.SnippetGroupID)
	FROM 
		SnippetGroups a
	ORDER BY 
		a.SnippetGroup;
GO

