USE Service
GO

EXEC sp_dropuser 'service_user'
GO

USE Intranet
GO 

EXEC sp_dropuser 'service_user'
GO