ALTER PROCEDURE sp_administration_schema_objectid
	@ObjectID	INT
AS
	DECLARE @SQL		VARCHAR(100)

	SET @SQL = 'sp_helptext ' + OBJECT_NAME(@ObjectID)
	--PRINT @SQL
	EXEC(@SQL)
GO

--EXEC sp_administration_schema_objectid 2066106401