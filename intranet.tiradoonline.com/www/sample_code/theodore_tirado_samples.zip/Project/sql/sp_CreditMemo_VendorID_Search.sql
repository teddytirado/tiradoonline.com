IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_CreditMemo_VendorID_Search' AND TYPE = 'P')
	DROP PROCEDURE sp_CreditMemo_VendorID_Search;
GO


CREATE PROCEDURE sp_CreditMemo_VendorID_Search
	@VendorID			INT,
	@StartDate			DATETIME,
	@EndDate			DATETIME
AS

	SELECT
		*,
		Vendor = (SELECT VendorName FROM Vendors WHERE VendorID = CreditMemo.VendorID),
		updated_by = (SELECT FirstName + ' '  + LastName FROM Intranet..Userz WHERE SalesID = CreditMemo.update_by),
		created_by = (SELECT FirstName + ' '  + LastName FROM Intranet..Userz WHERE SalesID = CreditMemo.create_by)
	FROM
		CreditMemo
	WHERE
		CreditMemoDate BETWEEN @StartDate AND @EndDate AND
		VendorID = @VendorID;
GO

sp_CreditMemo_VendorID_Search 1001, '1/1/2005', '8/16/2010'