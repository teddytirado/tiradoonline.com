IF EXISTS (SELECT NAME FROM SYSOBJECTS WHERE NAME = 'sp_Settings_get' AND TYPE = 'P')
         DROP PROCEDURE sp_Settings_get;

GO

CREATE PROCEDURE sp_Settings_get
AS

	SELECT 
		*
	FROM
		Settings;

GO

 

EXEC sp_Settings_get

 