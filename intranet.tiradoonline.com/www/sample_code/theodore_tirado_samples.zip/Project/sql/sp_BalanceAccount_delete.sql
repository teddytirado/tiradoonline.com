ALTER PROCEDURE sp_BalanceAccount_delete 
	@BalanceAccountID	INT
AS

	/*
	BEGIN TRANSACTION DeleteBalanceAccount

	DECLARE @BalanceAccountName		VARCHAR(50);

	DELETE FROM Balance WHERE BalanceAccountID = @BalanceAccountID;
	DELETE FROM BalanceAccounts WHERE BalanceAccountID = @BalanceAccountID;

	IF @@ERROR = 0
		COMMIT TRANSACTION DeleteBalanceAccount;
	ELSE
		ROLLBACK TRANSACTION DeleteBalanceAccount;

	SELECT @BalanceAccountName;
	*/
	UPDATE BalanceAccounts SET Active = 0  WHERE BalanceAccountID = @BalanceAccountID;
	SELECT BalanceAccountName FROM BalanceAccounts WHERE BalanceAccountID = @BalanceAccountID;
GO

--EXEC sp_BalanceAccount_delete  1001, 'T-Mobile'