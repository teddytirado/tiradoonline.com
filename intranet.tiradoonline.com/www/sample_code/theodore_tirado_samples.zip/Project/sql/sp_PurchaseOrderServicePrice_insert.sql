IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_PurchaseOrderServicePrice_insert' AND TYPE = 'P')
	DROP PROCEDURE sp_PurchaseOrderServicePrice_insert;
GO


CREATE PROCEDURE sp_PurchaseOrderServicePrice_insert
	@ServiceReportNumber	NVARCHAR(10),
	@Quantity		INT,
	@PONumber		NVARCHAR(5),
	@PartNumber		NVARCHAR(20),
	@Description		NVARCHAR(50),
	@UnitPrice		MONEY
AS
	
	IF NOT EXISTS (SELECT PurchaseOrderServicePriceID FROM PurchaseOrderServicePrice WHERE 
				ServiceReportNumber = @ServiceReportNumber AND
				PONumber = @PONumber AND 
				PartNumber = @PartNumber)
		BEGIN
			INSERT INTO PurchaseOrderServicePrice
				(ServiceReportNumber,
				Quantity,
				PONumber,
				PartNumber,
				Description,
				UnitPrice)
			VALUES
				(@ServiceReportNumber,
				@Quantity,
				@PONumber,
				@PartNumber,
				@Description,
				@UnitPrice)
		END

GO

