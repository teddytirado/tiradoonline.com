ALTER PROCEDURE sp_BalanceAccounts_SubAccounts_get
	@BalanceAccountID		INT
AS

	--SET @BalanceAccountID = 1049;

	SELECT 
		DISTINCT a.BalanceAccountName,
		SubBalanceTotal = SUM(Payment)
	FROM 
		BalanceAccounts a, 
		Balance b 
	WHERE 
		a.BalanceAccountID = b.SubBalanceAccountID AND 
		(b.BalanceAccountID = @BalanceAccountID OR
		b.SubBalanceAccountID = @BalanceAccountID)
		/*
b.SubBalanceAccountID IN 
			(SELECT 
					c.SubBalanceAccountID 
			FROM 
				Balance c
			WHERE 
				c.BalanceAccountID = @BalanceAccountID)
		*/
			GROUP BY a.BalanceAccountName
	ORDER BY
		a.BalanceAccountName
GO

EXEC sp_BalanceAccounts_SubAccounts_get 1040