ALTER PROCEDURE sp_Paychecks_UserID_PaycheckDate
	@UserID			INT,
	@PaycheckDate		SMALLDATETIME
AS
	SELECT 
		a.PaycheckID,
		a.PaymentDate AS PaycheckDate, 
		a.Gross
	FROM 
		Paychecks a,
		Companies b
	WHERE 
		a.CompanyID = b.CompanyID AND
		b.UserID = @UserID AND
		DATEPART(month, a.PaymentDate) = MONTH(@PaycheckDate) AND
		DATEPART(year, a.PaymentDate) = YEAR(@PaycheckDate) 
	ORDER BY 
		a.PaymentDate
GO

EXEC sp_Paychecks_UserID_PaycheckDate 1001, '6/1/2000'

GO