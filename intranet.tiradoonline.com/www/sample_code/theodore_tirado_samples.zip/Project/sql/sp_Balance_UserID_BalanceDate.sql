ALTER PROCEDURE sp_Balance_UserID_BalanceDate
	@BalanceAccountID		INT,
	@BalanceDate			SMALLDATETIME
AS

	SELECT
		a.BalanceID,
		BalanceAccountID = @BalanceAccountID,
		a.SubBalanceAccountID,	
		BalanceAccountName = (SELECT BalanceAccountName FROM BalanceAccounts WHERE BalanceAccountID = @BalanceAccountID),
		SubAccountName = CASE 
					WHEN SubBalanceAccountID IS NOT NULL THEN
						(SELECT BalanceAccountName FROM BalanceAccounts WHERE BalanceAccountID = a.SubBalanceAccountID)
					ELSE
						NULL
				END,
		a.BalanceDate,
		a.Payment,
		a.Comment,
		b.Description
	FROM 
		Balance a, 
		Transactions b
	WHERE
		DATEPART(month, a.BalanceDate) = MONTH(@BalanceDate) AND 
		DATEPART(year, a.BalanceDate) = YEAR(@BalanceDate) AND 
		a.TransactionID = b.TransactionID AND
		(a.BalanceAccountID = @BalanceAccountID OR
		a.SubBalanceAccountID = @BalanceAccountID)
	ORDER BY
		a.BalanceDate,
		a.update_dt;
GO

EXEC teddy_user.sp_Balance_UserID_BalanceDate 1049, '1/1/2012'
EXEC teddy_user.sp_Balance_UserID_BalanceDate 1001, '1/1/2012'

