ALTER PROCEDURE sp_ContactGroups_get
AS
	SELECT
		a.ContactGroupID, 
		a.ContactGroup,
		TotalContacts = (SELECT COUNT(*) FROM Contacts b WHERE a.ContactGroupID = b.ContactGroupID)
	FROM 
		ContactGroups a
	ORDER BY 
		a.ContactGroup;
GO

exec sp_ContactGroups_get