ALTER PROCEDURE sp_Paychecks_UserID
	@UserID			INT,
	@PaymentYear		INT 
AS
	SELECT 
		b.PaycheckID, 
		b.PaymentDate, 
		b.CompanyID, 
		a.CompanyName, 
		Gross, 
		Net = (b.Gross - (b.Federal + b.SocialSecurity + b.Medicare + b.NY_Withholding + b.NY_Disability + b.NY_City)), 
                HourlyRate, 
                Hours = (Gross / HourlyRate),
                TotalRecords = (SELECT COUNT(*) FROM Companies a, Paychecks b WHERE a.CompanyID = b.CompanyID AND a.UserID = @UserID AND DATEPART(year, b.PaymentDate) = @PaymentYear) 
	FROM 
		Companies a, 
		Paychecks b 
	WHERE 
		a.CompanyID = b.CompanyID AND 
		a.UserID = @UserID AND 
		DATEPART(year, b.PaymentDate) = @PaymentYear 
	ORDER BY  
		b.PaymentDate DESC, 
		b.CompanyID
