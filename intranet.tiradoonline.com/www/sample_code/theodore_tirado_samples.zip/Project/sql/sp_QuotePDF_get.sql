IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_QuotePDF_get' AND TYPE = 'P')
	DROP PROCEDURE sp_QuotePDF_get;
GO


CREATE PROCEDURE sp_QuotePDF_get
AS

	IF NOT EXISTS (SELECT * FROM QuotePDF)
		BEGIN
			INSERT INTO QuotePDF
				(CompanyAddress, Agreement, updated_by)
			VALUES
				('MIS', 'MIS', 1000);
		END

	SELECT
		*
	FROM
		QuotePDF

GO
	