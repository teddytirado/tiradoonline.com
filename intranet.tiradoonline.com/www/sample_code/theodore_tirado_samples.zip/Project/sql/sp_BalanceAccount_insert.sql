ALTER PROCEDURE sp_BalanceAccount_insert
	@UserID 		INT,
	@BalanceAccountName	VARCHAR(20)
AS

	IF NOT EXISTS (SELECT BalanceAccountID FROM BalanceAccounts WHERE UserID = @UserID AND BalanceAccountName = @BalanceAccountName)
		BEGIN
			INSERT INTO BalanceAccounts 
				(UserID, BalanceAccountName) 
			VALUES 
				(@UserID, @BalanceAccountName);
		END

	SELECT @@IDENTITY AS BalanceAccountID;

GO

--EXEC sp_BalanceAccount_insert 1001, 'T-Mobile'