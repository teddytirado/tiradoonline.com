ALTER PROCEDURE sp_Contacts_UserID
	@UserID			INT,
	@ContactGroupID		INT
AS

	SELECT 
		a.ContactID, 
		ContactName = CASE 
					WHEN UPPER(b.ContactGroup) =  'COMPANIES' THEN a.Company			WHEN a.LastName <> '' THEN (a.FirstName + '&nbsp;' + a.LastName)
					WHEN a.LastName <> '' THEN (a.FirstName + '&nbsp;' + a.LastName)
					ELSE a.FirstName
			      	END, 
		a.Company,
		a.Title,
		a.Email1,
		a.Email2,
		a.Address1,
		a.Address2,
		a.City,
		a.StateID,
		a.ZipCode,
		a.Phone,
		a.FaxNumber, 
		a.Website, 
		a.Comments
	FROM 
		Contacts a,
		ContactGroups b
	WHERE 
		a.UserID = @UserID AND
		a.ContactGroupID = @ContactGroupID AND
		a.ContactGroupID = b.ContactGroupID
	ORDER BY
		a.FirstName
GO

