ALTER PROCEDURE sp_PersonalDays_PersonalDayID_get
	@PersonalDayID		INT
AS
	SELECT 
		a.PersonalDayID,
		a.CompanyID, 
		b.CompanyName,
		a.PersonalDate 
	FROM 
		Personaldays a,
		Companies b
	WHERE 
		a.CompanyID = b.CompanyID AND
		a.PersonalDayID = @PersonalDayID
GO
