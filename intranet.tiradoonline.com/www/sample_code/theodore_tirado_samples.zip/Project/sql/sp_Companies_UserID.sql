ALTER PROCEDURE sp_Companies_UserID
	@UserID		INT
AS
	SELECT 
        	CompanyID,
                CompanyName
	FROM
		Companies 
	WHERE 
		UserID = @UserID
