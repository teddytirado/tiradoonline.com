IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Service_Report_insert' AND TYPE = 'P')
	DROP PROCEDURE sp_Service_Report_insert;
GO


CREATE PROCEDURE sp_Service_Report_insert
	@ServiceReportNumber	INT,
	@CompanyID		INT,
	@CompanyName		VARCHAR(30),
	@SalesID		VARCHAR(10),
	@SalesTax		VARCHAR(10),
	@RepairDate		DATETIME,
	@RepairStartTime	VARCHAR(10),
	@RepairEndTime		VARCHAR(10),
	@Remarks		NVARCHAR(2000),
	@Problems		NVARCHAR(2000),
	@Solutions		NVARCHAR(2000),
	@ServiceDate		DATETIME,
	@ServiceTime		VARCHAR(10),
	@Contract		BIT,
	@T_M			BIT,
	@Warranty		BIT,
	@OtherDescription	VARCHAR(100),
	@PONumber		NVARCHAR(50),
	@WONumber	NVARCHAR(50),
	@LaborHours		REAL,
	@LaborRate		MONEY,
	@TravelHours		REAL,
	@MiscCharges		MONEY,
	@Shipping		MONEY,
	@Charge			BIT,
	@Freight		MONEY,
	@Contact		NVARCHAR(50),
	@Phone			NVARCHAR(11),
	@Ext			NVARCHAR(5),
	@LaborReimb		MONEY		

AS
	
	IF NOT EXISTS (SELECT ServiceReportNumber FROM ServiceReport WHERE ServiceReportNumber = @ServiceReportNumber)
		BEGIN
			BEGIN TRANSACTION TranServiceReport

			IF @CompanyName <> ''
				BEGIN
					IF NOT EXISTS (SELECT CompanyID FROM Companies WHERE CompanyName = @CompanyName)
						BEGIN 
							INSERT INTO Companies (CompanyName) VALUES (@CompanyName);
							SET @CompanyID = @@IDENTITY;
						END
				END

			INSERT INTO ServiceReport
				(ServiceReportNumber,
				CompanyID,
				SalesID,
				SalesTax,
				RepairDate,
				RepairStartTime,
				RepairEndTime,
				Remarks,
				Problems,
				Solutions,
				ServiceDate,
				ServiceTime,
				Contract,
				T_M,
				Warranty,
				OtherDescription,
				PONumber,
				WONumber,
				LaborHours,
				LaborRate,
				TravelHours,
				MiscCharges,
				Shipping,
				Charge,
				Freight,
				Contact,
				Phone,
				Ext,
				LaborReimb)
			VALUES 
				(@ServiceReportNumber,
				@CompanyID,
				@SalesID,
				@SalesTax,
				@RepairDate,
				@RepairStartTime,
				@RepairEndTime,
				@Remarks,
				@Problems,
				@Solutions,
				@ServiceDate,
				@ServiceTime,
				@Contract,
				@T_M,
				@Warranty,
				@OtherDescription,
				@PONumber,
				@WONumber,
				@LaborHours,
				@LaborRate,
				@TravelHours,
				@MiscCharges,
				@Shipping,
				@Charge,
				@Freight,
				@Contact,
				@Phone,
				@Ext,
				@LaborReimb);

			IF @@ERROR <> 0
				ROLLBACK TRAN TranServiceReport;
			ELSE
				COMMIT TRAN TranServiceReport;

			SELECT @ServiceReportNumber;
		END
	ELSE
		SELECT ServiceReportNumber = 0;
GO

EXEC sp_Service_Report_insert 4545452, 167, 'tiradoonline.com', '999', '0.0825', '7/1/10', '9:00 am', '10:00 am', 'Remarks', 'Problems', 'Solutions', '7/2/10', '10:00 am', 1, 0, 1, 'other description', 'PO Number', 'WO Number', 0, 0.00, 0, 0.00, 0.00, 0.00, 0.00, 'Theodore Tirado', '347.414.1284', '3115', 0.00