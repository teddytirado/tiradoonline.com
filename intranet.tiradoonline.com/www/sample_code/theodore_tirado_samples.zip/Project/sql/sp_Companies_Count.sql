ALTER PROCEDURE sp_Companies_Count
	@UserID		INT
AS
	SELECT COUNT(*) AS TOTAL FROM Companies WHERE UserID = @UserID
GO
