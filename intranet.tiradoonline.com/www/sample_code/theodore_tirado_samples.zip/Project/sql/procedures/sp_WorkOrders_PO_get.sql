IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_WorkOrders_PO_get' AND TYPE = 'P')
	DROP PROCEDURE sp_WorkOrders_PO_get;
GO


CREATE PROCEDURE sp_WorkOrders_PO_get
	@SalesID		NVARCHAR(50),
	@UserType		TINYINT,
	@StartRow		TINYINT,
	@EndRow			TINYINT

AS
	DECLARE @TOTALROWS 	INT;

	IF @UserType > 0
		BEGIN
			SELECT
				CustomerName = (SELECT NAMECUST FROM MISINC..ARCUS WHERE IDCUST = b.WOCustomer COLLATE SQL_Latin1_General_CP1_CI_AS),
				SalesPerson = (SELECT FirstName + ' ' + LastName FROM Userz WHERE SalesID = b.SPNumber COLLATE SQL_Latin1_General_CP1_CI_AS),
				b.WOCustomer,
				b.WODate,
				WorkOrderID = b.WONumber,
				WorkOrderTotal = (SELECT (SUM(WOUPrice * WOQTY) + b.WOTax) + b.WODelivery FROM WODetail WHERE WONumber = b.WONumber)
			INTO
				#WorkOrders
			FROM 
				Quote a,
				WorkOrder b
			WHERE 
				a.QID = b.QID AND
				a.Conv ='1' 
			ORDER BY 
				b.WONumber DESC

			PRINT '1'
			SET @TOTALROWS = (SELECT COUNT(*) FROM #WorkOrders);
			DECLARE WorkOrderCursor CURSOR FOR SELECT * FROM #WorkOrders;
		END
	ELSE
		BEGIN
			SELECT
				CustomerName = (SELECT NAMECUST FROM MISINC..ARCUS WHERE IDCUST = b.WOCustomer COLLATE SQL_Latin1_General_CP1_CI_AS),
				SalesPerson = (SELECT FirstName + ' ' + LastName FROM Userz WHERE SalesID = b.SPNumber COLLATE SQL_Latin1_General_CP1_CI_AS),
				b.WOCustomer,
				b.WODate,
				WorkOrderID = b.WONumber,
				WorkOrderTotal = (SELECT (SUM(WOUPrice * WOQTY) + b.WOTax) + b.WODelivery FROM WODetail WHERE WONumber = b.WONumber)
			INTO
				#WorkOrders2
			FROM 
				Quote a,
				WorkOrder b
			WHERE 
				a.QID = b.QID AND
				b.SPNumber = @SalesID AND
				a.Conv ='1' 
			ORDER BY 
				b.WONumber DESC

			
			PRINT '2'
			SET @TOTALROWS = (SELECT COUNT(*) FROM #WorkOrders2);
			DECLARE WorkOrderCursor CURSOR FOR SELECT * FROM #WorkOrders2;
		END

	
	OPEN WorkOrderCursor
	
	DECLARE @CustomerName 		VARCHAR(100);
	DECLARE @SalesPerson		VARCHAR(50);
	DECLARE @WOCustomer		VARCHAR(50);
	DECLARE @WorkOrderDate		VARCHAR(50);
	DECLARE @WONumber		INT;
	DECLARE @WorkOrderTotal		NUMERIC(9, 2);

	FETCH NEXT FROM WorkOrderCursor INTO @CustomerName, @SalesPerson, @WOCustomer, @WorkOrderDate, @WONumber, @WorkOrderTotal

	CREATE TABLE #WorkOrderTable
	(	
		CustomerName 		VARCHAR(100),
		SalesPerson		VARCHAR(50),
		WOCustomer		VARCHAR(50),
		WorkOrderDate		VARCHAR(50),
		WorkOrderID		INT,
		WorkOrderTotal		NUMERIC(9, 2)
	)

	DECLARE @COUNTER	INT;
	SET @COUNTER = 1;
	WHILE @@FETCH_STATUS = 0
		BEGIN
			IF @COUNTER >= @StartRow AND @COUNTER < @EndRow
				BEGIN
					INSERT INTO #WorkOrderTable
						(CustomerName, SalesPerson, WOCustomer, WorkOrderDate, WorkOrderID, WorkOrderTotal)
					VALUES
						(@CustomerName, @SalesPerson, @WOCustomer, @WorkOrderDate, @WONumber, @WorkOrderTotal);
				END
			SET @COUNTER = @COUNTER + 1;
			FETCH NEXT FROM WorkOrderCursor INTO @CustomerName, @SalesPerson, @WOCustomer, @WorkOrderDate, @WONumber, @WorkOrderTotal

		END

	CLOSE WorkOrderCursor	
	DEALLOCATE WorkOrderCursor	

	UPDATE #WorkOrderTable SET WorkOrderTotal = 0 WHERE WorkOrderTotal IS NULL;

	SELECT 
		*, 
		TotalRows = @TOTALROWS
	FROM 
		#WorkOrderTable;
GO

exec sp_WorkOrders_PO_get '5', 0, 1, 31