IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_CustomerPO_exists' AND TYPE = 'P')
	DROP PROCEDURE sp_CustomerPO_exists;
GO


CREATE PROCEDURE sp_CustomerPO_exists
	@CustomerPO	VARCHAR(50)
AS

	SELECT 
		WONumber,
		CustomerPO 
	FROM
		WorkOrder
	WHERE 
		CustomerPO = @CustomerPO
GO

EXEC sp_CustomerPO_exists 'TEST'