IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_InvalidLogins_insert' AND TYPE = 'P')
	DROP PROCEDURE sp_InvalidLogins_insert;
GO


CREATE PROCEDURE sp_InvalidLogins_insert
	@SalesID		nvarchar(50),
	@UPassword		nvarchar(50)
AS

	INSERT INTO InvalidLogins
		(SalesID, UPassword)
	VALUES
		(@SalesID, @UPassword);

GO