IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Vendor_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Vendor_get;
GO


CREATE PROCEDURE sp_Vendor_get
AS

	SELECT 
		VendorID,
		VendorNameAbb
	FROM
		Vendor 
	WHERE
		Active = 1
	ORDER BY 
		VendorNameAbb

GO

exec sp_Vendor_get