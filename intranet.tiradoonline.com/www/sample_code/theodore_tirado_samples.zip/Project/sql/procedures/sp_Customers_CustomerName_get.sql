IF EXISTS (SELECT NAME FROM SYSOBJECTS WHERE NAME = 'sp_Customers_CustomerName_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Customers_CustomerName_get;
GO


CREATE PROCEDURE sp_Customers_CustomerName_get
	@CustomerName		VARCHAR(30),
	@SalesID		VARCHAR(10),
	@Administrator		TINYINT	
AS

	SET @CustomerName = '%' + @CustomerName + '%';

	IF @Administrator = 1
		BEGIN
			SELECT 
				CustomerID, 
				CustomerName, 
				ContactName,
				Address1, 
				Address2,
				City,
				State,
				ZipCode,
				Phone, 
				Fax,
				SalesPerson = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = vw_Customers.SalesID)
			FROM 
				vw_Customers
			WHERE 
				UPPER(CustomerName) LIKE UPPER(@CustomerName)
			ORDER BY 
				CustomerID;
		END
	ELSE
		BEGIN
			SELECT 
				CustomerID, 
				CustomerName, 
				ContactName,
				Address1, 
				Address2,
				City,
				State,
				ZipCode,
				Phone, 
				Fax, 
				SalesPerson = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = vw_Customers.SalesID)
			FROM 
				vw_Customers
			WHERE 
				SalesID = @SalesID AND 
				UPPER(CustomerName) LIKE UPPER(@CustomerName)
			ORDER BY 
				CustomerID;
		END
GO

EXEC sp_Customers_CustomerName_get 'Soc', '5', 0
