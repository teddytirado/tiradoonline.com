IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_CustShip_WONumber_get' AND TYPE = 'P')
	DROP PROCEDURE sp_CustShip_WONumber_get;
GO


CREATE PROCEDURE sp_CustShip_WONumber_get
	@WONumber			INT
AS

	SELECT
		* 
	FROM
		CustShip
	WHERE
		WONumber = @WONumber;

GO

exec sp_CustShip_WONumber_get 15967

