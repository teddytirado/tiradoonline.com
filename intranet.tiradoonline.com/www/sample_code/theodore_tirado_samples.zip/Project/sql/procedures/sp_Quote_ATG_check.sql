IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Quote_ATG_check' AND TYPE = 'P')
	DROP PROCEDURE sp_Quote_ATG_check;
GO


CREATE PROCEDURE sp_Quote_ATG_check
	@QID			INT
AS

	SELECT
		QID,
		WOItemNum,
		create_dt
	FROM
		QuoteDetail
	WHERE
		QID = @QID AND
		WOItemNum LIKE '%NTENG%' OR
		WOItemNum LIKE '%NSC%' OR
		WOItemNum LIKE '%OSI%' OR
		WOItemNum = '30'

GO

exec sp_Quote_ATG_check 18613