IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_WODetail_LineNum_WONumber_fix' AND TYPE = 'P')
	DROP PROCEDURE sp_WODetail_LineNum_WONumber_fix;
GO


CREATE PROCEDURE sp_WODetail_LineNum_WONumber_fix
	@WorkOrderID			INT

AS

	IF EXISTS (SELECT * FROM WODetail WHERE WONumber = @WorkOrderID AND LineNum IS NULL)
		BEGIN
			
			DECLARE WorkOrderCursor CURSOR FOR SELECT WOLineNum FROM WODetail WHERE WONumber = @WorkOrderID ORDER BY create_dt;
			OPEN WorkOrderCursor
			
			DECLARE @WOLineNum		INT;
		
			FETCH NEXT FROM WorkOrderCursor INTO @WOLineNum		

			DECLARE @COUNTER	INT;
			SET @COUNTER = 1;
			WHILE @@FETCH_STATUS = 0
				BEGIN
					UPDATE WODetail SET LineNum = @COUNTER WHERE WOLineNum = @WOLineNum;
					SET @COUNTER = @COUNTER + 1;
					FETCH NEXT FROM WorkOrderCursor INTO @WOLineNum		
 		
				END
		
			CLOSE WorkOrderCursor	
			DEALLOCATE WorkOrderCursor	
		END
		
GO

exec sp_WODetail_LineNum_WONumber_fix 14428;

SELECT * FROM WODetail WHERE WONumber = 14428;