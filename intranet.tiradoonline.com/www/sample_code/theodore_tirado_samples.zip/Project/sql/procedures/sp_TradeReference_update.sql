IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_TradeReference_update' AND TYPE = 'P')
	DROP PROCEDURE sp_TradeReference_update;
GO


CREATE PROCEDURE sp_TradeReference_update

AS
		
	SELECT
		*
	FROM
		TradeReference;

GO

EXEC sp_TradeReference_update 