IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_WorkOrders_CustomerID_get' AND TYPE = 'P')
	DROP PROCEDURE sp_WorkOrders_CustomerID_get;
GO


CREATE PROCEDURE sp_WorkOrders_CustomerID_get
	@CustomerID		VARCHAR(50),
	@SalesID		NVARCHAR(50),
	@UserType		TINYINT
AS
	
	IF @UserType > 0
		BEGIN
			SELECT 
				CustomerName = (SELECT NAMECUST FROM MISINC..ARCUS WHERE IDCUST = @CustomerID COLLATE SQL_Latin1_General_CP1_CI_AS),
				SalesPerson = (SELECT FirstName + ' ' + LastName FROM Userz WHERE SalesID = WorkOrder.SPNumber COLLATE SQL_Latin1_General_CP1_CI_AS),
				WorkOrderTotal = (SELECT (SUM(WOUPrice * WOQTY) + WOTax) + WODelivery FROM WODetail WHERE WONumber = WorkOrder.WONumber),
				WorkOrderDate = WODate,
				WorkOrderID = WorkOrder.WONumber,
				*
			FROM 
				WorkOrder 
			WHERE 
				WOCustomer = @CustomerID
			ORDER BY 
				WONumber DESC
		END
	ELSE
		BEGIN
			SELECT 
				CustomerName = (SELECT NAMECUST FROM MISINC..ARCUS WHERE IDCUST = @CustomerID COLLATE SQL_Latin1_General_CP1_CI_AS),
				SalesPerson = (SELECT FirstName + ' ' + LastName FROM Userz WHERE SalesID = WorkOrder.SPNumber COLLATE SQL_Latin1_General_CP1_CI_AS),
				WorkOrderTotal = (SELECT (SUM(WOUPrice * WOQTY) + WOTax) + WODelivery FROM WODetail WHERE WONumber = WorkOrder.WONumber),
				WorkOrderDate = WODate,
				WorkOrderID = WorkOrder.WONumber,
				* 
			FROM 
				WorkOrder 
			WHERE 
				WOCustomer = @CustomerID AND		
				(SPNumber = @SalesID OR
				SPNumber IN (SELECT SalesID COLLATE SQL_LATIN1_GENERAL_CP1_CI_AS FROM SalesAssistants WHERE AssistantSalesID = @SalesID))
			ORDER BY 
				WONumber DESC
		END

GO

EXEC sp_WorkOrders_CustomerID_get '05SOCG0001  ', '5', 0