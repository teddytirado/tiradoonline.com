IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_News_update' AND TYPE = 'P')
	DROP PROCEDURE sp_News_update;
GO


CREATE PROCEDURE sp_News_update
	@NewsID		INT,
	@NewsDate	SMALLDATETIME,
	@Title		VARCHAR(150),
	@Body		TEXT
AS

	UPDATE News SET
		NewsDate = @NewsDate,
		Title = @Title,
		Body = @Body
	WHERE
		NewsID = @NewsID;

GO

--EXEC sp_News_update 26

