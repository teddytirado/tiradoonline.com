IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_QuoteDetail_WOLineNum_delete' AND TYPE = 'P')
	DROP PROCEDURE sp_QuoteDetail_WOLineNum_delete;
GO


CREATE PROCEDURE sp_QuoteDetail_WOLineNum_delete
	@WOLineNum		INT
AS
	DECLARE @QID			INT;
	DECLARE @WOLineNum2		INT;
	DECLARE @LineNum		INT;
	DECLARE @SQL			VARCHAR(1000);

	
	SET @QID = (SELECT QID FROM QuoteDetail WHERE WOLineNum = @WOLineNum);
	--PRINT 'QID: ' + CONVERT(VARCHAR, @QID);

	DELETE FROM QuoteDetail WHERE WOLineNum = @WOLineNum;

	DECLARE QuoteDetailCursor CURSOR 
		FOR SELECT WOLineNum FROM QuoteDetail WHERE QID = @QID;

	--PRINT 'TOTAL ROWS: ' + CONVERT(VARCHAR, @@CURSOR_ROWS);
	OPEN QuoteDetailCursor;

	FETCH NEXT FROM QuoteDetailCursor INTO @WOLineNum2;

	SET @LineNum = 1;	
	--PRINT 'LINENUM: ' + CONVERT(VARCHAR, @LineNum);
	WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @SQL = 'UPDATE QuoteDetail SET LineNum = ' + CONVERT(VARCHAR, @LineNum) + 'WHERE WOLineNum = ' + CONVERT(VARCHAR, @WOLineNum2);
			--PRINT @SQL;
			EXEC (@SQL);
			SET @LineNum = @LineNum + 1;	
			--PRINT 'LINENUM: ' + CONVERT(VARCHAR, @LineNum);
			FETCH NEXT FROM QuoteDetailCursor INTO @WOLineNum2;
		END

	CLOSE QuoteDetailCursor;
	DEALLOCATE QuoteDetailCursor;
GO

exec sp_QuoteDetail_WOLineNum_delete  36672


select top 10 * from quotedetail order by create_dt desc
