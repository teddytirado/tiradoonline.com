IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_WorkOrder_update' AND TYPE = 'P')
	DROP PROCEDURE sp_WorkOrder_update;
GO


CREATE PROCEDURE sp_WorkOrder_update
	@WONumber		INT,
	@ShippingMethod 	NVARCHAR(50),
	@ShippingComments	NTEXT,
	@WODelivery	 	NUMERIC(9, 2),
	@WOTaxRate		NUMERIC(9, 2),
	@WOTaxable		NVARCHAR(50)
AS
	
	DECLARE @WOTax 		NUMERIC(9, 2);
	
	IF @WOTaxRate IS NOT NULL AND CONVERT(INT, @WOTaxRate) <> 0
		BEGIN
			SET @WOTax = (SELECT SUM(WOUPrice * WOQTY) * (@WOTaxRate / 100) FROM WODetail WHERE WONumber = @WONumber);
			IF @WOTax IS NULL
				SET @WOTax = 0.00;
		END
	ELSE
		BEGIN
			SET @WOTax = 0.00;
		END

	UPDATE WorkOrder SET 
		ShippingMeth = @ShippingMethod,
		WONote = @ShippingComments,
		WODelivery = @WODelivery,
		WOTaxRate = @WOTaxRate,
		WOTax = @WOTax,
		WOTaxable = @WOTaxable
	WHERE 
		WONumber = @WONumber;
	
GO		

--sp_WorkOrder_update 7, '01SPEC1000', 'TRUCK', '', 0.00, 0

--sp_WorkOrder_update 16007, 'TRUCK', 'sss', 0.00, , 0.000, , '0'