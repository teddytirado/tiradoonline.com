IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_PreQuoteDetail_WOLineNum_PreQuoteDetailLineNum_move' AND TYPE = 'P')
	DROP PROCEDURE sp_PreQuoteDetail_WOLineNum_PreQuoteDetailLineNum_move;
GO


CREATE PROCEDURE sp_PreQuoteDetail_WOLineNum_PreQuoteDetailLineNum_move
	@PreQID			INT,
	@WOLineNum		INT,
	@PreQuoteDetailLineNum	INT
AS

	DECLARE @OldLineNum		INT;
	DECLARE @NewWOLineNum		INT;

	SET @OldLineNum = (SELECT LineNum FROM PreQuoteDetail WHERE WOLineNum = @WOLineNum);
	--PRINT 'OldLineNum: ' + CONVERT(VARCHAR, @OldLineNum);
	SET @NewWOLineNum = (SELECT WOLineNum FROM PreQuoteDetail WHERE PreQID = @PreQID AND LineNum = @PreQuoteDetailLineNum);
	UPDATE PreQuoteDetail SET LineNum = @PreQuoteDetailLineNum WHERE WOLineNum = @WOLineNum;
	--PRINT 'NewWOLineNum: ' + CONVERT(VARCHAR, NewWOLineNum);
	UPDATE PreQuoteDetail SET LineNum = @OldLineNum WHERE WOLineNum = @NewWOLineNum;
GO

--exec sp_PreQuoteDetail_WOLineNum_PreQuoteDetailLineNum_move 17000, 36685, 4


--select top 10 * from PreQuotedetail order by create_dt desc
--UPDATE PreQuoteDETAIL SET linenum = 3 where wolinenum = 36685
