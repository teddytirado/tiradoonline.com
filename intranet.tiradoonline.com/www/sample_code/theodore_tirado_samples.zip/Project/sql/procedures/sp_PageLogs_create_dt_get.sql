IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_PageLogs_create_dt_get' AND TYPE = 'P')
	DROP PROCEDURE sp_PageLogs_create_dt_get;
GO


CREATE PROCEDURE sp_PageLogs_create_dt_get
	@create_dt	DATETIME = GETDATE,
	@SalesID	INT = NULL
AS

	DECLARE @SQL	VARCHAR(1000);

	SET @SQL = '';
	SET @SQL = @SQL + 'SELECT ';
	SET @SQL = @SQL + 'TOP 100 ';
	SET @SQL = @SQL + 'a.PageLogID, ';
	SET @SQL = @SQL + 'a.create_dt, ';
	SET @SQL = @SQL + 'SalesPerson = b.FirstName + ' ' + b.LastName, ';
	SET @SQL = @SQL + 'a.SCRIPT_NAME ';
	SET @SQL = @SQL + 'FROM ';
	SET @SQL = @SQL + 'PageLogs a, ';
	SET @SQL = @SQL + 'Userz b ';
	SET @SQL = @SQL + 'WHERE ';
	SET @SQL = @SQL + 'a.SalesID = b.SalesID AND ';
	SET @SQL = @SQL + 'DATEPART(month, a.create_dt) = DATEPART(month, @create_dt) AND ';
	SET @SQL = @SQL + 'DATEPART(day, a.create_dt) = DATEPART(day, @create_dt) AND '; 
	SET @SQL = @SQL + 'DATEPART(year, a.create_dt) = DATEPART(year, @create_dt) ';
	SET @SQL = @SQL + 'ORDER BY ';
	SET @SQL = @SQL + 'a.create_dt DESC';
	
	EXEC sp_executesql @SQL;
GO

EXEC sp_PageLogs_create_dt_get '8/14/08'