IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_TimesheetEntry_Sick' AND TYPE = 'P')
	DROP PROCEDURE sp_TimesheetEntry_Sick;
GO


CREATE PROCEDURE sp_TimesheetEntry_Sick
	@TimesheetID	INT,
	@Status		BIT
AS
	
	UPDATE Timesheet
		SET Sick = @Status
	WHERE
		TimesheetID = @TimesheetID;

GO

