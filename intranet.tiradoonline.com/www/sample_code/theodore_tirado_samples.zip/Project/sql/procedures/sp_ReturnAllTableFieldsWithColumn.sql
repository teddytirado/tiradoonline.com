IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_ReturnAllTableFieldsWithColumn' AND TYPE = 'P')
	DROP PROCEDURE sp_ReturnAllTableFieldsWithColumn;
GO

CREATE PROCEDURE sp_ReturnAllTableFieldsWithColumn
	@Column		VARCHAR(50)
AS
	SET NOCOUNT ON;
	
	DECLARE @ColumnName	VARCHAR(50);
	DECLARE @ColumnText	VARCHAR(7000);
	DECLARE @TableName	VARCHAR(50);
	DECLARE @TableID	INT;
	DECLARE @Counter	INT;
	DECLARE @SQL 		NVARCHAR(2000);
	
	IF EXISTS (SELECT NAME FROM SYSOBJECTS WHERE NAME = 'tmpTable' AND TYPE = 'U')
		DROP TABLE tmpTable;



	DECLARE TableCursor CURSOR FOR SELECT tablename = (select name from sysobjects where id = a.id), id from SYSCOLUMNS a where a.name = @Column  ORDER BY TABLENAME;
	OPEN TableCursor
	FETCH NEXT FROM TableCursor INTO @TableName, @TableID

	SET @Counter = 1;
	
	WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @SQL = '';
			IF @Counter = 1
				BEGIN 
					SET @SQL = @SQL + 'CREATE TABLE tmpTable' + CHAR(10)
					SET @SQL = @SQL + '(' + CHAR(10);
					SET @SQL = @SQL + @TableName + ' VARCHAR(2000)' + CHAR(10);
					SET @SQL = @SQL + ');' + CHAR(10);
				END
			ELSE
				SET @SQL = 'ALTER TABLE tmpTable ADD ' + @TableName + ' VARCHAR(2000);' + CHAR(10)

			EXEC sp_executesql @SQL

			IF @Counter = 1
				BEGIN
					SET @SQL = 'INSERT INTO tmpTable (' + @TableName + ') VALUES (''0'');';
	 				EXEC sp_executesql @SQL
				END

			SET @Counter = @Counter + 1;
			FETCH NEXT FROM TableCursor INTO @TableName, @TableID
		END
	
	CLOSE TableCursor	
	DEALLOCATE TableCursor	


	DECLARE TableCursor CURSOR FOR SELECT tablename = (select name from sysobjects where id = a.id), id from SYSCOLUMNS a where a.name = @Column  ORDER BY TABLENAME;
	OPEN TableCursor
	FETCH NEXT FROM TableCursor INTO @TableName, @TableID

	WHILE @@FETCH_STATUS = 0
		BEGIN
			DECLARE ColumnCursor CURSOR FOR SELECT name FROM SYSCOLUMNS where id = @TableID ORDER BY colorder
			OPEN ColumnCursor
			FETCH NEXT FROM ColumnCursor INTO @ColumnName
			SET @ColumnText = '';
			SET @Counter = 1;
			WHILE @@FETCH_STATUS = 0
				BEGIN
					IF @Counter = 1
						SET @SQL = 'UPDATE tmpTable SET ' + @TableName + ' = ''' + @ColumnName + ',''';
					ELSE
						SET @SQL = 'UPDATE tmpTable SET ' + @TableName + ' = ' + @TableName + ' + ''' + @ColumnName + ',''';

					--PRINT @SQL;
 					EXEC sp_executesql @SQL
					SET @Counter = @Counter + 1;
					FETCH NEXT FROM ColumnCursor INTO @ColumnName
				END		
			CLOSE ColumnCursor	
			DEALLOCATE ColumnCursor	
			

			FETCH NEXT FROM TableCursor INTO @TableName, @TableID
		END
	
	CLOSE TableCursor	
	DEALLOCATE TableCursor	

	SELECT * INTO #tmpTable FROM tmpTable;

	DROP TABLE tmpTable;

	SELECT * FROM #tmpTable;
GO	

EXEC sp_ReturnAllTableFieldsWithColumn 'IDINVC'

