IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_CustShipq_Billing_update' AND TYPE = 'P')
	DROP PROCEDURE sp_CustShipq_Billing_update;
GO


CREATE PROCEDURE sp_CustShipq_Billing_update
	@QID			INT,
	@CustomerNum		NVARCHAR(50),
	@CustBName		NVARCHAR(50),
	@CustBAdd1		NVARCHAR(50),
	@CustBAdd2		NVARCHAR(50),
	@CustBAdd3		NVARCHAR(50),
	@CustBAdd4		NVARCHAR(255),
	@CustBCity		NVARCHAR(50),
	@CustBState		NVARCHAR(50),
	@CustBZip		NVARCHAR(50)
AS

	UPDATE CustShipq SET 
		CustomerNum = @CustomerNum,
		CustBName = @CustBName,
		CustBAdd1 = @CustBAdd1,
		CustBAdd2 = @CustBAdd2,
		CustBAdd3 = @CustBAdd3,
		CustBAdd4 = @CustBAdd4,
		CustBCity = @CustBCity,
		CustBState = @CustBState,
		CustBZip = @CustBZip
	WHERE 
		QID = @QID;

GO