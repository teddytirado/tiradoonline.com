IF EXISTS (SELECT NAME FROM SYSOBJECTS WHERE NAME = 'sp_Invoices_Purchases_totals_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Invoices_Purchases_totals_get;
GO

CREATE PROCEDURE sp_Invoices_Purchases_totals_get
	@CustomerID		VARCHAR(20),
	@SalesID		VARCHAR(10),
	@InvoiceYear		INT,
	@Administrator		TINYINT
AS

	IF @Administrator = 1
		BEGIN
			SELECT
		  		TotalInvoices = (SELECT COUNT(*) FROM vw_InvoiceHeader WHERE CustomerID = @CustomerID AND DATEPART(yyyy, InvoiceDate) = @InvoiceYear), 
		  		GrandTotalInvoices = (SELECT COUNT(*) FROM vw_InvoiceHeader WHERE CustomerID = @CustomerID),
				TotalPurchases = (SELECT COUNT(*) FROM vw_InvoiceHeader a, vw_InvoiceDetail b WHERE a.InvoiceNumber = b.InvoiceNumber AND a.CustomerID = @CustomerID AND DATEPART(yyyy, a.InvoiceDate) = @InvoiceYear AND UPPER(b.Category) <> 'FRT')
		END
	ELSE
		BEGIN
			SELECT
		  		TotalInvoices = (SELECT COUNT(*) FROM vw_InvoiceHeader WHERE SalesID = @SalesID AND CustomerID = @CustomerID), 
		  		GrandTotalInvoices = (SELECT COUNT(*) FROM vw_InvoiceHeader WHERE SalesID = @SalesID AND  CustomerID = @CustomerID AND DATEPART(yyyy, InvoiceDate) = @InvoiceYear),
				TotalPurchases = (SELECT COUNT(*) FROM vw_InvoiceHeader a, vw_InvoiceDetail b WHERE  a.SalesID = @SalesID AND a.InvoiceNumber = b.InvoiceNumber AND a.CustomerID = @CustomerID AND DATEPART(YYYY, a.InvoiceDate) = @InvoiceYear AND UPPER(b.Category) <> 'FRT')
		END
GO

EXEC sp_Invoices_Purchases_totals_get '33SEAG1500', '999', 2001, 1

SELECT * FROM vw_InvoiceHeader WHERE CustomerID = '33SEAG1500'
--SELECT * 