IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_TimesheetEntry_delete' AND TYPE = 'P')
	DROP PROCEDURE sp_TimesheetEntry_delete;
GO


CREATE PROCEDURE sp_TimesheetEntry_delete
	@TimesheetEntry		INT
AS
	
	DELETE FROM TimesheetEntry WHERE TimesheetEntryID = @TimesheetEntry 


GO

