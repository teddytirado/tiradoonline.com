IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_PreQuote_delete' AND TYPE = 'P')
	DROP PROCEDURE sp_PreQuote_delete;
GO


CREATE PROCEDURE sp_PreQuote_delete
	@PreQID		INT
AS

	BEGIN TRANSACTION TranQuote
	
	
	DELETE FROM PreQuote WHERE PreQID = @PreQID;
	DELETE FROM PreQuoteDetail WHERE PreQID = @PreQID;
	DELETE FROM PreCustShipQ WHERE PreQID = @PreQID;
	DELETE FROM PreQuoteTemplates WHERE PreQID = @PreQID;

	IF @@ERROR <> 0
		ROLLBACK TRAN TranQuote;
	ELSE
		COMMIT TRAN TranQuote;

GO

--exec sp_PreQuote_delete '999', 7
