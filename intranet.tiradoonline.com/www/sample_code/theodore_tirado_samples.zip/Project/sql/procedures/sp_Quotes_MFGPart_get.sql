IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Quotes_MFGPart_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Quotes_MFGPart_get;
GO


CREATE PROCEDURE sp_Quotes_MFGPart_get
	@MFGPart		NVARCHAR(50),
	@MFGYear		SMALLINT,
	@SalesID		NVARCHAR(50),
	@UserType		TINYINT
AS
	
	IF @UserType > 0
		BEGIN
			SELECT
				CustomerName = (SELECT NAMECUST FROM MISINC..ARCUS WHERE IDCUST = a.WOCustomer COLLATE SQL_Latin1_General_CP1_CI_AS),
				SalesPerson = (SELECT FirstName + ' ' + LastName FROM Userz WHERE SalesID = a.SPNumber COLLATE SQL_Latin1_General_CP1_CI_AS),
				QuoteTotal = (SELECT (SUM(WOUPrice * WOQTY) + WOTax) + WODelivery FROM QuoteDetail WHERE QID = a.QID),
				QuoteID = a.QID,
				a.*,
				b.*
			FROM 
				Quote a,
				QuoteDetail b
			WHERE 
				a.QID = b.QID AND
				DATEPART(YEAR, a.QuoteDate) >= @MFGYear AND
				LTRIM(RTRIM(b.WOItemNum)) = @MFGPart
			ORDER BY 
				a.QID DESC
		END
	ELSE
		BEGIN
			SELECT
				CustomerName = (SELECT NAMECUST FROM MISINC..ARCUS WHERE IDCUST = a.WOCustomer COLLATE SQL_Latin1_General_CP1_CI_AS),
				SalesPerson = (SELECT FirstName + ' ' + LastName FROM Userz WHERE SalesID = a.SPNumber COLLATE SQL_Latin1_General_CP1_CI_AS),
				QuoteTotal = (SELECT (SUM(WOUPrice * WOQTY) + WOTax) + WODelivery FROM QuoteDetail WHERE QID = a.QID),
				QuoteID = a.QID,
				a.*,
				b.*
			FROM 
				Quote a,
				QuoteDetail b
			WHERE 
				a.QID = b.QID AND
				DATEPART(YEAR, a.QuoteDate) >= @MFGYear AND
				LEFT(a.WOCustomer, 2) = @SalesID AND 
				LTRIM(RTRIM(b.WOItemNum)) = @MFGPart
			ORDER BY 
				a.QID DESC

		END

GO

EXEC sp_Quotes_MFGPart_get 'TN9500', 2010, '999', 1
