IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_CompanyPolicies_insert' AND TYPE = 'P')
	DROP PROCEDURE sp_CompanyPolicies_insert;
GO


CREATE PROCEDURE sp_CompanyPolicies_insert
	@CodeNo				VARCHAR(4),
	@PolicyName			VARCHAR(200),
	@Body				TEXT
AS

	IF NOT EXISTS (SELECT CodeNo FROM CompanyPolicies WHERE CodeNo = @CodeNo)
		BEGIN
			INSERT INTO CompanyPolicies 
				(CodeNo, PolicyName, Body)
			VALUES
				(@CodeNo, @PolicyName, @Body);
		END

GO

--EXEC sp_CompanyPolicies_insert 1010

