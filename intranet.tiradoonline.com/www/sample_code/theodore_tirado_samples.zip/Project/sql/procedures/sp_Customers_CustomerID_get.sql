IF EXISTS (SELECT NAME FROM SYSOBJECTS WHERE NAME = 'sp_Customers_CustomerID_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Customers_CustomerID_get;
GO


CREATE PROCEDURE sp_Customers_CustomerID_get
	@CustomerID		VARCHAR(20),
	@SalesID		VARCHAR(10),
	@Administrator		TINYINT	
AS

	SET @CustomerID = '%' + @CustomerID + '%';
	
	PRINT @Administrator;

	IF @Administrator = 1
		BEGIN
			SELECT 
				CustomerID, 
				CustomerName,
				ContactName, 
				Address1, 
				Address2,
				City,
				State,
				ZipCode,
				Phone, 
				Fax,
				SalesPerson = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = vw_Customers.SalesID)
			FROM 
				vw_Customers
			WHERE 
				UPPER(CustomerID) LIKE UPPER(@CustomerID)
			ORDER BY 
				CustomerID;
		END
	ELSE
		BEGIN
			SELECT 
				CustomerID, 
				CustomerName, 
				ContactName,
				Address1, 
				Address2,
				City,
				State,
				ZipCode,
				Phone, 
				Fax,
				SalesPerson = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = vw_Customers.SalesID)
			FROM 
				vw_Customers
			WHERE 
				SalesID = @SalesID AND 
				UPPER(CustomerID) LIKE UPPER(@CustomerID)
			ORDER BY 
				CustomerID;
		END
GO

EXEC sp_Customers_CustomerID_get 'GEN', '999', 1
