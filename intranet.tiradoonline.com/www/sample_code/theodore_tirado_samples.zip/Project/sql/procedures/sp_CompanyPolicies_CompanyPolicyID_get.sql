IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_CompanyPolicies_CompanyPolicyID_get' AND TYPE = 'P')
	DROP PROCEDURE sp_CompanyPolicies_CompanyPolicyID_get;
GO


CREATE PROCEDURE sp_CompanyPolicies_CompanyPolicyID_get
	@CompanyPolicyID		INT
AS

	SELECT
		CodeNo,
		PolicyName,
		Body,
		create_dt
	FROM
		CompanyPolicies
	WHERE
		CompanyPolicyID = @CompanyPolicyID;

GO

EXEC sp_CompanyPolicies_CompanyPolicyID_get 1010

