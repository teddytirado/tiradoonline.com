IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Phone_Numbers_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Phone_Numbers_get;
GO


CREATE PROCEDURE sp_Phone_Numbers_get
AS

	SELECT
		a.SalesID,
		FullName = a.FirstName + ' ' + a.LastName,
		a.Extension,
		a.FAXNum,
		b.Division
	FROM
		Userz a,
		Division b
	WHERE
		a.DivisionID = b.DivisionID AND
		UserControl = 'yes'
	ORDER BY
		b.Division,
		a.FirstName;

GO

EXEC sp_Phone_Numbers_get