IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Division_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Division_get;
GO


CREATE PROCEDURE sp_Division_get
AS

	SELECT
		*
	FROM
		Division
	ORDER BY 
		Division;

GO

exec sp_Division_get