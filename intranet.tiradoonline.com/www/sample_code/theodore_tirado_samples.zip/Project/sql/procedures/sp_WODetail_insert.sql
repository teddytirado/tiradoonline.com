IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_WODetail_insert' AND TYPE = 'P')
	DROP PROCEDURE sp_WODetail_insert;
GO


CREATE PROCEDURE sp_WODetail_insert
	@WONumber	INT,
	@VendorID	INT,
	@WOCost		NVARCHAR(50),
	@WOItemNum	NVARCHAR(50),
	@WODesc		VARCHAR(2000),
	@WOVenNum	NVARCHAR(50)
AS
	
	DECLARE @LineNum 	INT;

	SET @LineNum = (SELECT MAX(LineNum) FROM WODetail WHERE WONumber = @WONumber)
	IF @LineNum IS NULL
		SET @LineNum = 1;
	ELSE
		SET @LineNum = @LineNum + 1;

	INSERT INTO WODetail 
		(WONumber, LineNum, WOCost, WOItemNum, WOQTY, WODesc, WOUPrice, VendorID, CTID, WOVenNum)
	VALUES
		(@WONumber, @LineNum, @WOCost, @WOItemNum, '0', @WODesc, '0.00', @VendorID, 'NONE', @WOVenNum);

	SELECT @@IDENTITY;

GO

--exec sp_WODetail_insert