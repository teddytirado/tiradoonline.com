IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Taxes_Customer_get' AND TYPE = 'P')
 	DROP PROCEDURE sp_Taxes_Customer_get;
GO

CREATE PROCEDURE sp_Taxes_Customer_get
	@CustomerID	CHAR(12),
	@TaxRate	DECIMAL(15, 5) = 0.00 OUTPUT
AS
	
		SELECT TOP 1 
			a.CODETAXGRP,
			b.AUTHORITY1,
			c.ITEMRATE1 AS TaxRate
		INTO
			#Taxes
		FROM
			MISINC..ARCUS a,
			MISINC..TXGRP b,
			MISINC..TXRATE c
		WHERE
			a.IDCUST = @CustomerID AND
			a.CODETAXGRP = b.GROUPID AND
			b.AUTHORITY1 = C.AUTHORITY

		BEGIN
			
			INSERT INTO #Taxes
				(CODETAXGRP, AUTHORITY1, TaxRate)
			VALUES
				('', '', 0.00);
		END 

	SELECT * FROM #Taxes;	
GO

EXEC sp_Taxes_Customer_get '05SOCG0001'

exec sp_Taxes_Customer_get '21RUBI1000' 