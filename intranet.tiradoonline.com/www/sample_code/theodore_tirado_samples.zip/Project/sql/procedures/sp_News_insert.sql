IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_News_insert' AND TYPE = 'P')
	DROP PROCEDURE sp_News_insert;
GO


CREATE PROCEDURE sp_News_insert
	@NewsDate	SMALLDATETIME,
	@Title		VARCHAR(150),
	@Body		TEXT
AS

	INSERT INTO News 
		(NewsDate, Title, Body)
	VALUES
		(@NewsDate, @Title, @Body);

GO

--EXEC sp_News_insert 26

