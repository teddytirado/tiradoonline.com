IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_TimesheetEntry_manual_insert' AND TYPE = 'P')
	DROP PROCEDURE sp_TimesheetEntry_manual_insert;
GO


CREATE PROCEDURE sp_TimesheetEntry_manual_insert
	@TimeSheetID		INT,
	@TimesheetDate		DATETIME,
	@StartTime		DATETIME,
	@EndTime		DATETIME
AS

	SET @StartTime = @TimesheetDate + ' ' + @StartTime;
	SET @EndTime = @TimesheetDate + ' ' + @EndTime;
 
	INSERT INTO TimesheetEntry 
		(TimesheetID, start_time, end_time)
	VALUES
		(@TimesheetID, @StartTime, @EndTime)

GO

SELECT * FROM TimesheetEntry