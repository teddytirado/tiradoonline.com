IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_QuoteTemplates_SalesID_get' AND TYPE = 'P')
	DROP PROCEDURE sp_QuoteTemplates_SalesID_get;
GO


CREATE PROCEDURE sp_QuoteTemplates_SalesID_get
	@SalesID		VARCHAR(50),
	@Administrator		TINYINT
AS
	
	IF @Administrator = 1 
		BEGIN
			SELECT 
				QID,
				QuoteTemplateID,
				SalesID,
				SalesPerson = (SELECT FirstName + ' ' + LastName FROM Userz WHERE SalesID  COLLATE SQL_Latin1_General_CP1_CI_AS = QuoteTemplates.SalesID),
				QuoteTemplateName,
				create_dt
			FROM
				QuoteTemplates
			--WHERE
			--	SalesID IN (SELECT SalesID  COLLATE SQL_Latin1_General_CP1_CI_AS FROM SalesAssistants WHERE AssistantSalesID COLLATE SQL_Latin1_General_CP1_CI_AS = @SalesID  COLLATE SQL_Latin1_General_CP1_CI_AS) OR
			--	SalesID = @SalesID
			ORDER BY 
				QuoteTemplateName;
		END
	ELSE
		BEGIN
			SELECT 
				QID,
				SalesID,
				QuoteTemplateID,
				SalesPerson = (SELECT FirstName + ' ' + LastName FROM Userz WHERE SalesID  COLLATE SQL_Latin1_General_CP1_CI_AS = QuoteTemplates.SalesID),
				QuoteTemplateName,
				create_dt
			FROM
				QuoteTemplates
			WHERE
				SalesID = @SalesID
			ORDER BY 
				QuoteTemplateName;
		END
GO

EXEC sp_QuoteTemplates_SalesID_get '18', 0



