IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Timesheet_max_min_year_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Timesheet_max_min_year_get;
GO


CREATE PROCEDURE sp_Timesheet_max_min_year_get
AS

	
	SELECT 
		MaxYear = (SELECT MAX(DATEPART(YEAR, Timesheet_dt)) FROM Timesheet),
		MinYear = (SELECT MIN(DATEPART(YEAR, Timesheet_dt)) FROM Timesheet);

GO

EXEC sp_Timesheet_max_min_year_get