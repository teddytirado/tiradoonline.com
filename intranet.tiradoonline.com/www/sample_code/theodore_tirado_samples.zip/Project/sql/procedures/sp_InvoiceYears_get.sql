IF EXISTS (SELECT NAME FROM SYSOBJECTS WHERE NAME = 'sp_InvoiceYears_get' AND TYPE = 'P')
	DROP PROCEDURE sp_InvoiceYears_get;
GO

CREATE PROCEDURE sp_InvoiceYears_get
	@CustomerID		VARCHAR(20),
	@SalesID		VARCHAR(10),
	@Administrator		TINYINT	
AS

	IF @Administrator = 1
		BEGIN
			SELECT 
				DISTINCT DATEPART(yyyy, InvoiceDate) AS InvoiceYear, 
				TotalInvoices = COUNT(*) 
			FROM 
				vw_InvoiceHeader 
			WHERE 
				CustomerID = @CustomerID 
			GROUP BY 
				DATEPART(yyyy, InvoiceDate) 
			ORDER BY 
				DATEPART(yyyy, InvoiceDate) DESC
		END
	ELSE
		BEGIN
			SELECT 
				DISTINCT DATEPART(yyyy, InvoiceDate) AS InvoiceYear, 
				TotalInvoices = COUNT(*) 
			FROM 
				vw_InvoiceHeader 
			WHERE 
				SalesID = @SalesID AND
				CustomerID = @CustomerID 
			GROUP BY 
				DATEPART(yyyy, InvoiceDate) 
			ORDER BY 
				DATEPART(yyyy, InvoiceDate) DESC
		END
GO

EXEC sp_InvoiceYears_get '01AOLT1000', '999', 1
