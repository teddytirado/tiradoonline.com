IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_SalesAssistants_insert' AND TYPE = 'P')
	DROP PROCEDURE sp_SalesAssistants_insert;
GO


CREATE PROCEDURE sp_SalesAssistants_insert
	@SalesID			NVARCHAR(255),
	@AssistantSalesID		NVARCHAR(255)
AS


	INSERT INTO SalesAssistants
		(SalesID, AssistantSalesID)
	VALUES
		(@SalesID, @AssistantSalesID);

GO
