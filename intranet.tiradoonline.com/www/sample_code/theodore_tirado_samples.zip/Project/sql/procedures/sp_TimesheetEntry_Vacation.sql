IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_TimesheetEntry_Vacation' AND TYPE = 'P')
	DROP PROCEDURE sp_TimesheetEntry_Vacation;
GO


CREATE PROCEDURE sp_TimesheetEntry_Vacation
	@TimesheetID	INT,
	@Status		BIT
AS
	
	UPDATE Timesheet
		SET Vacation = @Status
	WHERE
		TimesheetID = @TimesheetID;

GO

