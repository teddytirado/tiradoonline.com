IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_QuoteDetail_QID_get' AND TYPE = 'P')
	DROP PROCEDURE sp_QuoteDetail_QID_get;
GO


CREATE PROCEDURE sp_QuoteDetail_QID_get
	@QID		INT
AS
	
	SELECT 
		a.*, 
		b.*,
		Total = (SELECT COUNT(*) FROM QuoteDetail WHERE QID = @QID) 
	FROM 
		Quote a,
		QuoteDetail b
	WHERE 
		a.QID = b.QID AND
		a.QID = @QID
	ORDER BY 
		b.LineNum;

GO

EXEC sp_QuoteDetail_QID_get 2576