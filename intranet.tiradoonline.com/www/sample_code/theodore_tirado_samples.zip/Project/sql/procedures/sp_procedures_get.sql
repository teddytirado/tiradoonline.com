IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Procedures_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Procedures_get;
GO


CREATE PROCEDURE sp_Procedures_get
AS
	

	SELECT 
		NAME 
	FROM 
		sysobjects 
	WHERE 
		TYPE = 'P' AND 
		LEFT(NAME, 3) <> 'DT_' 
	ORDER BY 
		NAME;

GO

EXEC sp_Procedures_get