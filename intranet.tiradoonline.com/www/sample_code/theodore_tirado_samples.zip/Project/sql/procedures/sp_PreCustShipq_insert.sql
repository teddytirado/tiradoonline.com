IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_PreCustShipq_insert' AND TYPE = 'P')
	DROP PROCEDURE sp_PreCustShipq_insert;
GO


CREATE PROCEDURE sp_PreCustShipq_insert
	@PreQID			INT,
	@CustomerNum		NVARCHAR(50),
	@CustName		NVARCHAR(50),
	@CustBName		NVARCHAR(50),
	@CustBAdd1		NVARCHAR(50),
	@CustBAdd2		NVARCHAR(50),
	@CustBAdd3		NVARCHAR(50),
	@CustBAdd4		NVARCHAR(50),
	@CustBCity		NVARCHAR(50),
	@CustBState		NVARCHAR(50),
	@CustBZip		NVARCHAR(50)
AS

	INSERT INTO PreCustShipq
		(PreQID, CustomerNum, CustName, CustBName, CustBAdd1, CustBAdd2, CustBAdd3, CustBAdd4, CustBCity, CustBState, CustBZip)
	VALUES
		(@PreQID, @CustomerNum, @CustName, @CustBName, @CustBAdd1, @CustBAdd2, @CustBAdd3, @CustBAdd4, @CustBCity, @CustBState, @CustBZip);

GO

