IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_QuoteDetail_WOLineNum_QuoteDetailLineNum_move' AND TYPE = 'P')
	DROP PROCEDURE sp_QuoteDetail_WOLineNum_QuoteDetailLineNum_move;
GO


CREATE PROCEDURE sp_QuoteDetail_WOLineNum_QuoteDetailLineNum_move
	@QID			INT,
	@WOLineNum		INT,
	@QuoteDetailLineNum	INT
AS

	DECLARE @OldLineNum		INT;
	DECLARE @NewWOLineNum		INT;

	SET @OldLineNum = (SELECT LineNum FROM QuoteDetail WHERE WOLineNum = @WOLineNum);
	--PRINT 'OldLineNum: ' + CONVERT(VARCHAR, @OldLineNum);
	SET @NewWOLineNum = (SELECT WOLineNum FROM QuoteDetail WHERE QID = @QID AND LineNum = @QuoteDetailLineNum);
	UPDATE QuoteDetail SET LineNum = @QuoteDetailLineNum WHERE WOLineNum = @WOLineNum;
	--PRINT 'NewWOLineNum: ' + CONVERT(VARCHAR, NewWOLineNum);
	UPDATE QuoteDetail SET LineNum = @OldLineNum WHERE WOLineNum = @NewWOLineNum;
GO

--exec sp_QuoteDetail_WOLineNum_QuoteDetailLineNum_move 17000, 36685, 4


--select top 10 * from Quotedetail order by create_dt desc
--UPDATE QuoteDETAIL SET linenum = 3 where wolinenum = 36685
