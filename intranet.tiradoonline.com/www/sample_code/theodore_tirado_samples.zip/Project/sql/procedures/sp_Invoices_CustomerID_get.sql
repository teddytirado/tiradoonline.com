IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Invoices_CustomerID_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Invoices_CustomerID_get;
GO


CREATE PROCEDURE sp_Invoices_CustomerID_get
	@CustomerID		VARCHAR(20),
	@SalesID		VARCHAR(10),
	@InvoiceYear		INT,
	@Administrator		TINYINT	
AS

	IF @Administrator = 1
		BEGIN
			SELECT 
				InvoiceNumber,
				InvoiceDate,
				PONumber,
				TotalCost = (SELECT SUM(Cost * Quantity) FROM vw_InvoiceDetail WHERE InvoiceNumber = vw_InvoiceHeader.InvoiceNumber AND UPPER(ItemNumber) <> 'FRT' AND UPPER(Description) <> 'FREIGHT'),
				TotalPrice = (SELECT SUM(UnitPrice) FROM vw_InvoiceDetail WHERE InvoiceNumber = vw_InvoiceHeader.InvoiceNumber AND UPPER(ItemNumber) <> 'FRT' AND UPPER(Description) <> 'FREIGHT'),
				ExtendedPrice = (SELECT SUM(UnitPrice * Quantity) FROM vw_InvoiceDetail WHERE InvoiceNumber = vw_InvoiceHeader.InvoiceNumber AND UPPER(ItemNumber) <> 'FRT' AND UPPER(Description) <> 'FREIGHT'),
				Freight = (SELECT SUM(UnitPrice) FROM vw_InvoiceDetail WHERE InvoiceNumber = vw_InvoiceHeader.InvoiceNumber AND (UPPER(ItemNumber) = 'FRT' OR UPPER(Description) = 'FREIGHT')),
				Tax = (SELECT SUM(Tax) FROM vw_InvoiceDetail WHERE InvoiceNumber = vw_InvoiceHeader.InvoiceNumber),
				TotalDue
			FROM 
				vw_InvoiceHeader
			WHERE 
				UPPER(CustomerID) = UPPER(@CustomerID) AND
				DATEPART(YYYY, InvoiceDate) = @InvoiceYear
			ORDER BY 
				InvoiceNumber;
		END
	ELSE
		BEGIN
			SELECT 
				InvoiceNumber,
				InvoiceDate,
				PONumber,
				TotalCost = (SELECT SUM(Cost) FROM vw_InvoiceDetail WHERE InvoiceNumber = vw_InvoiceHeader.InvoiceNumber AND UPPER(ItemNumber) <> 'FRT' AND UPPER(Description) <> 'FREIGHT'),
				TotalPrice = (SELECT SUM(UnitPrice) FROM vw_InvoiceDetail WHERE InvoiceNumber = vw_InvoiceHeader.InvoiceNumber AND UPPER(ItemNumber) <> 'FRT' AND UPPER(Description) <> 'FREIGHT'),
				ExtendedPrice = (SELECT SUM(UnitPrice * Quantity) FROM vw_InvoiceDetail WHERE InvoiceNumber = vw_InvoiceHeader.InvoiceNumber AND UPPER(ItemNumber) <> 'FRT' AND UPPER(Description) <> 'FREIGHT'),
				Freight = (SELECT SUM(UnitPrice) FROM vw_InvoiceDetail WHERE InvoiceNumber = vw_InvoiceHeader.InvoiceNumber AND (UPPER(ItemNumber) = 'FRT' OR UPPER(Description) = 'FREIGHT')),
				Tax = (SELECT SUM(Tax) FROM vw_InvoiceDetail WHERE InvoiceNumber = vw_InvoiceHeader.InvoiceNumber),
				TotalDue
			FROM 
				vw_InvoiceHeader
			WHERE 
				SalesID = @SalesID AND
				UPPER(CustomerID) = UPPER(@CustomerID) AND
				DATEPART(YYYY, InvoiceDate) = @InvoiceYear
			ORDER BY 
				InvoiceNumber;
		END
GO

EXEC sp_Invoices_CustomerID_get '07WALD1000', '999', 2010, 1 
