IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_QuoteTemplates_insert' AND TYPE = 'P')
	DROP PROCEDURE sp_QuoteTemplates_insert;
GO


CREATE PROCEDURE sp_QuoteTemplates_insert
	@SalesID		INT,
	@QuoteID		INT,
	@QuoteTemplateName	VARCHAR(50)
AS

	DECLARE @QuoteTemplateID	INT;

	IF NOT EXISTS (SELECT * FROM QuoteTemplates WHERE SalesID = @SalesID AND QuoteTemplateName = @QuoteTemplateName) OR NOT EXISTS (SELECT * FROM QuoteTemplates WHERE SalesID = @SalesID AND QID = @QuoteID)
		BEGIN
			INSERT INTO QuoteTemplates 
				(SalesID, QID, QuoteTemplateName)
			VALUES
				(@SalesID, @QuoteID, @QuoteTemplateName);
			
			SELECT QuoteTemplateID = @@IDENTITY;
			--SELECT SalesID = @SalesID;
		END
	ELSE
		SELECT QuoteTemplateID = NULL;

	
GO

--exec sp_QuoteTemplates_insert '999', 7
