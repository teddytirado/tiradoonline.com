IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_CompanyPolicies_update' AND TYPE = 'P')
	DROP PROCEDURE sp_CompanyPolicies_update;
GO


CREATE PROCEDURE sp_CompanyPolicies_update
	@CompanyPolicyID		INT,
	@CodeNo				VARCHAR(4),
	@PolicyName			VARCHAR(200),
	@Body				TEXT
AS

	UPDATE CompanyPolicies SET
		CodeNo = @CodeNo,
		PolicyName = @PolicyName,

		Body = @Body
	FROM
		CompanyPolicies
	WHERE
		CompanyPolicyID = @CompanyPolicyID;

GO

--EXEC sp_CompanyPolicies_update 1010

