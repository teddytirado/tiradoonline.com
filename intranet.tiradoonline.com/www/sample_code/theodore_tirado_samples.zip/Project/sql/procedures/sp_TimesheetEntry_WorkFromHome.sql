IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_TimesheetEntry_WorkFromHome' AND TYPE = 'P')
	DROP PROCEDURE sp_TimesheetEntry_WorkFromHome;
GO


CREATE PROCEDURE sp_TimesheetEntry_WorkFromHome
	@TimesheetID	INT,
	@Status 	BIT
AS
	
	UPDATE Timesheet
		SET WorkFromHome = @Status
	WHERE
		TimesheetID = @TimesheetID;

GO

