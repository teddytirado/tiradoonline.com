IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_CompanyPolicies_get' AND TYPE = 'P')
	DROP PROCEDURE sp_CompanyPolicies_get;
GO


CREATE PROCEDURE sp_CompanyPolicies_get
AS

	SELECT
		CompanyPolicyID,
		CodeNo,
		PolicyName,
		create_dt
	FROM
		CompanyPolicies
	ORDER BY 
		CodeNo;

GO

EXEC sp_CompanyPolicies_get

