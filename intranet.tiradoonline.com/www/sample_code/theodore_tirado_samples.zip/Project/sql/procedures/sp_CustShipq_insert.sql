IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_CustShipq_insert' AND TYPE = 'P')
	DROP PROCEDURE sp_CustShipq_insert;
GO


CREATE PROCEDURE sp_CustShipq_insert
	@QID			INT,
	@CustomerNum		NVARCHAR(50),
	@CustName		NVARCHAR(50),
	@CustBName		NVARCHAR(50),
	@CustBAdd1		NVARCHAR(50),
	@CustBAdd2		NVARCHAR(50),
	@CustBAdd3		NVARCHAR(50),
	@CustBAdd4		NVARCHAR(50),
	@CustBCity		NVARCHAR(50),
	@CustBState		NVARCHAR(50),
	@CustBZip		NVARCHAR(50)
AS

	INSERT INTO CustShipq
		(QID, CustomerNum, CustName, CustBName, CustBAdd1, CustBAdd2, CustBAdd3, CustBAdd4, CustBCity, CustBState, CustBZip)
	VALUES
		(@QID, @CustomerNum, @CustName, @CustBName, @CustBAdd1, @CustBAdd2, @CustBAdd3, @CustBAdd4, @CustBCity, @CustBState, @CustBZip);

GO

