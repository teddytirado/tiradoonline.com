IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Carrier_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Carrier_get;
GO


CREATE PROCEDURE sp_Carrier_get
	@CarrierID		INT
AS

	SELECT 
		Carrier = CarrierAbb + ' - ' + DSType
	FROM
		Carrier
	WHERE
		DSID = @CarrierID;
GO

EXEC sp_Carrier_get 14;

