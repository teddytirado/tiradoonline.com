IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_SalesAssistants_SalesID_get' AND TYPE = 'P')
	DROP PROCEDURE sp_SalesAssistants_SalesID_get;
GO


CREATE PROCEDURE sp_SalesAssistants_SalesID_get
	@SalesID			NVARCHAR(255)
AS

	SELECT
		a.SalesAssistantID,
		a.AssistantSalesID,
		FullName = b.LastName + ', ' + b.FirstName,
		b.UserControl
	FROM	
		SalesAssistants a,
		Userz b
	WHERE
		a.AssistantSalesID = b.SalesID AND
		a.SalesID = @SalesID
	ORDER BY
		b.LastName;

GO

EXEC sp_SalesAssistants_SalesID_get 3