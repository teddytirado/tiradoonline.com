IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_PreCustShipq_PreQID_get' AND TYPE = 'P')
	DROP PROCEDURE sp_PreCustShipq_PreQID_get;
GO


CREATE PROCEDURE sp_PreCustShipq_PreQID_get
	@PreQID			INT
AS

	SELECT
		* 
	FROM
		PreCustShipQ
	WHERE
		PreQID = @PreQID;

GO