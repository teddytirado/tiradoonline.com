IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_SalesAssistants_delete' AND TYPE = 'P')
	DROP PROCEDURE sp_SalesAssistants_delete;
GO


CREATE PROCEDURE sp_SalesAssistants_delete
	@SalesAssistantID	INT
AS

	DELETE FROM SalesAssistants WHERE SalesAssistantID = @SalesAssistantID;

GO
