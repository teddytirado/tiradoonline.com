IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_ULogins_insert' AND TYPE = 'P')
	DROP PROCEDURE sp_ULogins_insert;
GO


CREATE PROCEDURE sp_ULogins_insert
	@SalesID		nvarchar(255),
	@IPAddress		VARCHAR(100),
	@Browser		VARCHAR(100)
AS

	INSERT INTO ULogins
		(SalesID, IPAddress, Browser)
	VALUES
		(@SalesID, @IPAddress, @Browser);

GO