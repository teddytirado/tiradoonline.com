IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_ItemCategory_get' AND TYPE = 'P')
	DROP PROCEDURE sp_ItemCategory_get;
GO


CREATE PROCEDURE sp_ItemCategory_get
AS

	SELECT
		CategoryValue,
		Category
	FROM	
		ItemCategory
	ORDER BY
		ItemCategoryID;

GO

EXEC sp_ItemCategory_get