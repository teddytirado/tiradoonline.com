IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_TimeEntry_SalesID_get' AND TYPE = 'P')
	DROP PROCEDURE sp_TimeEntry_SalesID_get;
GO


CREATE PROCEDURE sp_TimeEntry_SalesID_get
	@TimesheetID	INT
AS

	SELECT
		TimesheetID,
		start_time,
		end_time,
		note
	FROM	
		TimesheetEntry
	WHERE
		TimesheetID = @TimesheetID
GO

exec sp_TimeEntry_SalesID_get 1001