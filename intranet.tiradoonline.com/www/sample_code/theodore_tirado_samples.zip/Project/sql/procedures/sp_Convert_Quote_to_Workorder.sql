IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Convert_Quote_to_Workorder' AND TYPE = 'P')
	DROP PROCEDURE sp_Convert_Quote_to_Workorder;
GO


CREATE PROCEDURE sp_Convert_Quote_to_Workorder
	@QID			INT,
	@CustomerPO		NVARCHAR(50)
AS
	
	DECLARE @WONumber		INT;

	BEGIN TRAN T1

		INSERT INTO WorkOrder
			(SPNumber, PreparedByID, QID, Attn, Phone, QuoteDate, Terms, WOCustomer, WODate, ShippingMeth, CustomerPO, WONote, WODelivery, WOTaxRate, WOTax, WOTaxable, Status)
		SELECT
			SPNumber, PreparedByID, QID, Attn, Phone, QuoteDate, Terms, WOCustomer, GETDATE(), ShippingMeth, @CustomerPO, WONote, WODelivery, WOTaxRate, WOTax, WOTaxable, 1
		FROM
			Quote
		WHERE 
			QID = @QID;
		
		
		SELECT @WONumber = @@IDENTITY;

		UPDATE Quote SET CONV = 1 WHERE QID = @QID;

		IF @@ERROR <> 0 
			ROLLBACK TRAN T1

	COMMIT TRAN T1


GO

