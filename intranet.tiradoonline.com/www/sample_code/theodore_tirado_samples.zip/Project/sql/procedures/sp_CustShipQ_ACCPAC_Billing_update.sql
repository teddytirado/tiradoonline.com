IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_CustShipQ_ACCPAC_Billing_update' AND TYPE = 'P')
	DROP PROCEDURE sp_CustShipQ_ACCPAC_Billing_update;
GO


CREATE PROCEDURE sp_CustShipQ_ACCPAC_Billing_update

AS
	--SET NOCOUNT ON;

	DECLARE @QuoteID	INT;
	DECLARE @CustomerID	VARCHAR(100);
	DECLARE @NAMECUST	VARCHAR(100);
	DECLARE @TEXTSTRE1	VARCHAR(100);
	DECLARE @TEXTSTRE2	VARCHAR(100);
	DECLARE @TEXTSTRE3	VARCHAR(100);
	DECLARE @TEXTSTRE4	VARCHAR(100);
	DECLARE @NAMECITY	VARCHAR(100);
	DECLARE @CODESTTE	VARCHAR(100);
	DECLARE @CODEPSTL	VARCHAR(100);

	DECLARE quoteCursor CURSOR FOR SELECT QID, WOCustomer FROM Quote ORDER BY QuoteDate DESC;
	OPEN quoteCursor

	FETCH NEXT FROM quoteCursor INTO @QuoteID, @CustomerID

	WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @CustomerID = LTRIM(RTRIM(@CustomerID));

			SELECT 
				@NAMECUST = NAMECUST, 
				@TEXTSTRE1 = TEXTSTRE1, 
				@TEXTSTRE2 = TEXTSTRE2, 
				@TEXTSTRE3 = TEXTSTRE3, 
				@TEXTSTRE4 = TEXTSTRE4, 
				@NAMECITY = NAMECITY, 
				@CODESTTE = CODESTTE, 
				@CODEPSTL = CODEPSTL 
			FROM 
				MISINC..ARCUS 
			WHERE 
				LTRIM(RTRIM(IDCUST)) = LTRIM(RTRIM(@CustomerID));

			
			UPDATE CustShipQ SET
				CustBName = @NAMECUST,
				CustBAdd1 = @TEXTSTRE1, 
				CustBAdd2 = @TEXTSTRE2, 
				CustBAdd3 = @TEXTSTRE3, 
				CustBAdd4 = @TEXTSTRE4, 
				CustBCity = @NAMECITY, 
				CustBState = @CODESTTE, 
				CustBZip = @CODEPSTL
			WHERE
				QID = @QuoteID;

			PRINT @QuoteID;
			PRINT @CustomerID + ' - ' + @NAMECUST;
			
			FETCH NEXT FROM quoteCursor INTO @QuoteID, @CustomerID
			
		END


	CLOSE quoteCursor	
	DEALLOCATE quoteCursor	

GO

--exec sp_CustShipQ_ACCPAC_Billing_update