IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_WOPO_get' AND TYPE = 'P')
	DROP PROCEDURE sp_WOPO_get;
GO


CREATE PROCEDURE sp_WOPO_get
	@WONumber		INT
AS

	SELECT 
		*
	FROM
		WOPO
	WHERE
		WONumber = @WONumber
	ORDER BY
		POIDs;

GO

