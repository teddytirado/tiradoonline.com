IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_ServiceReport_close' AND TYPE = 'P')
	DROP PROCEDURE sp_ServiceReport_close;
GO


CREATE PROCEDURE sp_ServiceReport_close
	@ServiceReportNumber	VARCHAR(10),
	@SalesID			VARCHAR(10)
AS
		UPDATE ServiceReport SET
			Status = 0,
			close_by = @SalesID,
			close_dt = GETDATE() 
		WHERE 
			ServiceReportNumber = @ServiceReportNumber;

GO

--EXEC sp_ServiceReport_close 992