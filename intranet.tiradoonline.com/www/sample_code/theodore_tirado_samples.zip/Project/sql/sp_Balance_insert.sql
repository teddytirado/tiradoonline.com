ALTER PROCEDURE sp_Balance_insert
	@BalanceAccountID		INT, 
	@BalanceDate			SMALLDATETIME, 
	@TransactionID			INT, 
	@Comment			VARCHAR(255), 
	@Payment			NUMERIC(8,2)
AS
	
	INSERT INTO Balance
		(BalanceAccountID, BalanceDate, TransactionID, Comment, Payment, update_dt) 
	VALUES 
		(@BalanceAccountID, @BalanceDate, @TransactionID, @Comment, @Payment, GETDATE());

	SELECT @@IDENTITY;
GO
