ALTER PROCEDURE sp_Reminders_update
	@UserID		INT,
	@ReminderDate	SMALLDATETIME,
	@ReminderDesc	VARCHAR(255)
AS

	UPDATE Reminders
		SET ReminderDesc = @ReminderDesc
	WHERE 
		UserID = @UserID AND
		ReminderDate = @ReminderDate
GO