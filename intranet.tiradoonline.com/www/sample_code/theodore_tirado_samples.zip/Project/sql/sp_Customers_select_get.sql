IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Customers_select_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Customers_select_get;
GO


CREATE PROCEDURE sp_Customers_select_get
	@SalesID		NVARCHAR(50),
	@UserType		TINYINT
AS
	
	IF @UserType > 0
		BEGIN
			SELECT 
				* 
			FROM 
				MISINC..ARCUS
			ORDER BY 
				IDCUST;

		END
	ELSE
		BEGIN
			SELECT 
				* 
			FROM 
				MISINC..ARCUS
			WHERE 
				LEFT(IDCUST, 2) IN (SELECT 
							'SalesID' =
							   CASE 
							   	WHEN LEN(SalesID) < 2 THEN '0' + SalesID
						           END
						    FROM 
							SalesAssistants 
						    WHERE 
							AssistantSalesID = @SalesID

						    UNION
							SELECT SalesID FROM Userz WHERE SalesID = @SalesID)
			ORDER BY 
				IDCUST;
		END


GO


EXEC sp_Customers_select_get '46', 0