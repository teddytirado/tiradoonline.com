IF EXISTS (SELECT NAME FROM SYSOBJECTS WHERE NAME = 'sp_BalanceAccountsLinked_get' AND TYPE = 'P')
         DROP PROCEDURE sp_BalanceAccountsLinked_get;

GO

CREATE PROCEDURE sp_BalanceAccountsLinked_get
         @BalanceAccountID              INT
AS

	SELECT
		BalanceAccountsLinkedID,
		Email
	FROM
		BalanceAccountsLinked
	WHERE
		BalanceAccountID = @BalanceAccountID		
	ORDER BY
		Email
GO

 

EXEC sp_BalanceAccountsLinked_get 1014

 