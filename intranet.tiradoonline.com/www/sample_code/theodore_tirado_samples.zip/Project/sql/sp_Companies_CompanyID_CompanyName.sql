ALTER PROCEDURE sp_Companies_CompanyID_CompanyName
	@UserID		INT
AS
	SELECT CompanyID, CompanyName FROM Companies WHERE UserID = @UserID ORDER BY CompanyName
GO
