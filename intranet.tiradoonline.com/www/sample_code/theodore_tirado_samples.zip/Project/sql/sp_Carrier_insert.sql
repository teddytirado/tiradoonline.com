IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Carrier_insert' AND TYPE = 'P')
	DROP PROCEDURE sp_Carrier_insert;
GO


CREATE PROCEDURE sp_Carrier_insert
	@CarrierAbb		NVARCHAR(50),
	@CarrierName		NVARCHAR(50),
	@DSType			NVARCHAR(50)
AS

	INSERT INTO Carrier
		(CarrierAbb, CarrierName, DSType)
	VALUES
		(@CarrierAbb, @CarrierName, @DSType);
	
GO

--EXEC sp_Carrier_insert;

