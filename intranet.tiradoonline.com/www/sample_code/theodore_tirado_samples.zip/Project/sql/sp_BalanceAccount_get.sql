ALTER PROCEDURE sp_BalanceAccount_get
	@UserID 		INT
AS
	
	
	SELECT 
		BalanceAccountID,
		BalanceAccountName
	INTO
		#BalanceAccounts
	FROM
		BalanceAccounts
	WHERE
		UserID = @UserID AND
		Active = 1
	ORDER BY
		BalanceAccountName;
	
	ALTER TABLE #BalanceAccounts ADD TotalBalance NUMERIC(9,2) NULL;	

	UPDATE
		#BalanceAccounts
	SET
		TotalBalance = (SELECT ISNULL(SUM(a.Payment), 0) FROM Balance a WHERE 
					BalanceAccountID = #BalanceAccounts.BalanceAccountID OR
					SubBalanceAccountID = #BalanceAccounts.BalanceAccountID);
					-- OR
					--#BalanceAccounts.BalanceAccountID IN (SELECT BalanceAccountID FROM Balance WHERE BalanceAccountID = #BalanceAccounts.BalanceAccountID) OR
					--#BalanceAccounts.BalanceAccountID IN (SELECT BalanceAccountID FROM Balance c WHERE SubBalanceAccountID = a.BalanceAccountID) OR

	SELECT
		* 
	FROM 
		#BalanceAccounts;
	--UPDATE Balance
		--SET 

GO

EXEC sp_BalanceAccount_get 1001
