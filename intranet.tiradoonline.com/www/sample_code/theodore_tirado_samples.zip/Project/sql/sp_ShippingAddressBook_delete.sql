IF EXISTS (SELECT NAME FROM SYSOBJECTS WHERE NAME = 'sp_ShippingAddressBook_delete' AND TYPE = 'P')
	DROP PROCEDURE sp_ShippingAddressBook_delete;
GO


CREATE PROCEDURE sp_ShippingAddressBook_delete
	@ShippingAddressBookID		INT
AS
	DELETE FROM ShippingAddressBook WHERE ShippingAddressBookID = @ShippingAddressBookID;
GO

--EXEC sp_ShippingAddressBook_delete '999', 1001 
