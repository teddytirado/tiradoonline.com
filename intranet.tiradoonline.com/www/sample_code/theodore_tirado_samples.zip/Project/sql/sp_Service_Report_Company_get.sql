
IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Service_Report_Search' AND TYPE = 'P')
	DROP PROCEDURE sp_Service_Report_Search;
GO


CREATE PROCEDURE sp_Service_Report_Search
	@Company 		NVARCHAR(50) = NULL,
	@ServiceReportNumber	INT,
	@RepairYear 		INT,
	@SearchBy		VARCHAR(20)
AS
	IF @SearchBy = 'Company' 
		BEGIN
			IF @Company IS NULL
				BEGIN
					SELECT 
						DISTINCT a.Company,
						COUNT(*) AS ServiceReportsTotal,
						LastServiceReportDate = (SELECT TOP 1 RepairDate FROM ServiceReport WHERE Company = a.Company ORDER BY RepairDate DESC)
					FROM 
						ServiceReport a
					WHERE 
						DATEPART("year", RepairDate) >= @RepairYear
					GROUP BY 
						a.Company
					ORDER BY 
						a.Company;
				END
			ELSE
				BEGIN
					SET @Company = '%' + UPPER(@Company) + '%';
		
					SELECT 
						DISTINCT a.Company,
						COUNT(*) AS ServiceReportsTotal,
						LastServiceReportDate = (SELECT TOP 1 RepairDate FROM ServiceReport WHERE Company = a.Company ORDER BY RepairDate DESC)
					FROM 
						ServiceReport a
					WHERE 
						UPPER(a.Company) LIKE @Company AND
						DATEPART("year", RepairDate) >= @RepairYear
					GROUP BY 
						a.Company
					ORDER BY 
						a.Company;
	
		
			
				END
		END
	ELSE IF @SearchBy = 'ServiceReportNumber'
		BEGIN
			SELECT 
				*
			FROM 
				ServiceReport
			WHERE 
				ServiceReportNumber = @ServiceReportNumber
	
		END
		
GO

exec sp_Service_Report_Search 'soc', 1234567, 2005, 'ServiceReportNumber'