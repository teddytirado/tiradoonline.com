IF EXISTS (SELECT NAME FROM SYSOBJECTS WHERE NAME = 'sp_BalanceAccountsLinked_delete' AND TYPE = 'P')
         DROP PROCEDURE sp_BalanceAccountsLinked_delete;

GO

CREATE PROCEDURE sp_BalanceAccountsLinked_delete
        @BalanceAccountsLinkedID              	INT
AS

	DELETE FROM BalanceAccountsLinked WHERE @BalanceAccountsLinkedID = BalanceAccountsLinkedID;

GO

 

--EXEC sp_BalanceAccountsLinked_delete 1014

 