ALTER PROCEDURE sp_Balance_UserID_BalanceDate_email
	@BalanceAccountID		INT,
	@BalanceDate			SMALLDATETIME
AS

	SELECT TOP 20
		a.BalanceID, 
		a.BalanceDate, 
		a.BankDate,
		a.Payment, 
		a.Comment, 
		b.Description
	FROM 
		Balance a, Transactions b
	WHERE
		--DATEPART(month, a.BalanceDate) = MONTH(@BalanceDate) AND 
		--DATEPART(year, a.BalanceDate) = YEAR(@BalanceDate) AND 
		a.TransactionID = b.TransactionID AND
		a.BalanceAccountID = @BalanceAccountID
	ORDER BY
		a.BalanceDate DESC
GO

EXEC sp_Balance_UserID_BalanceDate_email 1023, '6/20/05'