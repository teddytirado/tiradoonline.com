IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_CreditMemo_get' AND TYPE = 'P')
	DROP PROCEDURE sp_CreditMemo_get;
GO


CREATE PROCEDURE sp_CreditMemo_get
	@CreditMemoNumber 		VARCHAR(20) = NULL

AS

	IF @CreditMemoNumber = NULL
		BEGIN 
			SELECT
				CreditMemoNumber,
				CreditMemoDate,
				ReferenceNumber,
				ServiceReportNumber,
				PartNumber,
				PartDescription,
				Claim,
				VendorID,
				LaborReimbursement,
				LaborAmount,
				CheckNumber,
				PaidAmount,
				PaidDate,
				Status,
				Notes,
				close_by = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = CreditMemo.closed_by COLLATE SQL_Latin1_General_CP1_CI_AS),
				close_dt = closed_dt,
				update_by = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = CreditMemo.update_by COLLATE SQL_Latin1_General_CP1_CI_AS),
				update_dt,
				create_by = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = CreditMemo.create_by COLLATE SQL_Latin1_General_CP1_CI_AS),
				create_dt
			FROM 	
				CreditMemo
			ORDER BY
				CreditMemoNumber DESC
		END			
	ELSE
		BEGIN
			SELECT
				CreditMemoNumber,
				CreditMemoDate,
				ReferenceNumber,
				ServiceReportNumber,
				PartNumber,
				PartDescription,
				Claim,
				VendorID,
				LaborReimbursement,
				LaborAmount,
				CheckNumber,
				PaidAmount,
				PaidDate,
				Status,
				Notes,
				close_by = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = CreditMemo.closed_by COLLATE SQL_Latin1_General_CP1_CI_AS),
				close_dt = closed_dt,
				update_by = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = CreditMemo.update_by COLLATE SQL_Latin1_General_CP1_CI_AS),
				update_dt,
				create_by = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = CreditMemo.create_by COLLATE SQL_Latin1_General_CP1_CI_AS),
				create_dt
			FROM 	
				CreditMemo
			WHERE
				CreditMemoNumber = @CreditMemoNumber;
		END			

GO



EXEC sp_CreditMemo_get 234