ALTER PROCEDURE sp_BalanceAccount_SubBalanceAccountID_get
	@UserID				INT,
	@BalanceAccountID		INT
AS

	SELECT
		BalanceAccountID,
		BalanceAccountName
	FROM 
		BalanceAccounts
	WHERE
		UserID = @UserID AND
		BalanceAccountID <> @BalanceAccountID AND
		Active = 1
	ORDER BY
		BalanceAccountName;
GO

EXEC sp_BalanceAccount_SubBalanceAccountID_get 1001, 1014
