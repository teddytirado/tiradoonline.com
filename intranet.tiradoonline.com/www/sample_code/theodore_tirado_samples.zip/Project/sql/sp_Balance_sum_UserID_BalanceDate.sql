ALTER PROCEDURE sp_Balance_sum_UserID_BalanceDate
	@BalanceAccountID		INT,
	@BalanceDate			SMALLDATETIME
AS

	SELECT 
		PreviousBalance = (SELECT ISNULL(SUM(Payment), 0) FROM Balance WHERE BalanceDate < @BalanceDate AND BalanceAccountID = @BalanceAccountID)
		TotalBalance = (SELECT ISNULL(SUM(Payment), 0) FROM Balance WHERE DATEPART(BalanceDate <= @BalanceDate AND BalanceAccountID = @BalanceAccountID)
GO

EXEC sp_Balance_sum_UserID_BalanceDate 1014, '10/1/2011';
