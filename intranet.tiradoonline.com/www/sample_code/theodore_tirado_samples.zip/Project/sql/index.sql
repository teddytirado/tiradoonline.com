/*
ALTER DATABASE Intranet 
ADD FILE 
(
 NAME = Intranet_idx,
 FILENAME = 'D:\www\intranet\data\Intranet.ndf',
 SIZE = 20MB,
 MAXSIZE = 100MB,
 FILEGROWTH = 5MB
)
*/

IF EXISTS (SELECT NAME FROM SYSINDEXES WHERE NAME = 'idx_PageLogs_SalesID') 
	DROP INDEX PageLogs.idx_PageLogs_SalesID;
GO
IF EXISTS (SELECT NAME FROM SYSINDEXES WHERE NAME = 'idx_PageLogs_QUERY_STRING') 
	DROP INDEX PageLogs.idx_PageLogs_QUERY_STRING;
GO
IF EXISTS (SELECT NAME FROM SYSINDEXES WHERE NAME = 'idx_PageLogs_FORM') 
	DROP INDEX PageLogs.idx_PageLogs_FORM;
GO

USE Intranet;
GO

CREATE INDEX idx_PageLogs_SalesID ON PageLogs (SalesID);
CREATE INDEX idx_PageLogs_QUERY_STRING ON PageLogs (QUERY_STRING);
CREATE INDEX idx_PageLogs_FORM ON PageLogs (FORM);


