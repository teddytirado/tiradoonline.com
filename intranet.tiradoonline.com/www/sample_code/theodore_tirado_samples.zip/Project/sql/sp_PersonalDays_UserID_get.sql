ALTER PROCEDURE sp_PersonalDays_UserID_get
	@UserID		INT
AS
	SELECT 
		a.PersonalDayID,
		b.CompanyID, 
		b.CompanyName, 
		a.PersonalDate 
	FROM 
		Personaldays a, 
		Companies b 
	WHERE 
		a.CompanyID = b.CompanyID AND 
		b.UserID = @UserID
	ORDER BY 
		a.PersonalDate DESC, 
		b.CompanyName
GO
