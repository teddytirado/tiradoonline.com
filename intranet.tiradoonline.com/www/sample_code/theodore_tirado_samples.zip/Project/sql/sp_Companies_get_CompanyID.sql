ALTER PROCEDURE sp_Companies_get_CompanyID
	@CompanyID	INT
AS
	SELECT 
		CompanyID, 
		CompanyName,
		StartDate,
		EndDate
	FROM 
		Companies 
	WHERE 
		CompanyID = @CompanyID

