IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Quote_PDF' AND TYPE = 'P')
	DROP PROCEDURE sp_Quote_PDF;
GO


CREATE PROCEDURE sp_Quote_PDF
	@QID			INT
AS

	SELECT
		a.*,
		SalesPerson = b.FirstName + ' ' + b.LastName,
		TaxRate = a.WOTaxRate,
		CustomerName = (SELECT NAMECUST FROM MISINC..ARCUS WHERE IDCUST = a.WOCustomer COLLATE SQL_Latin1_General_CP1_CI_AS)

	FROM
		Quote a,
		Userz b
	WHERE
		a.SPNumber = b.SalesID COLLATE SQL_Latin1_General_CP1_CI_AS AND
		a.QID = @QID;

GO

exec sp_Quote_PDF 19731

