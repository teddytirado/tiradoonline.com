IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_ServiceReport_ModelNumber_get' AND TYPE = 'P')
	DROP PROCEDURE sp_ServiceReport_ModelNumber_get;
GO


CREATE PROCEDURE sp_ServiceReport_ModelNumber_get
	@ModelNumber		NVARCHAR(50),
	@StartDate		DATETIME,
	@EndDate		DATETIME,
	@SortBy			VARCHAR(30)
AS

	SET NOCOUNT ON;
	DECLARE @SQL_STRING VARCHAR(1000);

	SET @SQL_STRING = 'SELECT 
		a.ServiceReportNumber,
		Customer = (SELECT Company FROM Companies WHERE CompanyID = b.CompanyID),

		RepairDate = (SELECT TOP 1 RepairDate FROM DateServicePerformed WHERE ServiceReportNumber = a.ServiceReportNumber ORDER BY RepairDate DESC),
		Service_Date = b.ServiceDate
	FROM
		ServicedSerialNumbers a,
		ServiceReport b
	WHERE
		a.ServiceReportNumber = b.ServiceReportNumber AND
		a.ModelNumber = ''' + @ModelNumber + '''
	ORDER BY 
		' + @SortBy;

	--PRINT @SQL_STRING;
	EXEC(@SQL_STRING);
GO



--select * from ServiceReport WHERE ServiceReportNumber = '32071'

--SELECT * FROM ServicedSerialNumbers WHERE ModelNumber = 'HP 2200';

sp_ServiceReport_ModelNumber_get 'HP LJ 4345', '1/1/2005', '10/12/2010', 'RepairDate DESC' 