CREATE PROCEDURE sp_ExecutedSQLScripts_insert
	@ExecutedSQLScript	VARCHAR(1000)
AS
	
	INSERT INTO ExecutedSQLScripts
		(ExecutedSQLScript)
	VALUES
		(@ExecutedSQLScript);

