ALTER PROCEDURE sp_Snippets_insert
	@SnippetGroupID		INT,
	@SnippetName		VARCHAR(30),
	@Snippet		VARCHAR(8000)
AS
	INSERT INTO Snippets 
		(SnippetGroupID, SnippetName, Snippet) 
	VALUES 
		(@SnippetGroupID, @SnippetName, @Snippet);

	SELECT @@IDENTITY
