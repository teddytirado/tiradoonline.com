ALTER PROCEDURE sp_Snippets_get
	@SnippetGroupID		INT
AS
	SELECT 
		SnippetID,
		SnippetName,
		Snippet
	FROM 
		Snippets
	WHERE
		SnippetGroupID = @SnippetGroupID
	ORDER BY
		SnippetName;

