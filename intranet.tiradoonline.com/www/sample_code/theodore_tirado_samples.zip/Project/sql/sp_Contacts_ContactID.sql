ALTER PROCEDURE sp_Contacts_ContactID
	@ContactID		INT
AS

	SELECT 
		ContactGroupID, FirstName, LastName, Company, Title, Email1, Email2,
		Address1, Address2, City, StateID, ZipCode, Phone, 
		WorkPhone, Pager, CellPhone, FaxNumber, Website, Comments
	FROM 
		Contacts 
	WHERE 
		ContactID = @ContactID
GO
