select 
	object_name(a.id) TableName, 
	a.name,
	c.name, 
	b.uid, 
	a.* 
from 
	sysindexes a,
	sysobjects b,
	sysfiles c
where 
	b.uid = USER_ID() and
	a.id = b.id and
	a.groupid = c.groupid and
	left(a.name, 4) = 'idx_' and
	left(object_name(a.id), 3) <> 'sys' and 
	left(object_name(a.id), 2) <> 'dt'
order by
	object_name(a.id)

