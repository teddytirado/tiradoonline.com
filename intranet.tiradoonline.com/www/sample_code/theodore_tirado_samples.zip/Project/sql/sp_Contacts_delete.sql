ALTER PROCEDURE sp_Contacts_delete
	@ContactID		INT
AS

	DELETE FROM Contacts WHERE ContactID = @ContactID;
GO