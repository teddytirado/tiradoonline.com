IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Companies_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Companies_get;
GO


CREATE PROCEDURE sp_Companies_get
AS

	SELECT
		CompanyID,
		CompanyName,
		Address1,
		City,
		StateID,
		ZipCode,
		create_by,
		create_dt
	FROM
		Companies
	ORDER BY
		CompanyName

GO

EXEC sp_Companies_get