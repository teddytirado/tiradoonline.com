select * from APTCP WHERE cntbtch ='4527' AND IDVEND = 'ADP1000' AND AMTPAYM = '300.000' order by audtdate desc
select * from APTCP WHERE cntbtch ='4527' AND IDVEND = 'ADP1000' AND AMTPAYM = '18.000' order by audtdate desc
select * from APTCP WHERE cntbtch ='4527' AND IDVEND = 'ADP1000' AND AMTPAYM = '7.000' order by audtdate desc
select * from APTCP WHERE cntbtch ='4527' AND IDVEND = 'ADP1000' AND AMTPAYM = '187.640' order by audtdate desc

UPDATE APTCP set cntrmit = 12 WHERE cntbtch ='4527' AND IDVEND = 'ADP1000' AND AMTPAYM = '300.000'
UPDATE APTCP set cntrmit = 12 WHERE cntbtch ='4527' AND IDVEND = 'ADP1000' AND AMTPAYM = '18.000' 
UPDATE APTCP set cntrmit = 12 WHERE cntbtch ='4527' AND IDVEND = 'ADP1000' AND AMTPAYM = '7.000' 
UPDATE APTCP set cntrmit = 12 WHERE cntbtch ='4527' AND IDVEND = 'ADP1000' AND AMTPAYM = '187.640' 
select * from APTCP WHERE cntbtch ='4527' AND IDVEND = 'ADP1000' AND AMTPAYM = '300.000' order by audtdate desc
select * from APTCP WHERE cntbtch ='4527' AND IDVEND = 'ADP1000' AND AMTPAYM = '18.000' order by audtdate desc
select * from APTCP WHERE cntbtch ='4527' AND IDVEND = 'ADP1000' AND AMTPAYM = '7.000' order by audtdate desc
select * from APTCP WHERE cntbtch ='4527' AND IDVEND = 'ADP1000' AND AMTPAYM = '187.640' order by audtdate desc

