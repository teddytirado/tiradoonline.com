IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_DateServicePerformed_ServiceReportNumber_get' AND TYPE = 'P')
	DROP PROCEDURE sp_DateServicePerformed_ServiceReportNumber_get;
GO


CREATE PROCEDURE sp_DateServicePerformed_ServiceReportNumber_get
	@ServiceReportNumber	NVARCHAR(10)
AS

	SELECT 
		DateServicePerformedID,
		ServiceReportNumber,
		RepairDate,
		RepairStartTime,
		RepairEndTime
	FROM	
		DateServicePerformed
	WHERE
		ServiceReportNumber = @ServiceReportNumber
	ORDER BY
		create_dt
	

GO

