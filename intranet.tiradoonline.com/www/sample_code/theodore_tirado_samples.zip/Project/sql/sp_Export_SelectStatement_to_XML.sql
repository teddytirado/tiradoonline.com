IF EXISTS (SELECT NAME FROM SYSOBJECTS WHERE NAME = 'sp_Export_SelectStatement_to_XML' AND TYPE = 'P')
	DROP PROCEDURE sp_Export_SelectStatement_to_XML;
GO


CREATE PROCEDURE sp_Export_SelectStatement_to_XML
	@SelectStatement		VARCHAR(200)
AS
	
	SET @SelectStatement = @SelectStatement + ' FOR XML AUTO'; 
	EXEC(@SelectStatement);

GO

EXEC sp_Export_SelectStatement_to_XML 'select * from Userz'
