USE MASTER
GO
EXEC ("xp_cmdshell 'MKDIR c:\data', NO_OUTPUT")
GO
IF EXISTS (SELECT Name FROM SYSDATABASES WHERE LOWER(Name) = '%%%DatabaseName%%%')
	DROP DATABASE %%%DatabaseName%%%
GO

CREATE DATABASE %%%DatabaseName%%% ON
(
	NAME 		= %%%DatabaseName%%%_dat,
	FILENAME 	= 'c:\data\%%%DatabaseName%%%_Data.MDF',
	SIZE 		= 10,
	MAXSIZE		= UNLIMITED,
	FILEGROWTH	= 1
)
LOG ON
(
	NAME 		= %%%DatabaseName%%%_log,
	FILENAME 	= 'c:\data\%%%DatabaseName%%%_Log.LDF',
	SIZE 		= 10,
	MAXSIZE		= UNLIMITED,
	FILEGROWTH	= 1
)
GO
USE %%%DatabaseName%%%
GO
if exists (select * from sysobjects where id = object_id('FK_Balance_Transactions'))
	ALTER TABLE Balance 			DROP CONSTRAINT FK_Balance_Transactions
if exists (select * from sysobjects where id = object_id('FK_AddressBook_Users'))
	ALTER TABLE AddressBook 		DROP CONSTRAINT FK_AddressBook_Users
if exists (select * from sysobjects where id = object_id('FK_Balance_Users'))
	ALTER TABLE Balance 			DROP CONSTRAINT FK_Balance_Users
if exists (select * from sysobjects where id = object_id('FK_Bills_Users'))
	ALTER TABLE Bills				DROP CONSTRAINT FK_Bills_Users
if exists (select * from sysobjects where id = object_id('FK_Companies_Users'))
	ALTER TABLE Companies 			DROP CONSTRAINT FK_Companies_Users
if exists (select * from sysobjects where id = object_id('FK_CreditCard_Users'))
	ALTER TABLE CreditCard 			DROP CONSTRAINT FK_CreditCard_Users
if exists (select * from sysobjects where id = object_id('FK_Logins_Users'))
	ALTER TABLE Logins 				DROP CONSTRAINT FK_Logins_Users
if exists (select * from sysobjects where id = object_id('FK_Hours_Companies'))
	ALTER TABLE Hours 				DROP CONSTRAINT FK_Hours_Companies
if exists (select * from sysobjects where id = object_id('FK_Paychecks_Companies'))
	ALTER TABLE Paychecks 			DROP CONSTRAINT FK_Paychecks_Companies
if exists (select * from sysobjects where id = object_id('FK_CCBalance_CreditCard'))
	ALTER TABLE CCBalance 			DROP CONSTRAINT FK_CCBalance_CreditCard
GO


--**************************************
--**			TABLES				   *
--**************************************
if exists (select * from sysobjects where id = object_id('AddressBook') and OBJECTPROPERTY(id, 'IsUserTable') = 1)
	DROP TABLE AddressBook
	GO
	
	CREATE TABLE AddressBook
	(
		AddressBookID int IDENTITY (1, 1) NOT NULL,
		UserID int NOT NULL,
		FirstName varchar(30) NOT NULL,
		LastName varchar(30) NOT NULL,
		Email varchar(100) NOT NULL,
		Company varchar(30) NULL,
		Title varchar(30) NULL,
		HomeAddress1 varchar(100) NULL,
		HomeAddress2 varchar(100) NULL,
		HomeCity varchar(20) NULL,
		HomeState varchar(2) NULL,
		HomeZipCode int NULL,
		HomePhoneArea int NULL,
		HomePhoneNum1 int NULL,
		HomePhoneNum2 int NULL,
		BusinessAddress1 varchar(100) NULL,
		BusinessAddress2 varchar(100) NULL,
		BusinessCity varchar(50) NULL,
		BusinessState varchar(2) NULL,
		BusinessZipCode int NULL,
		BusinessPhoneArea int NULL,
		BusinessPhoneNum1 int NULL,
		BusinessPhoneNum2 int NULL,
		BusinessPhoneExt int NULL,
		PagerArea int NULL,
		PagerNum1 int NULL,
		PagerNum2 int NULL,
		PagerPin varchar(20) NULL,
		CellPhoneArea int NULL,
		CellPhoneNum1 int NULL,
		CellPhoneNum2 int NULL,
		FaxArea int NULL,
		FaxPhoneNum1 int NULL,
		FaxPhoneNum2 int NULL,
		Birthday smalldatetime NULL 
	)
GO

if exists (select * from sysobjects where id = object_id('Balance') and OBJECTPROPERTY(id, 'IsUserTable') = 1)
	DROP TABLE Balance
	GO

	CREATE TABLE Balance
	(
		BalanceID int IDENTITY (1, 1) NOT NULL,
		UserID int NOT NULL,
		TransactionID int NOT NULL,
		BalanceDate smalldatetime NOT NULL DEFAULT getdate(),
		Payment numeric(8, 2) NOT NULL DEFAULT 0,
		Comment varchar(255) NULL,
		update_dt smalldatetime NOT NULL DEFAULT getdate()
	)
GO

if exists (select * from sysobjects where id = object_id('Bills') and OBJECTPROPERTY(id, 'IsUserTable') = 1)
	DROP TABLE Bills
	GO

	CREATE TABLE Bills
	(
		BillID int IDENTITY (1000, 1) NOT NULL,
		UserID int NOT NULL,
		BillDay int NOT NULL,
		BillDesc text NOT NULL 
	)
GO

if exists (select * from sysobjects where id = object_id('CCBalance') and OBJECTPROPERTY(id, 'IsUserTable') = 1)
	DROP TABLE CCBalance
	GO

	CREATE TABLE CCBalance
	(
		CCBalanceID int IDENTITY (1000, 1) NOT NULL,
		CCID int NOT NULL,
		CCDate smalldatetime NOT NULL DEFAULT getdate(),
		CCDescription varchar(100) NOT NULL,
		CCPayment numeric(9, 2) NOT NULL DEFAULT 0,
		update_dt smalldatetime NOT NULL
	)
GO

if exists (select * from sysobjects where id = object_id('Companies') and OBJECTPROPERTY(id, 'IsUserTable') = 1)
	DROP TABLE Companies
	GO

	CREATE TABLE Companies
	(
		CompanyID int IDENTITY (1, 1) NOT NULL,
		UserID int NOT NULL,
		CompanyName varchar(30) NOT NULL 
	)
GO

if exists (select * from sysobjects where id = object_id('CreditCard') and OBJECTPROPERTY(id, 'IsUserTable') = 1)
	DROP TABLE CreditCard
	GO

	CREATE TABLE CreditCard
	(
		CCID int IDENTITY (1000, 1) NOT NULL,
		UserID int NOT NULL,
		CCName varchar(20) NOT NULL,
		CCLimit numeric(9,2) NOT NULL,
		CCExpiration smalldatetime NOT NULL
	)
GO

if exists (select * from sysobjects where id = object_id('Hours') and OBJECTPROPERTY(id, 'IsUserTable') = 1)
	DROP TABLE Hours
	GO

	CREATE TABLE Hours
	(
		HoursID int IDENTITY (1001, 1) NOT NULL,
		CompanyID int NOT NULL,
		WorkDate datetime NOT NULL DEFAULT getdate(),
		StartHour numeric(4, 1) NOT NULL DEFAULT 0,
		EndHour numeric(4, 1) NULL DEFAULT 0,
		LunchHour numeric(4, 3) NULL DEFAULT 0
	)
GO

if exists (select * from sysobjects where id = object_id('Logins') and OBJECTPROPERTY(id, 'IsUserTable') = 1)
	DROP TABLE Logins
	GO

	CREATE TABLE Logins
	(
		LoginID int IDENTITY (1, 1) NOT NULL,
		UserID int NOT NULL,
		LoginDate smalldatetime NOT NULL DEFAULT getdate(),
		Browser varchar(100) NULL,
		IPAddress varchar(15) NOT NULL 
	)
GO

if exists (select * from sysobjects where id = object_id('Logs') and OBJECTPROPERTY(id, 'IsUserTable') = 1)
	DROP TABLE Logs
	GO

	CREATE TABLE Logs
	(
		LogID int IDENTITY (1, 1) NOT NULL,
		LogDate smalldatetime NOT NULL,
		LogDesc text NULL 
	) 
GO

if exists (select * from sysobjects where id = object_id('Paychecks') and OBJECTPROPERTY(id, 'IsUserTable') = 1)
	DROP TABLE Paychecks
	GO

	CREATE TABLE Paychecks
	(
		PaycheckID int IDENTITY (1001, 1) NOT NULL,
		CompanyID int NOT NULL,
		PaymentDate datetime NOT NULL DEFAULT getdate(),
		HourlyRate numeric(18, 2) NOT NULL DEFAULT 0,
		Gross numeric(18, 2) NOT NULL DEFAULT 0,
		Federal numeric(18, 2) NULL DEFAULT 0,
		SocialSecurity numeric(18, 2) NULL DEFAULT 0,
		Medicare numeric(18, 2) NULL DEFAULT 0,
		NY_Withholding numeric(18, 2) NULL DEFAULT 0,
		NY_Disability numeric(18, 2) NULL DEFAULT 0,
		NY_City numeric(18, 2) NULL DEFAULT 0 
	)
GO

if exists (select * from sysobjects where id = object_id('Transactions') and OBJECTPROPERTY(id, 'IsUserTable') = 1)
	DROP TABLE Transactions
	GO

	CREATE TABLE Transactions
	(
		TransactionID int IDENTITY (1001, 1) NOT NULL,
		TransactionType tinyint NOT NULL,
		Description varchar(30) NOT NULL 
	)
GO

if exists (select * from sysobjects where id = object_id('Users') and OBJECTPROPERTY(id, 'IsUserTable') = 1)
	DROP TABLE Backups;

CREATE TABLE Backups
(
	BackupID	INT IDENTITY(1001, 1) NOT NULL,
	UserID	INT NOT NULL,
	BackupDate	SMALLDATETIME NOT NULL DEFAULT getdate()
);

if exists (select * from sysobjects where id = object_id('Users') and OBJECTPROPERTY(id, 'IsUserTable') = 1)
	DROP TABLE Users
	GO

	CREATE TABLE Users
	(
		UserID int IDENTITY (1, 1) NOT NULL,
		UserName varchar(10) NOT NULL,
		Password varchar(10) NOT NULL,
		FirstName varchar(30) NOT NULL,
		LastName varchar(30) NOT NULL,
		Administrator int NOT NULL,
		Email varchar(50) NOT NULL,
		HourlyRate numeric(18, 2) NULL DEFAULT 0,
		SendReports smallint NULL DEFAULT 0,
		Update_by varchar(10) NOT NULL DEFAULT getdate(),
		Update_dt smalldatetime NOT NULL DEFAULT getdate(),
		create_dt smalldatetime NOT NULL DEFAULT getdate() 
	)
GO



--**************************************
--**			PRIMARY KEYS           *
--**************************************
ALTER TABLE AddressBook		ADD CONSTRAINT PK_AddressBook 				PRIMARY KEY NONCLUSTERED (AddressBookID)
ALTER TABLE Balance			ADD CONSTRAINT PK_Balance	 				PRIMARY KEY NONCLUSTERED (BalanceID)
ALTER TABLE Bills 			ADD CONSTRAINT PK_Bills 					PRIMARY KEY NONCLUSTERED (BillID)
ALTER TABLE CCBalance 		ADD CONSTRAINT PK_CCBalance 				PRIMARY KEY NONCLUSTERED (CCBalanceID)
ALTER TABLE Companies 		ADD CONSTRAINT PK_Companies 				PRIMARY KEY NONCLUSTERED (CompanyID)
ALTER TABLE CreditCard 		ADD CONSTRAINT PK_CreditCard 				PRIMARY KEY NONCLUSTERED (CCID)
ALTER TABLE Hours 			ADD CONSTRAINT PK_Hours 					PRIMARY KEY NONCLUSTERED (HoursID)
ALTER TABLE Logins 			ADD CONSTRAINT PK_Logins 					PRIMARY KEY NONCLUSTERED (LoginID)
ALTER TABLE Logs 			ADD CONSTRAINT PK_Logs 						PRIMARY KEY NONCLUSTERED (LogID)
ALTER TABLE Paychecks 		ADD CONSTRAINT PK_Payments 					PRIMARY KEY NONCLUSTERED (PaycheckID)
ALTER TABLE Transactions	ADD CONSTRAINT PK_Transactions 				PRIMARY KEY NONCLUSTERED (TransactionID)
ALTER TABLE Backups 		ADD CONSTRAINT PK_Backups 					PRIMARY KEY NONCLUSTERED (BackupID);
ALTER TABLE Users			ADD CONSTRAINT PK_Users 					PRIMARY KEY NONCLUSTERED (UserID)
GO


--**************************************
--**			FOREIGN KEYS           *
--**************************************
ALTER TABLE AddressBook 	ADD CONSTRAINT FK_AddressBook_Users 		FOREIGN KEY (UserID) 			REFERENCES Users (UserID)
ALTER TABLE Balance 		ADD CONSTRAINT FK_Balance_Transactions 		FOREIGN KEY (TransactionID) 	REFERENCES Transactions (TransactionID)
ALTER TABLE Balance 		ADD CONSTRAINT FK_Balance_Users 			FOREIGN KEY (UserID) 			REFERENCES Users (UserID)
ALTER TABLE Bills 			ADD CONSTRAINT FK_Bills_Users 				FOREIGN KEY (UserID) 			REFERENCES Users (UserID)
ALTER TABLE Companies 		ADD CONSTRAINT FK_Companies_Users 			FOREIGN KEY (UserID) 			REFERENCES Users (UserID)
ALTER TABLE CreditCard 		ADD CONSTRAINT FK_CreditCard_Users 			FOREIGN KEY (UserID) 			REFERENCES Users (UserID)
ALTER TABLE Logins 			ADD CONSTRAINT FK_Logins_Users 				FOREIGN KEY (UserID) 			REFERENCES Users (UserID)
ALTER TABLE CCBalance 		ADD CONSTRAINT FK_CCBalance_CreditCard 		FOREIGN KEY (CCID) 				REFERENCES CreditCard (CCID)
ALTER TABLE Hours 			ADD CONSTRAINT FK_Hours_Companies 			FOREIGN KEY (CompanyID) 		REFERENCES Companies (CompanyID)
ALTER TABLE Paychecks 		ADD CONSTRAINT FK_Paychecks_Companies 		FOREIGN KEY (CompanyID) 		REFERENCES Companies (CompanyID)
ALTER TABLE Backups 		ADD CONSTRAINT FK_Backups 					FOREIGN KEY (UserID) 			REFERENCES Users(UserID);
GO

--**************************************
--**			UNIQUE INDEXES         *
--**************************************
ALTER TABLE Users			ADD CONSTRAINT IX_Users 					UNIQUE NONCLUSTERED (UserName)
GO

--**************************************
--**			INDEXES                *
--**************************************
CREATE INDEX IDX_AddressBook_UserID 	ON AddressBook(UserID);
CREATE INDEX IDX_Backups_UserID  		ON Backups(UserID);
CREATE INDEX IDX_Balance_UserID  		ON Balance(UserID);
CREATE INDEX IDX_Balance_BalanceDate	ON Balance(BalanceDate);
CREATE INDEX IDX_Balance_TransactionID  ON Balance(TransactionID);
CREATE INDEX IDX_Bills_UserID  			ON Bills(UserID);
CREATE INDEX IDX_CCBalance_CCID  		ON CCBalance(CCID);
CREATE INDEX IDX_CCBalance_CCDate  		ON CCBalance(CCDate);
CREATE INDEX IDX_Companies_UserID  		ON Companies(UserID);
CREATE INDEX IDX_CreditCard_UserID  	ON CreditCard(UserID);
CREATE INDEX IDX_Hours_CompanyID  		ON Hours(CompanyID);
CREATE INDEX IDX_Hours_WorkDate  		ON Hours(WorkDate);
CREATE INDEX IDX_Logins_UserID  		ON Logins(UserID);
CREATE INDEX IDX_Logins_LoginDate  		ON Logins(LoginDate);
CREATE INDEX IDX_Logs_LogDate	  		ON Logs(LogDate);
CREATE INDEX IDX_Paychecks_CompanyID  	ON Paychecks(CompanyID);
CREATE INDEX IDX_Paychecks_PaymentDate  ON Paychecks(PaymentDate);
CREATE INDEX IDX_Users_UserName  		ON Users(UserName);
GO

--**********************************************
--**			STORED PROCEDURES              *
--**********************************************
if exists (select * from sysobjects where id = object_id('sp_DeleteUser') and OBJECTPROPERTY(id, 'IsProcedure') = 1)
	DROP PROCEDURE sp_DeleteUser
	GO

	CREATE PROCEDURE sp_DeleteUser
	@UserID			INT
	AS
		DELETE FROM Users WHERE UserID = @UserID
GO

if exists (select * from sysobjects where id = object_id('sp_Taxes') and OBJECTPROPERTY(id, 'IsProcedure') = 1)
	DROP PROCEDURE sp_Taxes
	GO
	
	CREATE PROCEDURE sp_Taxes
	AS
		DECLARE @FederalTax				NUMERIC(18,12)
		DECLARE @SocialSecurityTax		NUMERIC(18,12)
		DECLARE @MedicareTax			NUMERIC(18,12)
		DECLARE @NYStateTax				NUMERIC(18,12)
		DECLARE @NYCTax					NUMERIC(18,12)

		SELECT @FederalTax 				= .016801768607
		SELECT @SocialSecurityTax 		= .06200442152
		SELECT @MedicareTax 			= .01450257919
		SELECT @NYStateTax 				= .04347826087
		SELECT @NYCTax 					= .02840088430

		SELECT @FederalTax "FederalTax", 
			 @SocialSecurityTax "SocialSecurity", 
	 		 @MedicareTax "Medicare", 
			 @NYStateTax "NYStateTax", 
			 @NYCTax "NYCity"
GO

if exists (select * from sysobjects where id = object_id('sp_AddUser') and OBJECTPROPERTY(id, 'IsProcedure') = 1)
	DROP PROCEDURE sp_AddUser
	GO
	
	CREATE PROCEDURE sp_AddUser
	@UserName			VARCHAR(10),
	@Password			VARCHAR(10),
	@Administrator		INT,
	@FirstName			VARCHAR(20),
	@LastName			VARCHAR(20),
	@Email				VARCHAR(50),
	@UpdateBy			VARCHAR(10)
	AS
		BEGIN TRANSACTION
			INSERT INTO Users (UserName, Password, Administrator, FirstName, LastName, Email, HourlyRate, Create_dt, Update_by, Update_dt)
				VALUES
			(@UserName, @Password, @Administrator, @FirstName, @LastName, @Email, 0, getdate(), @UpdateBy, getdate())

			IF @@error > 0
				ROLLBACK TRANSACTION

			INSERT INTO TRANSACTIONS (DESCRIPTION) VALUES ('Transfer - ' + LOWER(@Username))
	
			IF @@error > 0
				ROLLBACK TRANSACTION
		COMMIT TRANSACTION
GO

if exists (select * from sysobjects where id = object_id('sp_CreditCardSum') and OBJECTPROPERTY(id, 'IsProcedure') = 1)
	DROP PROCEDURE sp_CreditCardSum
	GO

	CREATE PROCEDURE sp_CreditCardSum
	@CurrentDate		VARCHAR(20),
	@CCID			INT
	AS
		DECLARE @Counter			INT
		DECLARE @CCBalance		NUMERIC(9,2)
		DECLARE @CCPayment		NUMERIC(9,2)

		DECLARE CreditCard_cursor CURSOR FOR 
			SELECT a.CCPayment FROM CCBalance a, CreditCard b WHERE 
			a.CCDate < CONVERT(DATETIME, @CurrentDate) AND
			a.CCID = b.CCID AND b.CCID = @CCID

		SELECT @Counter = 1
		OPEN CreditCard_cursor
		FETCH NEXT FROM CreditCard_cursor INTO @CCPayment

		WHILE @@FETCH_STATUS = 0
			BEGIN
				IF @Counter = 1
					BEGIN
						SELECT @CCBalance = 0 - @CCPayment
					END
				ELSE
					BEGIN
						SELECT @CCBalance = @CCBalance - @CCPayment
					END
		
				PRINT @CCBALANCE	
				SELECT @Counter = @Counter + 1
				FETCH NEXT FROM CreditCard_cursor INTO @CCPayment
			END
	
		CLOSE CreditCard_cursor
		DEALLOCATE CreditCard_cursor

		SELECT TOTALSUM = @CCBalance
GO
