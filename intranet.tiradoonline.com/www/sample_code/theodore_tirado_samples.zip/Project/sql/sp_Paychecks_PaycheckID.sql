ALTER PROCEDURE sp_Paychecks_PaycheckID
	@PaycheckID		INT 
AS
	SELECT 
		CompanyID, 
		PaymentDate, 
		HourlyRate, 
		Gross, 
		Federal, 
		SocialSecurity, 
		Medicare, 
		NY_Withholding, 
		NY_Disability, 
		NY_City 
	FROM 
		Paychecks 
	WHERE 
		PaycheckID = @PaycheckID
GO
