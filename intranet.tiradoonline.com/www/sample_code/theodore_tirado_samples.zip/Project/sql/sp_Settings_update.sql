IF EXISTS (SELECT NAME FROM SYSOBJECTS WHERE NAME = 'sp_Settings_update' AND TYPE = 'P')
         DROP PROCEDURE sp_Settings_update;

GO

CREATE PROCEDURE sp_Settings_update
         @AdministratorEmail              VARCHAR(50)
AS


	UPDATE Settings SET
		AdministratorEmail = @AdministratorEmail;

GO

 

EXEC sp_Settings_update 'teddy@tiradoonline.com' 

EXEC sp_Settings_get;

 