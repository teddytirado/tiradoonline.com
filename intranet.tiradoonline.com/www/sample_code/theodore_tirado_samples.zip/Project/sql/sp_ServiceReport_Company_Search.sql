IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_ServiceReport_Company_Search' AND TYPE = 'P')
	DROP PROCEDURE sp_ServiceReport_Company_Search;
GO


CREATE PROCEDURE sp_ServiceReport_Company_Search
	@Company		NVARCHAR(50),
	@StartDate 		DATETIME,
	@EndDate 		DATETIME
AS

	SET NOCOUNT ON;

	/*********************/
	/* SEARCH BY COMPANY */
	/*********************/
	IF @Company IS NULL
		BEGIN
			SELECT 
				DISTINCT Customer AS Company,
				COUNT(*) AS ServiceReportsTotal,
				CompanyID
				--RepairDate = (SELECT a.RepairDate FROM vw_ServiceReport_Search a WHERE a.ServiceReportNumber = vw_ServiceReport_Search.ServiceReportNumber)
			INTO
				#tmp_ServiceReport
			FROM 
				vw_ServiceReport_Search
			WHERE 
				--CompanyID IS NOT NULL AND
				(RepairDate >= CONVERT(VARCHAR, @StartDate) AND
				RepairDate <= CONVERT(VARCHAR, @EndDate))
			GROUP BY 
				Customer,
				CompanyID
			ORDER BY 
				Customer
			/*
			SELECT 
				*,
				RepairDate = (SELECT TOP 1 RepairDate FROM vw_ServiceReport_Search WHERE ServiceReportNumber = #tmp_ServiceReport.ServiceReportNumber order by create_dt DESC)
			FROM 
				#tmp_ServiceReport
			*/
		END
	ELSE
		BEGIN
			SET @Company = '%' + UPPER(@Company) + '%';

			SELECT 
				DISTINCT Customer AS Company,
				COUNT(*) AS ServiceReportsTotal,
				CompanyID
				--RepairDate = (SELECT a.RepairDate FROM vw_ServiceReport_Search a WHERE a.ServiceReportNumber = vw_ServiceReport_Search.ServiceReportNumber)
			INTO
				#tmp_ServiceReport2
			FROM 
				vw_ServiceReport_Search
			WHERE 
				--CompanyID IS NOT NULL AND
				UPPER(Customer) LIKE @Company AND
				(RepairDate >= CONVERT(VARCHAR, @StartDate) AND
				RepairDate <= CONVERT(VARCHAR, @EndDate))
			GROUP BY 
				Customer,
				CompanyID
			ORDER BY 
				Customer;


			SELECT 
				*,
				RepairDate = (SELECT TOP 1 RepairDate FROM vw_ServiceReport_Search WHERE Company = #tmp_ServiceReport2.Company order by create_dt DESC)
			FROM 
				#tmp_ServiceReport2
			
		END
		


GO

EXEC sp_ServiceReport_Company_Search 'Waldorf', '1/1/2005', '10/15/2010'