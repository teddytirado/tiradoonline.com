ALTER PROCEDURE sp_administration_schema_type
	@ObjectType	VARCHAR(2)
AS
	SELECT 
		ID AS ObjectID,
		NAME AS ObjectName
	FROM 
		SYSOBJECTS
	WHERE 
		LEFT(NAME, 2) <> 'dt' AND 
		TYPE = @ObjectType AND
		USER_NAME(UID) = 'teddy_user'
	ORDER BY 
		NAME
GO
