IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Service_Report_update' AND TYPE = 'P')
	DROP PROCEDURE sp_Service_Report_update;
GO


CREATE PROCEDURE sp_Service_Report_update
	@ServiceReportNumber	INT,
	@CompanyID		INT,
	@SalesTax		VARCHAR(10),
	@RepairDate		DATETIME,
	@RepairStartTime	VARCHAR(10),
	@RepairEndTime		VARCHAR(10),
	@Remarks		NVARCHAR(2000),
	@Problems		NVARCHAR(2000),
	@Solutions		NVARCHAR(2000),
	@ServiceDate		DATETIME,
	@ServiceTime		VARCHAR(10),
	@Contract		BIT,
	@T_M			BIT,
	@Warranty		BIT,
	@OtherDescription	VARCHAR(100),
	@PONumber		NVARCHAR(50),
	@WorkOrderNumber	NVARCHAR(50),
	@LaborHours		REAL,
	@LaborRate		MONEY,
	@TravelHours		REAL,
	@MiscCharges		MONEY,
	@Shipping		MONEY,
	@Charge			BIT,
	@Freight		MONEY,
	@Contact		NVARCHAR(50),
	@Phone			NVARCHAR(11),
	@Ext			NVARCHAR(5),
	@LaborReimb		MONEY		
AS
	
	UPDATE [Service Report] SET
		CompanyID = @CompanyID,
		SalesTax = @SalesTax,
		[Repair Date] = @RepairDate,
		RepairStartTime = @RepairStartTime,
		RepairEndTime = @RepairEndTime,
		Remarks = @Remarks,
		Problems = @Problems,
		Solutions = @Solutions,
		ServiceDate = @ServiceDate,
		ServiceTime = @ServiceTime,
		Contract = @Contract,
		[T & M] = @T_M,
		Warranty = @Warranty,
		OtherDescription = @OtherDescription,
		[PO Number] = @PONumber,
		[WO Number] = @WorkOrderNumber,
		[Labor Hours] = @LaborHours,
		[Labor Rate] = @LaborRate,
		[Travel Hours] = @TravelHours,
		[Misc Charges] = @MiscCharges,
		Shipping = @Shipping,
		[Charge] = @Charge,
		Freight = @Freight,
		Contact = @Contact,
		Phone = @Phone,
		Ext = @Ext,
		[Labor Reimb] = @LaborReimb
	WHERE
		[Report Num] = @ServiceReportNumber;

GO

