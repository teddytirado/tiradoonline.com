ALTER PROCEDURE sp_Reminders_insert
	@UserID		INT,
	@ReminderDate	SMALLDATETIME,
	@ReminderDesc	VARCHAR(255)
AS

	INSERT INTO Reminders 
		(UserID, ReminderDate, ReminderDesc)
	VALUES
		(@UserID, @ReminderDate, @ReminderDesc);
GO