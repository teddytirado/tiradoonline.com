ALTER PROCEDURE sp_administration_execute
	@UserID		INT,
	@SQL		VARCHAR(2000)
AS
	EXEC(@SQL);
	EXEC sp_SQLScripts_insert @UserID, @SQL;
