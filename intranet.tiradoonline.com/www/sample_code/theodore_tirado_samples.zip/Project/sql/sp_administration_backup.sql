ALTER PROCEDURE sp_administration_backup
	@UserID	INT
AS
	BEGIN
		BACKUP DATABASE teddy TO teddy_dmp;
		BACKUP LOG teddy TO teddy_dmp;
		INSERT INTO Backups (UserID) VALUES (@UserID);
	END


go

exec teddy_user.sp_administration_backup 1001