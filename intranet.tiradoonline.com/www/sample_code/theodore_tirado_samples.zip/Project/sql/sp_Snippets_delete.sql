ALTER PROCEDURE sp_Snippets_delete
	@SnippetID	INT
AS
	DELETE FROM Snippets WHERE SnippetID = @SnippetID;
GO

