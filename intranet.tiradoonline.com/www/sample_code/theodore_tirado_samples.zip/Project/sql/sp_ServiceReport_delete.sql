IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_ServiceReport_delete' AND TYPE = 'P')
	DROP PROCEDURE sp_ServiceReport_delete;
GO


CREATE PROCEDURE sp_ServiceReport_delete
	@ServiceReportNumber	INT
AS
	BEGIN TRANSACTION TranDeleteServiceReport
		
		DELETE FROM DateServicePerformed WHERE ServiceReportNumber = CONVERT(NVARCHAR, @ServiceReportNumber);
		DELETE FROM ServicedSerialNumbers WHERE ServiceReportNumber = CONVERT(NVARCHAR, @ServiceReportNumber);
		DELETE FROM PurchaseOrderServicePrice WHERE ServiceReportNumber = CONVERT(NVARCHAR, @ServiceReportNumber);
		DELETE FROM CreditMemo WHERE ServiceReportNumber = CONVERT(NVARCHAR, @ServiceReportNumber);
		DELETE FROM ServiceReport WHERE ServiceReportNumber = @ServiceReportNumber;

	IF @@ERROR <> 0
		ROLLBACK TRAN TranDeleteServiceReport;
	ELSE
		COMMIT TRAN TranDeleteServiceReport;

GO

--EXEC sp_ServiceReport_delete 1234