sp_attach_db 'BalanceIntranet', 'C:\www\tiradoonline.com\balanceintranet.tiradoonline.com\database\BalanceIntranet.mdf', 'C:\www\tiradoonline.com\balanceintranet.tiradoonline.com\database\BalanceIntranet.ldf', 'C:\www\tiradoonline.com\balanceintranet.tiradoonline.com\database\BalanceIntranet.ndf'
select * from balanceintranet..sysusers

exec sp_addlogin 'balanceintranet_user', 'balanceintranet', 'BalanceIntranet', @sid = 0x44178F5E6921A94BA1307F3CC72A1632

