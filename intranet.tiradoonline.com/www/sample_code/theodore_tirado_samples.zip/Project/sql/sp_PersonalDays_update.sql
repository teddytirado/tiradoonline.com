ALTER PROCEDURE sp_PersonalDays_update
	@PersonalDayID	INT,
	@CompanyID	INT,
	@PersonalDate	SMALLDATETIME
AS
	UPDATE Personaldays SET
		CompanyID = @CompanyID,
		PersonalDate = @PersonalDate
	WHERE
		PersonalDayID = @PersonalDayID;	
GO
