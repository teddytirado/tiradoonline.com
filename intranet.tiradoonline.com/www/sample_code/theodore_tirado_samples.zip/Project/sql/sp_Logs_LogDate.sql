ALTER PROCEDURE sp_Logs_LogDate
	@LogDate		SMALLDATETIME
AS
	SELECT
		LogDate, LogDesc
	FROM
		Logs
	WHERE 
		DATEPART(day, LogDate) = DAY(@LogDate) AND
		DATEPART(month, LogDate) = MONTH(@LogDate) AND
		DATEPART(year, LogDate) = YEAR(@LogDate)
	ORDER BY 
		LogDate DESC
GO
