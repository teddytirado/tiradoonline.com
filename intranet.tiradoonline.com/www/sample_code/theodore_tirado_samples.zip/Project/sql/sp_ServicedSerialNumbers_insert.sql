IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_ServicedSerialNumbers_insert' AND TYPE = 'P')
	DROP PROCEDURE sp_ServicedSerialNumbers_insert;
GO


CREATE PROCEDURE sp_ServicedSerialNumbers_insert
	@ServiceReportNumber	NVARCHAR(10),
	@ModelNumber		NVARCHAR(20),
	@SerialNumber		NVARCHAR(20)
AS

	DECLARE 	@LineNumber	TINYINT;

	SELECT @LineNumber = CASE
			WHEN MAX(LineNumber) IS NULL THEN 1
			ELSE MAX(LineNumber) + 1
			END FROM ServicedSerialNumbers WHERE ServiceReportNumber = @ServiceReportNumber;
	PRINT @LineNumber;

	IF @LineNumber IS NULL
		BEGIN
			SET @LineNumber = 1;
		END

	INSERT INTO ServicedSerialNumbers
		(ServiceReportNumber, LineNumber, ModelNumber, SerialNumber)
	VALUES
		(@ServiceReportNumber, @LineNumber, @ModelNumber, @SerialNumber)

GO

EXEC sp_ServicedSerialNumbers_insert '3', 'S', 'S'