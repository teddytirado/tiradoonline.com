SELECT DISTINCT EndTime, CONVERT(VARCHAR(8000), TextData) from teddy_user.profiler
select top 10 * from teddy_user.profiler
INSERT INTO teddy_user.profiler SELECT * FROM dbo.profiler WHERE EndTime NOT IN (SELECT EndTime FROM teddy_user.profiler);
SELECT COUNT(*) FROM dbo.profiler WHERE EndTime NOT IN (SELECT EndTime FROM teddy_user.profiler);
SET NOCOUNT ON
GO

DECLARE @MINIMUM	SMALLDATETIME;
DECLARE @MAXIMUM	SMALLDATETIME;
DECLARE @TOTALROWS	INT;

PRINT 'teddy_user.profiler';
DELETE FROM teddy_user.profiler WHERE EndTime IS NULL;
SET @TOTALROWS = (SELECT COUNT(*) FROM teddy_user.profiler)
SET @MINIMUM = (SELECT MIN(EndTime) FROM teddy_user.profiler);
SET @MAXIMUM = (SELECT MAX(EndTime) FROM teddy_user.profiler);
PRINT 'ROWS: ' + CONVERT(VARCHAR(20), @TOTALROWS);
PRINT 'DATE RANGE: ' + CONVERT(VARCHAR(100), @MINIMUM) + ' - ' + CONVERT(VARCHAR(100), @MAXIMUM);

PRINT 'dbo.profiler';
DELETE FROM dbo.profiler WHERE EndTime IS NULL;
SET @TOTALROWS = (SELECT COUNT(*) FROM dbo.profiler)
SET @MINIMUM = (SELECT MIN(EndTime) FROM dbo.profiler);
SET @MAXIMUM = (SELECT MAX(EndTime) FROM dbo.profiler);
PRINT 'ROWS: ' + CONVERT(VARCHAR(20), @TOTALROWS);
PRINT 'DATE RANGE: ' + CONVERT(VARCHAR(100), @MINIMUM) + ' - ' + CONVERT(VARCHAR(100), @MAXIMUM);

GO

SET NOCOUNT OFF
GO
