IF EXISTS (SELECT NAME FROM SYSOBJECTS WHERE NAME = 'sp_BalanceAccountsLinked_insert' AND TYPE = 'P')
         DROP PROCEDURE sp_BalanceAccountsLinked_insert;

GO

CREATE PROCEDURE sp_BalanceAccountsLinked_insert
        @BalanceAccountID              	INT,
	@Email				VARCHAR(50)
AS

	INSERT INTO BalanceAccountsLinked
		(BalanceAccountID, Email)
	VALUES
		(@BalanceAccountID, @Email)
GO

 

--EXEC sp_BalanceAccountsLinked_insert 1014

 