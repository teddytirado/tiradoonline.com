IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_ServiceReport_100_get' AND TYPE = 'P')
	DROP PROCEDURE sp_ServiceReport_100_get;
GO


CREATE PROCEDURE sp_ServiceReport_100_get
AS

	SELECT TOP 100
		a.ServiceReportNumber,
		b.CompanyName,
		RepairDate = (SELECT TOP 1 RepairDate FROM DateServicePerformed WHERE ServiceReportNumber = a.ServiceReportNumber ORDER BY RepairDate DESC),
		SalesPerson = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = a.SalesID COLLATE SQL_Latin1_General_CP1_CS_AS),
		TotalAmount,
		Status,
		close_by = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = a.close_by COLLATE SQL_Latin1_General_CP1_CS_AS),
		a.close_dt,
		update_by = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = a.update_by COLLATE SQL_Latin1_General_CP1_CS_AS),
		a.update_dt,
		create_by = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = a.create_by COLLATE SQL_Latin1_General_CP1_CS_AS),
		a.create_dt
	FROM
		ServiceReport a,
		Companies b
	WHERE
		a.CompanyID = b.CompanyID
	ORDER BY
		ServiceReportNumber DESC

GO

EXEC sp_ServiceReport_100_get