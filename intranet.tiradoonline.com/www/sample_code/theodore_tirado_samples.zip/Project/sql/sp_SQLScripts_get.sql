ALTER PROCEDURE sp_SQLScripts_get
	@UserID		INT
AS
	
	SELECT 
		SQLScriptID, 
		SQLScriptShow = CASE 
				WHEN LEN(SQLScript) > 30 THEN 
			            Left(SQLScript, 30) + '...............'
                                ELSE 
				    SQLScript
			   END,
		SQLScript
	FROM 
		SQLScripts 
	WHERE 
		UserID = @UserID 
	ORDER BY 
		SQLScript;
