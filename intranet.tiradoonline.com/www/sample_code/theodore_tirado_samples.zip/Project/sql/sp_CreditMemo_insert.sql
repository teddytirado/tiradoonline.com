IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_CreditMemo_insert' AND TYPE = 'P')
	DROP PROCEDURE sp_CreditMemo_insert;
GO

CREATE PROCEDURE sp_CreditMemo_insert
	@CreditMemoNumber 		VARCHAR(20),
	@CreditMemoDate 		DATETIME,
	@ReferenceNumber		VARCHAR(20),
	@ServiceReportNumber		VARCHAR(10),
	@SalesID			VARCHAR(10),
	@ServiceDate			DATETIME,
	@PONumber			VARCHAR(10),
	@PartNumber			VARCHAR(20),
	@PartDescription		VARCHAR(50),
	@Claim				VARCHAR(20),
	@VendorID			INT,
	@LaborReimbursement		BIT,
	@LaborAmount			MONEY,
	@CheckNumber			INT,
	@PaidDate			DATETIME,
	@PaidAmount			MONEY,
	@Notes				VARCHAR(1000)


AS
	
	IF NOT EXISTS (SELECT CreditMemoNumber FROM CreditMemo WHERE CreditMemoNumber = @CreditMemoNumber)
		BEGIN 
			BEGIN TRANSACTION TranCreditMemo
			
			IF NOT EXISTS(SELECT ServiceReportNumber FROM ServiceReport WHERE ServiceReportNumber = @ServiceReportNumber)
				SET @ServiceReportNumber = '';

			INSERT INTO CreditMemo
				(CreditMemoNumber,
				CreditMemoDate,
				ReferenceNumber,
				ServiceReportNumber,
				SalesID,
				PartNumber,
				PartDescription,
				Claim,
				VendorID,
				LaborReimbursement,
				LaborAmount,
				CheckNumber,
				PaidDate,
				PaidAmount,
				Notes,
				update_by,
				create_by)
			VALUES 
				(@CreditMemoNumber,
				@CreditMemoDate,
				@ReferenceNumber,
				@ServiceReportNumber,
				@SalesID,
				@PartNumber,
				@PartDescription,
				@Claim,
				@VendorID,
				@LaborReimbursement,
				@LaborAmount,
				@CheckNumber,
				@PaidDate,
				@PaidAmount,
				@Notes,
				@SalesID,
				@SalesID);
			
			IF @ServiceReportNumber <> ''
				BEGIN
					UPDATE ServiceReport SET
						ServiceDate = @ServiceDate,
						PONumber = @PONumber
					WHERE
						ServiceReportNumber= @ServiceReportNumber;
				END

			IF @@ERROR <> 0
				ROLLBACK TRAN TranCreditMemo;
			ELSE
				COMMIT TRAN TranCreditMemo;
									
			SELECT @CreditMemoNumber = @@IDENTITY;
		END 
	ELSE
		SELECT CreditMemoNumber = 0;
GO

EXEC sp_CreditMemo_insert '234', '2/24/2010', '345', '122', '999', '', '', 'part', 'desc', 'claim', 1001, 1, 23, 1002, '2/23/2010', 67, 'notes'