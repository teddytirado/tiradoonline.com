ALTER PROCEDURE sp_SickDays_get
	@UserID		INT
AS
	SELECT 
		b.CompanyID, 
		b.CompanyName, 
		a.SickDate 
	FROM 
		SickDays a, 
		Companies b 
	WHERE 
		a.CompanyID = b.CompanyID AND 
		b.UserID = @UserID
	ORDER BY 
		a.SickDate DESC, 
		b.CompanyName
GO
