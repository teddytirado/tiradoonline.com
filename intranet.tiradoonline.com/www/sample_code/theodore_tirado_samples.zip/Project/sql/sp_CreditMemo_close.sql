IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_CreditMemo_close' AND TYPE = 'P')
	DROP PROCEDURE sp_CreditMemo_close;
GO

CREATE PROCEDURE sp_CreditMemo_close
	@CreditMemoNumber 		VARCHAR(20),
	@SalesID			VARCHAR(10)
AS

	UPDATE CreditMemo SET
		closed_by = @SalesID,
		closed_dt = GETDATE(),
		Status = 0
	WHERE
		CreditMemoNumber = @CreditMemoNumber;
	
GO

