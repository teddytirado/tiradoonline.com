INSERT INTO profiler SELECT * FROM dbo.profiler;
INSERT INTO profiler SELECT * FROM dbo.profiler_bak;
