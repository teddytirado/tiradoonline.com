IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Customers_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Customers_get;
GO


CREATE PROCEDURE sp_Customers_get
	@SalesID		NVARCHAR(50),
	@UserType		TINYINT
AS
	
	IF @UserType > 0
		BEGIN
			SELECT 
				* 
			FROM 
				MISINC..ARCUS
			ORDER BY 
				IDCUST;

		END
	ELSE
		BEGIN
			SELECT 
				* 
			FROM 
				MISINC..ARCUS
			WHERE 
				LEFT(IDCUST, 2) = @SalesID
			ORDER BY 
				IDCUST;
		END

GO


EXEC sp_Customers_get '3004', 0