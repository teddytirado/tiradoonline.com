ALTER PROCEDURE sp_Reminders_get_ReminderID
	@UserID		INT,
	@ReminderDate	SMALLDATETIME
AS

	SELECT
		ReminderID
	FROM
		Reminders
	WHERE 
		UserID = @UserID AND
		ReminderDate = @ReminderDate
	ORDER BY
		ReminderDate
GO