ALTER PROCEDURE sp_Emails_Contacts_get
	@UserID		INT
AS

	SELECT 
		FullName = (FirstName + ' ' + LastName), 
		Email1 
	FROM 
		Contacts 
	WHERE 
		UserID = @UserID AND 
		LTRIM(RTRIM(Email1)) <> '' 
	ORDER BY 
		FirstName