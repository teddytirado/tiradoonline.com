ALTER PROCEDURE sp_Balance_BalanceID
	@BalanceID		INT
AS

	SELECT
		BalanceDate, 
		BalanceAccountID,
		SubBalanceAccountID,
		TransactionID, 
		Payment, 
		Comment
	FROM 
		Balance 
	WHERE 
		BalanceID = @BalanceID
GO