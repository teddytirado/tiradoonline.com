ALTER PROCEDURE sp_Balance_Transaction_Reports
	@BalanceAccountID		INT
AS
	DECLARE @MinDate	DATETIME;
	DECLARE @TotalMonths	INT;

	SET @MinDate = (SELECT MIN(BalanceDate) FROM Balance WHERE BalanceAccountID = @BalanceAccountID);
	SET @TotalMonths = DATEDIFF(month, @MinDate, GETDATE());
	IF @TotalMonths = 0 
		SET @TotalMonths = 1;
	
	SELECT 
		getdate(),
		b.TransactionID,
		b.Description,
		SUM(a.Payment) AS Amount,
		SUM(a.Payment) / @TotalMonths AS Monthly
	FROM 
		Balance a, 
		Transactions b 
	WHERE 
		a.BalanceAccountID = @BalanceAccountID AND
		a.TransactionID = b.TransactionID
	GROUP BY
		b.TransactionID,
		b.Description
	ORDER BY
		b.Description;

GO

EXEC sp_Balance_Transaction_Reports 1024