IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_QuotePDF' AND TYPE = 'P')
	DROP PROCEDURE sp_QuotePDF;
GO


CREATE PROCEDURE sp_QuotePDF
--	@QID		INT
AS

DECLARE @SalesTax 	DECIMAL(9,5)
SET @SalesTax = .08875;
	
SELECT
	CompanyAddress = (SELECT CompanyAddress FROM QuotePDF),
	Agreement = (SELECT Agreement FROM QuotePDF),
	RefernceNumber = a.RefNum,
	QuoteDate = LEFT(a.QuoteDate, 11),
	SalesPerson = (SELECT FirstName + ' ' + LastName FROM Userz WHERE SalesID COLLATE SQL_Latin1_General_CP1_CS_AS = a.SPNumber),
	CustomerName = LTRIM(RTRIM(d.NAMECUST)),
	CustomerAddress1 = LTRIM(RTRIM(c.CustAdd1)),
	CustomerAddress2 = LTRIM(RTRIM(c.CustAdd2)),
	CustomerCity = LTRIM(RTRIM(c.CustCity)),
	CustomerState = LTRIM(RTRIM(c.CustState)),
	CustomerZipCode = LTRIM(RTRIM(c.CustZip)),
	BillingAddress1 = LTRIM(RTRIM(c.CustBAdd1)),
	BillingAddress2 = LTRIM(RTRIM(c.CustBAdd2)),
	BillingCity = LTRIM(RTRIM(c.CustBCity)),
	BillingState = LTRIM(RTRIM(c.CustBState)),
	BillingZipCode = LTRIM(RTRIM(c.CustBZip)),
	Quantity = b.WOQTY,
	ItemNumber = LTRIM(RTRIM(b.WOItemNum)),
	Description = LTRIM(RTRIM(b.WODesc)),
	UnitPrice = CONVERT(NUMERIC(9,2), b.WOUPrice),
	ExtendedPrice = CONVERT(NUMERIC(9,2), (b.WOUPrice * b.WOQTY)),
	Freight = isNull(a.WOFreight, 0),
	Subtotal = CONVERT(VARCHAR(40), '0'),
	TotalSalesTax = CONVERT(VARCHAR(40), '0'),
	TotalAmount = CONVERT(VARCHAR(40), '0'),
	AmountDue = CONVERT(VARCHAR(40), '0')
FROM
	Quote a,
	QuoteDetail b,
	CustShipQ c,
	MISINC..ARCUS d
WHERE
	a.QID = 25685 AND
	a.QID = b.QID AND
	a.QID = c.QID AND
	UPPER(LTRIM(RTRIM(a.WOCustomer))) = UPPER(LTRIM(RTRIM(d.IDCUST))) COLLATE SQL_Latin1_General_CP1_CS_AS;
GO
EXEC sp_QuotePDF 