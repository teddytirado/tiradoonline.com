IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Companies_Letter_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Companies_Letter_get;
GO


CREATE PROCEDURE sp_Companies_Letter_get
	@Letter		VARCHAR(3)

AS

	IF @Letter = 'ALL'
		BEGIN
			SELECT 
				TotalServiceReports = (SELECT COUNT(*) FROM ServiceReport WHERE CompanyID = Companies.CompanyID),
				*, 
				State = (SELECT StateName FROM Intranet..States WHERE 
				StateAbbr = Companies.StateID COLLATE SQL_Latin1_General_CP1_CI_AS),
				update_by = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = Companies.update_by),
				create_by = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = Companies.create_by)
				
			FROM 
				Companies 
			ORDER BY 
				CompanyName
		END
	ELSE
		BEGIN
			SET @Letter = @Letter + '%';
			
			SELECT 
				TotalServiceReports = (SELECT COUNT(*) FROM ServiceReport WHERE CompanyID = Companies.CompanyID),
				*, 
				State = (SELECT StateName FROM Intranet..States WHERE 
				StateAbbr = Companies.StateID COLLATE SQL_Latin1_General_CP1_CI_AS),
				update_by = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = Companies.update_by),
				create_by = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = Companies.create_by)
			FROM 
				Companies 
			WHERE 
				UPPER(CompanyName) LIKE @Letter
			ORDER BY 
				CompanyName;
		END	

GO

EXEC sp_Companies_Letter_get 'ALL'