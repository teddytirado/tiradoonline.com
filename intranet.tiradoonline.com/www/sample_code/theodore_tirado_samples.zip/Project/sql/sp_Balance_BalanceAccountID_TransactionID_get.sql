ALTER PROCEDURE sp_Balance_BalanceAccountID_TransactionID_get
	@BalanceAccountID		INT,
	@TransactionID			INT
AS

	SELECT
		a.BalanceID, 
		a.BalanceDate, 
		a.BankDate,
		a.Payment, 
		a.Comment, 
		b.Description
	FROM 
		Balance a, 
		Transactions b
	WHERE
		b.TransactionID = @TransactionID AND
		a.TransactionID = b.TransactionID AND
		a.BalanceAccountID = @BalanceAccountID
	ORDER BY
		a.BalanceDate;
GO

--EXEC sp_Balance_BalanceAccountID_TransactionID_get 1024, 1027