IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_ServiceReport_update' AND TYPE = 'P')
	DROP PROCEDURE sp_ServiceReport_update;
GO


CREATE PROCEDURE sp_ServiceReport_update
	@OldServiceReportNumber	VARCHAR(10),
	@NewServiceReportNumber	VARCHAR(10),
	@ServiceReportNumberExt VARCHAR(5),
	@CompanyID		INT,
	@SalesTax		VARCHAR(10),
	@Remarks		NVARCHAR(2000),
	@Problems		NVARCHAR(2000),
	@Solutions		NVARCHAR(2000),
	@Notes			NVARCHAR(2000),
	@ServiceDate		VARCHAR(10),
	@ServiceTime		VARCHAR(15),
	@Contract		BIT,
	@T_M			BIT,
	@Warranty		BIT,
	@OtherDescription	VARCHAR(100),
	@PONumber		NVARCHAR(50),
	@WorkOrderNumber	NVARCHAR(50),
	@LaborHours		REAL,
	@LaborRate		MONEY,
	@TravelHours		REAL,
	@TravelRate		MONEY,
	@MiscCharges		MONEY,
	@Shipping		MONEY,
	@Contact		NVARCHAR(50),
	@Phone			NVARCHAR(20),
	@Ext			NVARCHAR(5),
	@TotalAmount		MONEY,
	@create_by		VARCHAR(10)	
AS
	
	UPDATE ServiceReport SET
		ServiceReportNumber = @NewServiceReportNumber,
		ServiceReportNumberExt = @ServiceReportNumberExt,
		CompanyID = @CompanyID,
		SalesTax = @SalesTax,
		Remarks = @Remarks,
		Problems = @Problems,
		Solutions = @Solutions,
		Notes = @Notes,
		ServiceDate = @ServiceDate,
		ServiceTime = @ServiceTime,
		Contract = @Contract,
		T_M = @T_M,
		Warranty = @Warranty,
		OtherDescription = @OtherDescription,
		PONumber = @PONumber,
		WONumber = @WorkOrderNumber,
		LaborHours = @LaborHours,
		LaborRate = @LaborRate,
		TravelHours = @TravelHours,
		TravelRate = @TravelRate,
		MiscCharges = @MiscCharges,
		Shipping = @Shipping,
		Contact = @Contact,
		Phone = Service.dbo.fn_PhoneNumber(@Phone),
		Ext = @Ext,
		TotalAmount = @TotalAmount, 
		update_by = @create_by,
		update_dt = GETDATE()
	WHERE
		ServiceReportNumber = @OldServiceReportNumber;

GO

EXEC sp_ServiceReport_update '32250', '32250', '1', 140, '0.0825', '', '', '', '', 'Jul 22 201', '', 1, 0, 0, '', '', '', 0, 0, 0, 0, 0, 0, 'Katan Chitra', '(212) 891-577', '', 365.885, '999'