
INSERT INTO ShippingAddressBook
	(SalesID, CustomerID, CustomerName, Address1, Address2, Address3, Address4, City, StateID, ZipCode, create_dt)
SELECT b.SalesID, CustomerID = a.CustomerNum, CustomerName = a.CustName, Address1 = a.CustAdd1, Address2 = a.CustAdd2, Address3 = a.CustAdd3, Address4 = a.CustAdd4, City = a.CustCity, StateID = a.CustState, ZipCode = a.CustZip, a.create_dt FROM CustShipQ a, Userz b WHERE (ISNUMERIC(LEFT(a.CustomerNum, 2)) = 1 AND ISNUMERIC(b.SalesID) = 1) AND LEFT(a.CustomerNum, 2) = b.SalesID COLLATE SQL_Latin1_General_CP1_CS_AS ORDER BY CustomerNum
