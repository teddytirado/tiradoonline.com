ALTER TABLE Balance ADD CONSTRAINT FK_Balance_Transactions FOREIGN KEY (TransactionID) REFERENCES Transactions(TransactionID);
GO
ALTER TABLE Balance ADD CONSTRAINT FK_Balance_Users FOREIGN KEY (UserID) REFERENCES Users(UserID);
GO
