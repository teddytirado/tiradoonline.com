ALTER TABLE PersonalDays ADD CONSTRAINT FK_PersonalDays_Companies FOREIGN KEY (CompanyID) REFERENCES Companies(CompanyID);
GO
