ALTER TABLE Snippets ADD CONSTRAINT FK_Snippets_Users FOREIGN KEY (UserID) REFERENCES Users(UserID);
GO
ALTER TABLE Snippets ADD CONSTRAINT FK_Snippets_SnippetGroups FOREIGN KEY (SnippetGroupID) REFERENCES SnippetGroups(SnippetGroupID);
GO
