ALTER TABLE Hours ADD CONSTRAINT FK_Hours_Companies FOREIGN KEY (CompanyID) REFERENCES Companies(CompanyID);
GO
