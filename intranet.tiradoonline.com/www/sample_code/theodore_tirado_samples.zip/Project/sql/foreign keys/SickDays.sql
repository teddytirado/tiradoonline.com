ALTER TABLE SickDays ADD CONSTRAINT FK_SickDays_Companies FOREIGN KEY (CompanyID) REFERENCES Companies(CompanyID);
GO
