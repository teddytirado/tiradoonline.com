ALTER TABLE Contacts ADD CONSTRAINT FK_Contacts_Users FOREIGN KEY (UserID) REFERENCES Users(UserID);
GO
ALTER TABLE Contacts ADD CONSTRAINT FK_Contacts_ContactGroups FOREIGN KEY (ContactGroupID) REFERENCES ContactGroups(ContactGroupID);
GO
ALTER TABLE Contacts ADD CONSTRAINT FK_Contacts_States FOREIGN KEY (StateID) REFERENCES States(StateID);
GO

