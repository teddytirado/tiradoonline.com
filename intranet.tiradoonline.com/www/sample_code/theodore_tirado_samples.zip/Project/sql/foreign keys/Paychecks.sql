ALTER TABLE Paychecks ADD CONSTRAINT FK_Paychecks_Companies FOREIGN KEY (CompanyID) REFERENCES Companies(CompanyID);
GO
