ALTER PROCEDURE sp_Backups_BackupDate
	@BackupDate		SMALLDATETIME
AS

	SELECT
		a.BackupDate, b.UserName
	FROM
		Backups a, Users b
	WHERE 
		a.UserID = b.UserID AND
		DATEPART(day, a.BackupDate) = DAY(@BackupDate) AND
		DATEPART(month, a.BackupDate) = MONTH(@BackupDate) AND
		DATEPART(year, a.BackupDate) = YEAR(@BackupDate)
	ORDER BY 
		a.BackupDate DESC
GO
