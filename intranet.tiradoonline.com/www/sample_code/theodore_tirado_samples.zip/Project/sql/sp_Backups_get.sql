ALTER PROCEDURE sp_Backups_get
	@UserID			INT
AS
	DECLARE @MediaSetID	INT;
	SET @MediaSetID = (SELECT MAX(media_set_id) FROM MSDB..backupmediafamily WHERE logical_device_name = 'teddy_dmp');
	--PRINT @MediaSetID;

	SELECT 
		c.backup_finish_date AS BackupDate
	FROM
		MSDB..backupmediaset b,
		MSDB..backupset c
	WHERE 
		b.media_set_id = @MediaSetID AND
		b.media_set_id = c.media_set_id and
		c.username = user_name(@UserID)
	GROUP BY
		c.media_set_id, c.backup_finish_date 
	ORDER BY
		c.backup_finish_date DESC




go

select * from MSDB..backupmediaset;
select * from MSDB..backupset;
exec sp_Backups_get 1001