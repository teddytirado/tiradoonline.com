ALTER PROCEDURE sp_PersonalDays_insert
	@CompanyID	INT,
	@PersonalDate	SMALLDATETIME
AS
	INSERT INTO Personaldays 
		(CompanyID, PersonalDate) 
	VALUES 
		(@CompanyID, @PersonalDate);
GO
