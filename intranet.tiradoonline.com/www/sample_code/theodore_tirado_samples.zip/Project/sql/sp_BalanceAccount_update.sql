ALTER PROCEDURE sp_BalanceAccount_update
	@BalanceAccountID	INT,
	@BalanceAccountName	VARCHAR(50)
AS

	UPDATE BalanceAccounts SET
		BalanceAccountName = @BalanceAccountName
	WHERE
		BalanceAccountID = @BalanceAccountID

GO

--EXEC sp_BalanceAccount_update 1001, 'T-Mobile'