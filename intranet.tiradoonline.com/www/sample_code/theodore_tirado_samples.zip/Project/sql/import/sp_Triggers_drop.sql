IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Triggers_drop' AND TYPE = 'P')
	DROP PROCEDURE sp_Triggers_drop;
GO


CREATE PROCEDURE sp_Triggers_drop
AS
	DECLARE @DatabaseName	VARCHAR(30);
	DECLARE @TableName	VARCHAR(30);
	DECLARE @SQL		NVARCHAR(3000);
	DECLARE @TriggerMethod	NVARCHAR(100);

	SET @DatabaseName = 'IntranetLogs';

	DECLARE triggerCursor CURSOR FOR SELECT NAME FROM sysobjects WHERE TYPE = 'U' AND LEFT(NAME, 2) <> 'dt' ORDER BY NAME;
	OPEN triggerCursor
	FETCH NEXT FROM triggerCursor INTO @TableName;



	WHILE @@FETCH_STATUS = 0
		BEGIN
		
			/********* INSERT *****************/
			SET @TriggerMethod = 'insert';
			SET @SQL = 'IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = ''tr_' + @TableName + '_' + @TriggerMethod + ''' AND TYPE = ''TR'')' + CHAR(10);
			SET @SQL = @SQL + CHAR(9) + 'DROP TRIGGER tr_' + @TableName + '_' + @TriggerMethod + ';' + CHAR(10);
			PRINT @SQL;
			EXEC sp_executesql @SQL;

			/********* UPDATE *****************/
			SET @TriggerMethod = 'update';
			SET @SQL = 'IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = ''tr_' + @TableName + '_' + @TriggerMethod + ''' AND TYPE = ''TR'')' + CHAR(10);
			SET @SQL = @SQL + CHAR(9) + 'DROP TRIGGER tr_' + @TableName + '_' + @TriggerMethod + ';' + CHAR(10);
			PRINT @SQL;
			EXEC sp_executesql @SQL;

			/********* DELETE *****************/
			SET @TriggerMethod = 'delete';
			SET @SQL = 'IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = ''tr_' + @TableName + '_' + @TriggerMethod + ''' AND TYPE = ''TR'')' + CHAR(10);
			SET @SQL = @SQL + CHAR(9) + 'DROP TRIGGER tr_' + @TableName + '_' + @TriggerMethod + ';' + CHAR(10);
			PRINT @SQL;
			EXEC sp_executesql @SQL;




			FETCH NEXT FROM triggerCursor INTO @TableName;
		END

	--PRINT @TotalSQL;

	CLOSE triggerCursor	
	DEALLOCATE triggerCursor	

GO

EXEC sp_Triggers_drop;

--SELECT * FROM Intranet_backup..sysobjects;