IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Triggers_create' AND TYPE = 'P')
	DROP PROCEDURE sp_Triggers_create;
GO


CREATE PROCEDURE sp_Triggers_create
AS
	DECLARE @DatabaseName	VARCHAR(30);
	DECLARE @TableName	VARCHAR(30);
	DECLARE @SQL		NVARCHAR(3000);
	DECLARE @TriggerMethod	NVARCHAR(100);

	SET @DatabaseName = 'IntranetLogs';

	DECLARE triggerCursor CURSOR FOR SELECT NAME FROM sysobjects WHERE TYPE = 'U' AND LEFT(NAME, 2) <> 'dt' ORDER BY NAME;
	OPEN triggerCursor
	FETCH NEXT FROM triggerCursor INTO @TableName;



	WHILE @@FETCH_STATUS = 0
		BEGIN
		
			/********* INSERT *****************/
			SET @TriggerMethod = 'insert';
			SET @SQL = 'IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = ''tr_' + @TableName + '_' + @TriggerMethod + ''' AND TYPE = ''TR'')' + CHAR(10);
			SET @SQL = @SQL + CHAR(9) + 'DROP TRIGGER tr_' + @TableName + '_' + @TriggerMethod + ';' + CHAR(10);
			PRINT @SQL;
			EXEC sp_executesql @SQL;
			PRINT 'EXECUTED';

			SET @SQL = 'CREATE TRIGGER tr_' + @TableName + '_' + @TriggerMethod + ' ON ' + @TableName + ' FOR INSERT' + CHAR(10);
			SET @SQL = @SQL + 'AS' + CHAR(10) + CHAR(10);
			SET @SQL = @SQL + CHAR(9) + 'IF NOT EXISTS (SELECT NAME FROM ' + @DatabaseName + '..sysobjects WHERE NAME = ''' + @TableName + '_' + @TriggerMethod + ''' AND TYPE = ''U'')' + CHAR(10);
			SET @SQL = @SQL + CHAR(9) + CHAR(9) + 'BEGIN'
			SET @SQL = @SQL + CHAR(9) + CHAR(9) + CHAR(9) + 'SELECT TOP 1 * INTO ' + @DatabaseName + '..' + @TableName + '_' + @TriggerMethod + ' FROM ' + @TableName + ';' + CHAR(10);
			SET @SQL = @SQL + CHAR(9) + CHAR(9) + CHAR(9) + 'TRUNCATE TABLE ' + @DatabaseName + '..' + @TableName + '_' + @TriggerMethod + ';' + CHAR(10);
			SET @SQL = @SQL + CHAR(9) + CHAR(9) + 'END' + CHAR(10)
			SET @SQL = @SQL + CHAR(9) + 'SET IDENTITY_INSERT ' + @DatabaseName + '..' + @TableName + '_' + @TriggerMethod + ' ON;' + CHAR(10);
			SET @SQL = @SQL + CHAR(9) + 'INSERT INTO ' + @DatabaseName + '..' + @TableName + '_' + @TriggerMethod + ' SELECT * FROM inserted;' + CHAR(10);
			SET @SQL = @SQL + CHAR(9) + 'SET IDENTITY_INSERT ' + @DatabaseName + '..' + @TableName + '_' + @TriggerMethod + ' OFF;' + CHAR(10);
			PRINT @SQL;
			EXEC sp_executesql @SQL;
			PRINT 'EXECUTED';
			PRINT '*************************************';

			/********* UPDATE *****************/
			SET @TriggerMethod = 'update';
			SET @SQL = 'IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = ''tr_' + @TableName + '_' + @TriggerMethod + ''' AND TYPE = ''TR'')' + CHAR(10);
			SET @SQL = @SQL + CHAR(9) + 'DROP TRIGGER tr_' + @TableName + '_' + @TriggerMethod + ';' + CHAR(10);
			PRINT @SQL;
			EXEC sp_executesql @SQL;
			PRINT 'EXECUTED';

			SET @SQL = 'CREATE TRIGGER tr_' + @TableName + '_' + @TriggerMethod + ' ON ' + @TableName + ' FOR UPDATE' + CHAR(10);
			SET @SQL = @SQL + 'AS' + CHAR(10) + CHAR(10);
			SET @SQL = @SQL + CHAR(9) + 'IF NOT EXISTS (SELECT NAME FROM ' + @DatabaseName + '..sysobjects WHERE NAME = ''' + @TableName + '_' + @TriggerMethod + ''' AND TYPE = ''U'')' + CHAR(10);
			SET @SQL = @SQL + CHAR(9) + CHAR(9) + 'BEGIN'
			SET @SQL = @SQL + CHAR(9) + CHAR(9) + CHAR(9) + 'SELECT TOP 1 * INTO ' + @DatabaseName + '..' + @TableName + '_' + @TriggerMethod + ' FROM ' + @TableName + ';' + CHAR(10);
			SET @SQL = @SQL + CHAR(9) + CHAR(9) + CHAR(9) + 'TRUNCATE TABLE ' + @DatabaseName + '..' + @TableName + '_' + @TriggerMethod + ';' + CHAR(10);
			SET @SQL = @SQL + CHAR(9) + CHAR(9) + 'END' + CHAR(10)
			SET @SQL = @SQL + CHAR(9) + 'SET IDENTITY_INSERT ' + @DatabaseName + '..' + @TableName + '_' + @TriggerMethod + ' ON;' + CHAR(10);
			SET @SQL = @SQL + CHAR(9) + 'INSERT INTO ' + @DatabaseName + '..' + @TableName + '_' + @TriggerMethod + ' SELECT * FROM inserted;' + CHAR(10);
			SET @SQL = @SQL + CHAR(9) + 'SET IDENTITY_INSERT ' + @DatabaseName + '..' + @TableName + '_' + @TriggerMethod + ' OFF;' + CHAR(10);
			PRINT @SQL;
			EXEC sp_executesql @SQL;
			PRINT 'EXECUTED';
			PRINT '*************************************';



			/********* DELETE *****************/
			SET @TriggerMethod = 'delete';
			SET @SQL = 'IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = ''tr_' + @TableName + '_' + @TriggerMethod + ''' AND TYPE = ''TR'')' + CHAR(10);
			SET @SQL = @SQL + CHAR(9) + 'DROP TRIGGER tr_' + @TableName + '_' + @TriggerMethod + ';' + CHAR(10);
			PRINT @SQL;
			EXEC sp_executesql @SQL;
			PRINT 'EXECUTED';

			SET @SQL = 'CREATE TRIGGER tr_' + @TableName + '_' + @TriggerMethod + ' ON ' + @TableName + ' FOR DELETE' + CHAR(10);
			SET @SQL = @SQL + 'AS' + CHAR(10) + CHAR(10);
			SET @SQL = @SQL + CHAR(9) + 'IF NOT EXISTS (SELECT NAME FROM ' + @DatabaseName + '..sysobjects WHERE NAME = ''' + @TableName + '_' + @TriggerMethod + ''' AND TYPE = ''U'')' + CHAR(10);
			SET @SQL = @SQL + CHAR(9) + CHAR(9) + 'BEGIN'
			SET @SQL = @SQL + CHAR(9) + CHAR(9) + CHAR(9) + 'SELECT TOP 1 * INTO ' + @DatabaseName + '..' + @TableName + '_' + @TriggerMethod + ' FROM ' + @TableName + ';' + CHAR(10);
			SET @SQL = @SQL + CHAR(9) + CHAR(9) + CHAR(9) + 'TRUNCATE TABLE ' + @DatabaseName + '..' + @TableName + '_' + @TriggerMethod + ';' + CHAR(10);
			SET @SQL = @SQL + CHAR(9) + CHAR(9) + 'END' + CHAR(10)
			SET @SQL = @SQL + CHAR(9) + 'SET IDENTITY_INSERT ' + @DatabaseName + '..' + @TableName + '_' + @TriggerMethod + ' ON;' + CHAR(10);
			SET @SQL = @SQL + CHAR(9) + 'INSERT INTO ' + @DatabaseName + '..' + @TableName + '_' + @TriggerMethod + ' SELECT * FROM deleted;' + CHAR(10);
			SET @SQL = @SQL + CHAR(9) + 'SET IDENTITY_INSERT ' + @DatabaseName + '..' + @TableName + '_' + @TriggerMethod + ' OFF;' + CHAR(10);
			PRINT @SQL;
			EXEC sp_executesql @SQL;
			PRINT 'EXECUTED';
			PRINT '*************************************';



			FETCH NEXT FROM triggerCursor INTO @TableName;
		END

	--PRINT @TotalSQL;

	CLOSE triggerCursor	
	DEALLOCATE triggerCursor	

GO

EXEC sp_Triggers_create;

--SELECT * FROM Intranet_backup..sysobjects;