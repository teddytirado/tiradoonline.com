ALTER procedure [dbo].[sp_itemship]
as

select distinct itemship into #itemship from wodetail where isdate(itemship) = 1 and itemship <> '' and itemship is not null order by itemship desc;

select a.*, wonumber = (SELECT TOP 1 wonumber from wodetail WHERE itemship = a.itemship) from #itemship a order by convert(datetime, a.itemship) desc;
