CREATE TABLE IntranetLogs.dbo.AccessLvl_insert
(
	AccessLvl nvarchar (50) NOT NULL,
	AccessLvlName varchar (20) NOT NULL 
);

CREATE TABLE IntranetLogs.dbo.AccessLvl_update
(
	AccessLvl nvarchar (50) NOT NULL,
	AccessLvlName varchar (20) NOT NULL 
);

CREATE TABLE IntranetLogs.dbo.AccessLvl_delete
(
	AccessLvl nvarchar (50) NOT NULL,
	AccessLvlName varchar (20) NOT NULL 
);

CREATE TABLE IntranetLogs.dbo.AttendanceAMPM_insert
(
	AMPM varchar (2) NOT NULL 
);

CREATE TABLE IntranetLogs.dbo.AttendanceAMPM_update
(
	AMPM varchar (2) NOT NULL 
);

CREATE TABLE IntranetLogs.dbo.AttendanceAMPM_delete
(
	AMPM varchar (2) NOT NULL 
);

CREATE TABLE IntranetLogs.dbo.AttendanceType_insert
(
	AttendanceTypeID int NOT NULL,
	AttendanceType varchar (50) NOT NULL,
	AttendanceTypeColor varchar (7) NOT NULL 
);

CREATE TABLE IntranetLogs.dbo.AttendanceType_update
(
	AttendanceTypeID int NOT NULL,
	AttendanceType varchar (50) NOT NULL,
	AttendanceTypeColor varchar (7) NOT NULL 
);

CREATE TABLE IntranetLogs.dbo.AttendanceType_delete
(
	AttendanceTypeID int NOT NULL,
	AttendanceType varchar (50) NOT NULL,
	AttendanceTypeColor varchar (7) NOT NULL 
);

CREATE TABLE IntranetLogs.dbo.AttendanceWorkDays_insert
(
	AttendanceWorkDayID int NOT NULL,
	SalesID nvarchar (255) NOT NULL,
	AttendanceWorkPeriodID int NULL,
	AttendanceTypeID int NOT NULL,
	StartTime datetime NOT NULL,
	Comment nvarchar (2000) NULL,
	create_dt datetime DEFAULT GETDATE() NULL 
);

CREATE TABLE IntranetLogs.dbo.AttendanceWorkDays_update
(
	AttendanceWorkDayID int NOT NULL,
	SalesID nvarchar (255) NOT NULL,
	AttendanceWorkPeriodID int NULL,
	AttendanceTypeID int NOT NULL,
	StartTime datetime NOT NULL,
	Comment nvarchar (2000) NULL,
	create_dt datetime DEFAULT GETDATE() NULL 
);

CREATE TABLE IntranetLogs.dbo.AttendanceWorkDays_delete
(
	AttendanceWorkDayID int NOT NULL,
	SalesID nvarchar (255) NOT NULL,
	AttendanceWorkPeriodID int NULL,
	AttendanceTypeID int NOT NULL,
	StartTime datetime NOT NULL,
	Comment nvarchar (2000) NULL,
	create_dt datetime DEFAULT GETDATE() NULL 
);

CREATE TABLE IntranetLogs.dbo.AttendanceWorkPeriod_insert
(
	AttendanceWorkPeriodID int NOT NULL,
	StartPeriodDate smalldatetime NOT NULL,
	EndPeriodDate smalldatetime NOT NULL,
	PayPeriodDate smalldatetime NULL,
	create_dt datetime DEFAULT GETDATE() NULL 
);

CREATE TABLE IntranetLogs.dbo.AttendanceWorkPeriod_update
(
	AttendanceWorkPeriodID int NOT NULL,
	StartPeriodDate smalldatetime NOT NULL,
	EndPeriodDate smalldatetime NOT NULL,
	PayPeriodDate smalldatetime NULL,
	create_dt datetime DEFAULT GETDATE() NULL 
);

CREATE TABLE IntranetLogs.dbo.AttendanceWorkPeriod_delete
(
	AttendanceWorkPeriodID int NOT NULL,
	StartPeriodDate smalldatetime NOT NULL,
	EndPeriodDate smalldatetime NOT NULL,
	PayPeriodDate smalldatetime NULL,
	create_dt datetime DEFAULT GETDATE() NULL 
);

CREATE TABLE IntranetLogs.dbo.Carrier_insert
(
	DSID int NOT NULL,
	CarrierName nvarchar (50) NULL,
	CarrierAbb nvarchar (50) NULL,
	DSType nvarchar (50) NULL ,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);

CREATE TABLE IntranetLogs.dbo.Carrier_update
(
	DSID int NOT NULL,
	CarrierName nvarchar (50) NULL,
	CarrierAbb nvarchar (50) NULL,
	DSType nvarchar (50) NULL ,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);

CREATE TABLE IntranetLogs.dbo.Carrier_delete
(
	DSID int NOT NULL,
	CarrierName nvarchar (50) NULL,
	CarrierAbb nvarchar (50) NULL,
	DSType nvarchar (50) NULL ,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);

CREATE TABLE IntranetLogs.dbo.CarrierType_insert
(
	CTID int NOT NULL,
	CarrierID nvarchar (50) NULL,
	DSType nvarchar (50) NULL,
	DSColor nvarchar (50) NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);
CREATE TABLE IntranetLogs.dbo.CarrierType_update
(
	CTID int NOT NULL,
	CarrierID nvarchar (50) NULL,
	DSType nvarchar (50) NULL,
	DSColor nvarchar (50) NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);
CREATE TABLE IntranetLogs.dbo.CarrierType_delete
(
	CTID int NOT NULL,
	CarrierID nvarchar (50) NULL,
	DSType nvarchar (50) NULL,
	DSColor nvarchar (50) NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);

CREATE TABLE IntranetLogs.dbo.Division_insert
(
	DivisionID int NOT NULL,
	Division nvarchar (50) NULL, 
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);
CREATE TABLE IntranetLogs.dbo.Division_update
(
	DivisionID int NOT NULL,
	Division nvarchar (50) NULL, 
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);
CREATE TABLE IntranetLogs.dbo.Division_delete
(
	DivisionID int NOT NULL,
	Division nvarchar (50) NULL, 
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);

-- CREATE TABLE IntranetLogs.dbo.Emails 
-- (
-- 	EmailID int NOT NULL,
-- 	ToEmail nvarchar (100) NULL,
-- 	FromEmail nvarchar (100) NULL,
-- 	Subject nvarchar (255) NULL,
-- 	BodyText ntext NULL,
-- 	isHTML int NULL,
-- 	create_dt smalldatetime DEFAULT GETDATE() NULL 
-- );

CREATE TABLE IntranetLogs.dbo.InvalidLogins_insert
(
	InvalidLoginID int NOT NULL,
	SalesID nvarchar (50) NULL,
	UPassword nvarchar (50) NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);
CREATE TABLE IntranetLogs.dbo.InvalidLogins_update
(
	InvalidLoginID int NOT NULL,
	SalesID nvarchar (50) NULL,
	UPassword nvarchar (50) NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);
CREATE TABLE IntranetLogs.dbo.InvalidLogins_delete
(
	InvalidLoginID int NOT NULL,
	SalesID nvarchar (50) NULL,
	UPassword nvarchar (50) NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);

CREATE TABLE IntranetLogs.dbo.ItemCategory_insert
(
	ItemCategoryID int NOT NULL,
	CategoryValue varchar (10) NOT NULL,
	Category varchar (30) NOT NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);
CREATE TABLE IntranetLogs.dbo.ItemCategory_update
(
	ItemCategoryID int NOT NULL,
	CategoryValue varchar (10) NOT NULL,
	Category varchar (30) NOT NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);
CREATE TABLE IntranetLogs.dbo.ItemCategory_delete
(
	ItemCategoryID int NOT NULL,
	CategoryValue varchar (10) NOT NULL,
	Category varchar (30) NOT NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);

CREATE TABLE IntranetLogs.dbo.News_insert
(
	NewsID int NOT NULL,
	NewsDate smalldatetime NULL,
	Title varchar (150) NULL,
	Body text NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);
CREATE TABLE IntranetLogs.dbo.News_update
(
	NewsID int NOT NULL,
	NewsDate smalldatetime NULL,
	Title varchar (150) NULL,
	Body text NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);
CREATE TABLE IntranetLogs.dbo.News_delete
(
	NewsID int NOT NULL,
	NewsDate smalldatetime NULL,
	Title varchar (150) NULL,
	Body text NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);

 CREATE TABLE IntranetLogs.dbo.PageLogs_insert
 (
 	PageLogID int NOT NULL,
 	SalesID nvarchar (255) NOT NULL,
 	SCRIPT_NAME varchar (255) NOT NULL,
 	REQUEST_METHOD varchar (20) NULL,
 	QUERY_STRING text NULL,
 	FORM text NULL,
 	create_dt smalldatetime DEFAULT GETDATE() NULL 
 );

 CREATE TABLE IntranetLogs.dbo.PageLogs_update
 (
 	PageLogID int NOT NULL,
 	SalesID nvarchar (255) NOT NULL,
 	SCRIPT_NAME varchar (255) NOT NULL,
 	REQUEST_METHOD varchar (20) NULL,
 	QUERY_STRING text NULL,
 	FORM text NULL,
 	create_dt smalldatetime DEFAULT GETDATE() NULL 
 );
 CREATE TABLE IntranetLogs.dbo.PageLogs_delete
 (
 	PageLogID int NOT NULL,
 	SalesID nvarchar (255) NOT NULL,
 	SCRIPT_NAME varchar (255) NOT NULL,
 	REQUEST_METHOD varchar (20) NULL,
 	QUERY_STRING text NULL,
 	FORM text NULL,
 	create_dt smalldatetime DEFAULT GETDATE() NULL 
 );

CREATE TABLE IntranetLogs.dbo.SalesAssistants_insert 
(
	SalesAssistantID int NOT NULL,
	SalesID nvarchar (255) NOT NULL,
	AssistantSalesID nvarchar (255) NOT NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);
CREATE TABLE IntranetLogs.dbo.SalesAssistants_update
(
	SalesAssistantID int NOT NULL,
	SalesID nvarchar (255) NOT NULL,
	AssistantSalesID nvarchar (255) NOT NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);
CREATE TABLE IntranetLogs.dbo.SalesAssistants_delete
(
	SalesAssistantID int NOT NULL,
	SalesID nvarchar (255) NOT NULL,
	AssistantSalesID nvarchar (255) NOT NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);

CREATE TABLE IntranetLogs.dbo.States_insert
(
	StateID int NOT NULL,
	StateAbbr varchar (3) NOT NULL,
	StateName varchar (50) NOT NULL,
	create_dt smalldatetime NOT NULL 
);

CREATE TABLE IntranetLogs.dbo.States_update
(
	StateID int NOT NULL,
	StateAbbr varchar (3) NOT NULL,
	StateName varchar (50) NOT NULL,
	create_dt smalldatetime NOT NULL 
);

CREATE TABLE IntranetLogs.dbo.States_delete
(
	StateID int NOT NULL,
	StateAbbr varchar (3) NOT NULL,
	StateName varchar (50) NOT NULL,
	create_dt smalldatetime NOT NULL 
);

CREATE TABLE IntranetLogs.dbo.ULogins_insert
(
	LoginID int NOT NULL,
	SalesID nvarchar(50) NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL
);

CREATE TABLE IntranetLogs.dbo.ULogins_update
(
	LoginID int NOT NULL,
	SalesID nvarchar(50) NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL
);

CREATE TABLE IntranetLogs.dbo.ULogins_delete
(
	LoginID int NOT NULL,
	SalesID nvarchar(50) NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL
);

CREATE TABLE IntranetLogs.dbo.Userz_insert
(
	UserID int NOT NULL,
	SalesID nvarchar (255) NOT NULL,
	UPassword nvarchar (255) NULL,
	FirstName nvarchar (255) NULL,
	LastName nvarchar (50) NULL,
	Email nvarchar (50) NULL,
	Extension nvarchar (50) NULL,
	CellPhone nvarchar (50) NULL,
	DivisionID int NULL,
	MakeSale nvarchar (50) NULL,
	AccessLvl nvarchar (50) NULL,
	FAXNum nvarchar (50) NULL,
	ARTransaction nvarchar (255) NULL,
	ARName nvarchar (255) NULL,
	ARID nvarchar (255) NULL,
	ARInvoice nvarchar (255) NULL,
	OEWork nvarchar (50) NULL,
	OEPO nvarchar (50) NULL,
	OEInvoice nvarchar (50) NULL,
	OEUninvoiced nvarchar (50) NULL,
	APCheck nvarchar (50) NULL,
	APInvoice nvarchar (50) NULL,
	ICSerial nvarchar (50) NULL,
	GLGL nvarchar (50) NULL,
	POWO nvarchar (50) NULL,
	POPO nvarchar (50) NULL,
	ReportsCategory nvarchar (50) NULL,
	ReportsSales nvarchar (50) NULL,
	ReportsCash nvarchar (50) NULL,
	ReportsDaily nvarchar (50) NULL,
	ARReports nvarchar (50) NULL,
	SHItem nvarchar (50) NULL,
	SHDesc nvarchar (50) NULL,
	UserControl nvarchar (50) NULL,
	EWQ nvarchar (50) NULL,
	EWPOA nvarchar (50) NULL,
	EWAcct nvarchar (50) NULL,
	EWWare nvarchar (50) NULL,
	EWDeleteWorkOrder nvarchar(50) NULL,
	EWViewAll nvarchar(50) NULL,
	APCR nvarchar (50) NULL,
	TPE nvarchar (50) NULL,
	CCA nvarchar (50) NULL,
	NEWS nvarchar (50) NULL,
	Invent nvarchar (50) NULL,
	Terminated bit NOT NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);

CREATE TABLE IntranetLogs.dbo.Userz_update
(
	UserID int NOT NULL,
	SalesID nvarchar (255) NOT NULL,
	UPassword nvarchar (255) NULL,
	FirstName nvarchar (255) NULL,
	LastName nvarchar (50) NULL,
	Email nvarchar (50) NULL,
	Extension nvarchar (50) NULL,
	CellPhone nvarchar (50) NULL,
	DivisionID int NULL,
	MakeSale nvarchar (50) NULL,
	AccessLvl nvarchar (50) NULL,
	FAXNum nvarchar (50) NULL,
	ARTransaction nvarchar (255) NULL,
	ARName nvarchar (255) NULL,
	ARID nvarchar (255) NULL,
	ARInvoice nvarchar (255) NULL,
	OEWork nvarchar (50) NULL,
	OEPO nvarchar (50) NULL,
	OEInvoice nvarchar (50) NULL,
	OEUninvoiced nvarchar (50) NULL,
	APCheck nvarchar (50) NULL,
	APInvoice nvarchar (50) NULL,
	ICSerial nvarchar (50) NULL,
	GLGL nvarchar (50) NULL,
	POWO nvarchar (50) NULL,
	POPO nvarchar (50) NULL,
	ReportsCategory nvarchar (50) NULL,
	ReportsSales nvarchar (50) NULL,
	ReportsCash nvarchar (50) NULL,
	ReportsDaily nvarchar (50) NULL,
	ARReports nvarchar (50) NULL,
	SHItem nvarchar (50) NULL,
	SHDesc nvarchar (50) NULL,
	UserControl nvarchar (50) NULL,
	EWQ nvarchar (50) NULL,
	EWPOA nvarchar (50) NULL,
	EWAcct nvarchar (50) NULL,
	EWWare nvarchar (50) NULL,
	EWDeleteWorkOrder nvarchar(50) NULL,
	EWViewAll nvarchar(50) NULL,
	APCR nvarchar (50) NULL,
	TPE nvarchar (50) NULL,
	CCA nvarchar (50) NULL,
	NEWS nvarchar (50) NULL,
	Invent nvarchar (50) NULL,
	Terminated bit NOT NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);

CREATE TABLE IntranetLogs.dbo.Userz_delete
(
	UserID int NOT NULL,
	SalesID nvarchar (255) NOT NULL,
	UPassword nvarchar (255) NULL,
	FirstName nvarchar (255) NULL,
	LastName nvarchar (50) NULL,
	Email nvarchar (50) NULL,
	Extension nvarchar (50) NULL,
	CellPhone nvarchar (50) NULL,
	DivisionID int NULL,
	MakeSale nvarchar (50) NULL,
	AccessLvl nvarchar (50) NULL,
	FAXNum nvarchar (50) NULL,
	ARTransaction nvarchar (255) NULL,
	ARName nvarchar (255) NULL,
	ARID nvarchar (255) NULL,
	ARInvoice nvarchar (255) NULL,
	OEWork nvarchar (50) NULL,
	OEPO nvarchar (50) NULL,
	OEInvoice nvarchar (50) NULL,
	OEUninvoiced nvarchar (50) NULL,
	APCheck nvarchar (50) NULL,
	APInvoice nvarchar (50) NULL,
	ICSerial nvarchar (50) NULL,
	GLGL nvarchar (50) NULL,
	POWO nvarchar (50) NULL,
	POPO nvarchar (50) NULL,
	ReportsCategory nvarchar (50) NULL,
	ReportsSales nvarchar (50) NULL,
	ReportsCash nvarchar (50) NULL,
	ReportsDaily nvarchar (50) NULL,
	ARReports nvarchar (50) NULL,
	SHItem nvarchar (50) NULL,
	SHDesc nvarchar (50) NULL,
	UserControl nvarchar (50) NULL,
	EWQ nvarchar (50) NULL,
	EWPOA nvarchar (50) NULL,
	EWAcct nvarchar (50) NULL,
	EWWare nvarchar (50) NULL,
	EWDeleteWorkOrder nvarchar(50) NULL,
	EWViewAll nvarchar(50) NULL,
	APCR nvarchar (50) NULL,
	TPE nvarchar (50) NULL,
	CCA nvarchar (50) NULL,
	NEWS nvarchar (50) NULL,
	Invent nvarchar (50) NULL,
	Terminated bit NOT NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);

CREATE TABLE IntranetLogs.dbo.Vendor_insert
(
	VendorID int NOT NULL,
	SalesID nvarchar (50) NULL,
	VendorName nvarchar (50) NULL,
	VendorNameAbb nvarchar (50) NULL,
	VendorContact nvarchar (50) NULL,
	VendorEmail nvarchar (50) NULL,
	VendorPhone nvarchar (50) NULL,
	VendorFax nvarchar (50) NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);

CREATE TABLE IntranetLogs.dbo.Vendor_update
(
	VendorID int NOT NULL,
	SalesID nvarchar (50) NULL,
	VendorName nvarchar (50) NULL,
	VendorNameAbb nvarchar (50) NULL,
	VendorContact nvarchar (50) NULL,
	VendorEmail nvarchar (50) NULL,
	VendorPhone nvarchar (50) NULL,
	VendorFax nvarchar (50) NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);

CREATE TABLE IntranetLogs.dbo.Vendor_delete
(
	VendorID int NOT NULL,
	SalesID nvarchar (50) NULL,
	VendorName nvarchar (50) NULL,
	VendorNameAbb nvarchar (50) NULL,
	VendorContact nvarchar (50) NULL,
	VendorEmail nvarchar (50) NULL,
	VendorPhone nvarchar (50) NULL,
	VendorFax nvarchar (50) NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);

CREATE TABLE IntranetLogs.dbo.newItem_insert
(
	NewItemID int NOT NULL,
	ItemID nvarchar (50) NULL,
	SPNumber nvarchar (50) NULL,
	ItemDesc nvarchar (255) NULL,
	WONum nvarchar (50) NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);
CREATE TABLE IntranetLogs.dbo.newItem_update
(
	NewItemID int NOT NULL,
	ItemID nvarchar (50) NULL,
	SPNumber nvarchar (50) NULL,
	ItemDesc nvarchar (255) NULL,
	WONum nvarchar (50) NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);
CREATE TABLE IntranetLogs.dbo.newItem_delete
(
	NewItemID int NOT NULL,
	ItemID nvarchar (50) NULL,
	SPNumber nvarchar (50) NULL,
	ItemDesc nvarchar (255) NULL,
	WONum nvarchar (50) NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);

