IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'WorkOrder_insert')
	DROP TABLE IntranetLogs..WorkOrder_insert;

CREATE TABLE IntranetLogs.dbo.WorkOrder_insert
(
	WONumber int NOT NULL, 
	QID int NULL, 
	SPNumber nvarchar (50) NULL, 
	PreparedByID varchar(20) NULL,
	WODate nvarchar (50) NULL, 
	CustomerPO nvarchar (50) NULL, 
	Attn nvarchar (50) NULL, 
	Phone nvarchar (50) NULL, 
	QuoteDate nvarchar (50) NULL, 
	Terms nvarchar (50) NULL, 
	WOCustomer nvarchar (50) NULL, 
	WONumbers nvarchar (50) NULL, 
	ShippingMeth nvarchar (50) NULL, 
	WONote nvarchar(2000) NULL, 
	WODelivery nvarchar (50) NULL, 
	WOFreight nvarchar (50) NULL, 
	FreightMisc nvarchar (50) NULL, 
	WOTaxRate nvarchar(50)  NULL, 
	WOTax nvarchar (50) NULL, 
	WOtaxable nvarchar (50) NULL, 
	WC nvarchar (50) NULL, 
	Status int NULL, 
	create_dt smalldatetime DEFAULT GETDATE() NULL
);

IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'WorkOrder_update')
	DROP TABLE IntranetLogs..WorkOrder_update;

CREATE TABLE IntranetLogs.dbo.WorkOrder_update
(
	WONumber int NOT NULL, 
	QID int NULL, 
	SPNumber nvarchar (50) NULL, 
	PreparedByID varchar(20) NULL,
	WODate nvarchar (50) NULL, 
	CustomerPO nvarchar (50) NULL, 
	Attn nvarchar (50) NULL, 
	Phone nvarchar (50) NULL, 
	QuoteDate nvarchar (50) NULL, 
	Terms nvarchar (50) NULL, 
	WOCustomer nvarchar (50) NULL, 
	WONumbers nvarchar (50) NULL, 
	ShippingMeth nvarchar (50) NULL, 
	WONote nvarchar(2000) NULL, 
	WODelivery nvarchar (50) NULL, 
	WOFreight nvarchar (50) NULL, 
	FreightMisc nvarchar (50) NULL, 
	WOTaxRate nvarchar(50)  NULL, 
	WOTax nvarchar (50) NULL, 
	WOtaxable nvarchar (50) NULL, 
	WC nvarchar (50) NULL, 
	Status int NULL, 
	create_dt smalldatetime DEFAULT GETDATE() NULL
);

IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'WorkOrder_delete')
	DROP TABLE IntranetLogs..WorkOrder_delete;

CREATE TABLE IntranetLogs.dbo.WorkOrder_delete
(
	WONumber int NOT NULL, 
	QID int NULL, 
	SPNumber nvarchar (50) NULL, 
	PreparedByID varchar(20) NULL,
	WODate nvarchar (50) NULL, 
	CustomerPO nvarchar (50) NULL, 
	Attn nvarchar (50) NULL, 
	Phone nvarchar (50) NULL, 
	QuoteDate nvarchar (50) NULL, 
	Terms nvarchar (50) NULL, 
	WOCustomer nvarchar (50) NULL, 
	WONumbers nvarchar (50) NULL, 
	ShippingMeth nvarchar (50) NULL, 
	WONote nvarchar(2000) NULL, 
	WODelivery nvarchar (50) NULL, 
	WOFreight nvarchar (50) NULL, 
	FreightMisc nvarchar (50) NULL, 
	WOTaxRate nvarchar(50)  NULL, 
	WOTax nvarchar (50) NULL, 
	WOtaxable nvarchar (50) NULL, 
	WC nvarchar (50) NULL, 
	Status int NULL, 
	create_dt smalldatetime DEFAULT GETDATE() NULL
);


IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'WODetail_insert')
	DROP TABLE IntranetLogs..WODetail_insert;

CREATE TABLE IntranetLogs.dbo.WODetail_insert
(
	WOLineNum int NOT NULL, 
	WONumber int NULL, 
	LineNum int NULL, 
	WOCost nvarchar (50) NULL, 
	WOItemNum nvarchar (50) NULL, 
	WOQTY nvarchar (50) NULL, 
	WODesc varchar (1000) NULL, 
	WOUPrice nvarchar (50) NULL, 
	VendorID nvarchar (50) NULL, 
	CTID nvarchar (50) NULL, 
	WOVenNum nvarchar (50) NULL, 
	ItemPO nvarchar (50) NULL, 
	ItemRec nvarchar (50) NULL, 
	ItemShip nvarchar (50) NULL, 
	create_dt smalldatetime DEFAULT GETDATE() NULL
);


IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'WODetail_update')
	DROP TABLE IntranetLogs..WODetail_update;

CREATE TABLE IntranetLogs.dbo.WODetail_update
(
	WOLineNum int NOT NULL, 
	WONumber int NULL, 
	LineNum int NULL, 
	WOCost nvarchar (50) NULL, 
	WOItemNum nvarchar (50) NULL, 
	WOQTY nvarchar (50) NULL, 
	WODesc varchar (1000) NULL, 
	WOUPrice nvarchar (50) NULL, 
	VendorID nvarchar (50) NULL, 
	CTID nvarchar (50) NULL, 
	WOVenNum nvarchar (50) NULL, 
	ItemPO nvarchar (50) NULL, 
	ItemRec nvarchar (50) NULL, 
	ItemShip nvarchar (50) NULL, 
	create_dt smalldatetime DEFAULT GETDATE() NULL
);


IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'WODetail_delete')
	DROP TABLE IntranetLogs..WODetail_delete;

CREATE TABLE IntranetLogs.dbo.WODetail_delete
(
	WOLineNum int NOT NULL, 
	WONumber int NULL, 
	LineNum int NULL, 
	WOCost nvarchar (50) NULL, 
	WOItemNum nvarchar (50) NULL, 
	WOQTY nvarchar (50) NULL, 
	WODesc varchar (1000) NULL, 
	WOUPrice nvarchar (50) NULL, 
	VendorID nvarchar (50) NULL, 
	CTID nvarchar (50) NULL, 
	WOVenNum nvarchar (50) NULL, 
	ItemPO nvarchar (50) NULL, 
	ItemRec nvarchar (50) NULL, 
	ItemShip nvarchar (50) NULL, 
	create_dt smalldatetime DEFAULT GETDATE() NULL
);


IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'WorkOrderStatus_insert')
	DROP TABLE IntranetLogs..WorkOrderStatus_insert;

CREATE TABLE IntranetLogs.dbo.WorkOrderStatus_insert
(
	WorkOrderStatusID 	TINYINT NOT NULL,
	WorkOrderStatus		VARCHAR(20)
);

IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'WorkOrderStatus_update')
	DROP TABLE IntranetLogs..WorkOrderStatus_update;

CREATE TABLE IntranetLogs.dbo.WorkOrderStatus_update
(
	WorkOrderStatusID 	TINYINT NOT NULL,
	WorkOrderStatus		VARCHAR(20)
);

IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'WorkOrderStatus_delete')
	DROP TABLE IntranetLogs..WorkOrderStatus_delete;

CREATE TABLE IntranetLogs.dbo.WorkOrderStatus_delete
(
	WorkOrderStatusID 	TINYINT NOT NULL,
	WorkOrderStatus		VARCHAR(20)
);

IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'CustShip_insert')
	DROP TABLE IntranetLogs..CustShip_insert;

CREATE TABLE IntranetLogs.dbo.CustShip_insert
(
	WONumber int NULL, 
	QID int NULL, 
	CustomerNum nvarchar (50) NULL, 
	CustName nvarchar (50) NULL, 
	CustAdd1 nvarchar (50) NULL, 
	CustAdd2 nvarchar (50) NULL, 
	CustAdd3 nvarchar (50) NULL, 
	CustAdd4 nvarchar (255) NULL, 
	CustState nvarchar (50) NULL, 
	CustCity nvarchar (50) NULL, 
	CustZip nvarchar (50) NULL, 
	create_dt smalldatetime DEFAULT GETDATE() NULL
);

IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'CustShip_update')
	DROP TABLE IntranetLogs..CustShip_update;

CREATE TABLE IntranetLogs.dbo.CustShip_update
(
	WONumber int NULL, 
	QID int NULL, 
	CustomerNum nvarchar (50) NULL, 
	CustName nvarchar (50) NULL, 
	CustAdd1 nvarchar (50) NULL, 
	CustAdd2 nvarchar (50) NULL, 
	CustAdd3 nvarchar (50) NULL, 
	CustAdd4 nvarchar (255) NULL, 
	CustState nvarchar (50) NULL, 
	CustCity nvarchar (50) NULL, 
	CustZip nvarchar (50) NULL, 
	create_dt smalldatetime DEFAULT GETDATE() NULL
);

IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'CustShip_delete')
	DROP TABLE IntranetLogs..CustShip_delete;

CREATE TABLE IntranetLogs.dbo.CustShip_delete
(
	WONumber int NULL, 
	QID int NULL, 
	CustomerNum nvarchar (50) NULL, 
	CustName nvarchar (50) NULL, 
	CustAdd1 nvarchar (50) NULL, 
	CustAdd2 nvarchar (50) NULL, 
	CustAdd3 nvarchar (50) NULL, 
	CustAdd4 nvarchar (255) NULL, 
	CustState nvarchar (50) NULL, 
	CustCity nvarchar (50) NULL, 
	CustZip nvarchar (50) NULL, 
	create_dt smalldatetime DEFAULT GETDATE() NULL
);

IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'WOPO_insert')
	DROP TABLE IntranetLogs..WOPO_insert;


CREATE TABLE IntranetLogs.dbo.WOPO_insert
(
	POID int NOT NULL,
	WONumber int NULL,
	POIDs nvarchar (50) NULL,
	PONum nvarchar (50) NULL,
	POShip nvarchar (50) NULL,
	Method nvarchar (50) NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL
);

IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'WOPO_update')
	DROP TABLE IntranetLogs..WOPO_update;


CREATE TABLE IntranetLogs.dbo.WOPO_update
(
	POID int NOT NULL,
	WONumber int NULL,
	POIDs nvarchar (50) NULL,
	PONum nvarchar (50) NULL,
	POShip nvarchar (50) NULL,
	Method nvarchar (50) NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL
);
IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'WOPO_delete')
	DROP TABLE IntranetLogs..WOPO_delete;


CREATE TABLE IntranetLogs.dbo.WOPO_delete
(
	POID int NOT NULL,
	WONumber int NULL,
	POIDs nvarchar (50) NULL,
	PONum nvarchar (50) NULL,
	POShip nvarchar (50) NULL,
	Method nvarchar (50) NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL
);

IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'Emails_insert')
	DROP TABLE IntranetLogs..Emails_insert;


CREATE TABLE IntranetLogs.dbo.Emails_insert
(
	EmailID int NOT NULL,
	ToEmail nvarchar (100) NULL,
	FromEmail nvarchar (100) NULL,
	Subject nvarchar(200) NULL,
	BodyText varchar(8000) NULL,
	isHTML int NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
)
IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'Emails_update')
	DROP TABLE IntranetLogs..Emails_update;


CREATE TABLE IntranetLogs.dbo.Emails_update
(
	EmailID int NOT NULL,
	ToEmail nvarchar (100) NULL,
	FromEmail nvarchar (100) NULL,
	Subject nvarchar(200) NULL,
	BodyText varchar(8000) NULL,
	isHTML int NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
)
GO

