IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Triggers_create' AND TYPE = 'P')
	DROP PROCEDURE sp_Triggers_create;
GO


CREATE PROCEDURE sp_Triggers_create
AS
	DECLARE @DatabaseName	VARCHAR(30);
	DECLARE @TableName	VARCHAR(30);
	DECLARE @SQL		NVARCHAR(3000);
	DECLARE @TriggerMethod	NVARCHAR(100);

	SET @DatabaseName = 'IntranetLogs';

	--EXEC sp_Triggers_drop;

	DECLARE triggerCursor CURSOR FOR SELECT NAME FROM sysobjects WHERE TYPE = 'U' AND LEFT(NAME, 2) <> 'dt' ORDER BY NAME;
	OPEN triggerCursor
	FETCH NEXT FROM triggerCursor INTO @TableName;



	WHILE @@FETCH_STATUS = 0
		BEGIN
		
			/********* INSERT *****************/
			SET @TriggerMethod = 'insert';
			SET @SQL = 'CREATE TRIGGER tr_' + @TableName + '_' + @TriggerMethod + ' ON ' + @TableName + ' FOR INSERT' + CHAR(10);
			SET @SQL = @SQL + 'AS' + CHAR(10) + CHAR(10);
			SET @SQL = @SQL + CHAR(9) + 'INSERT INTO ' + @DatabaseName + '.dbo.' + @TableName + '_' + @TriggerMethod + ' SELECT * FROM inserted;' + CHAR(10);
			PRINT @SQL;
			EXEC sp_executesql @SQL;
			PRINT 'EXECUTED';
			PRINT '*************************************';

			/********* UPDATE *****************/
			SET @TriggerMethod = 'update';
			SET @SQL = 'CREATE TRIGGER tr_' + @TableName + '_' + @TriggerMethod + ' ON ' + @TableName + ' FOR UPDATE' + CHAR(10);
			SET @SQL = @SQL + 'AS' + CHAR(10) + CHAR(10);
			SET @SQL = @SQL + CHAR(9) + 'INSERT INTO ' + @DatabaseName + '.dbo.' + @TableName + '_' + @TriggerMethod + ' SELECT * FROM inserted;' + CHAR(10);
			PRINT @SQL;
			EXEC sp_executesql @SQL;
			PRINT 'EXECUTED';
			PRINT '*************************************';



			/********* DELETE *****************/
			SET @TriggerMethod = 'delete';
			SET @SQL = 'CREATE TRIGGER tr_' + @TableName + '_' + @TriggerMethod + ' ON ' + @TableName + ' FOR DELETE' + CHAR(10);
			SET @SQL = @SQL + 'AS' + CHAR(10) + CHAR(10);
			SET @SQL = @SQL + CHAR(9) + 'INSERT INTO ' + @DatabaseName + '.dbo.' + @TableName + '_' + @TriggerMethod + ' SELECT * FROM deleted;' + CHAR(10);
			PRINT @SQL;
			EXEC sp_executesql @SQL;
			PRINT 'EXECUTED';
			PRINT '*************************************';



			FETCH NEXT FROM triggerCursor INTO @TableName;
		END

	--PRINT @TotalSQL;

	CLOSE triggerCursor	
	DEALLOCATE triggerCursor	

GO

EXEC sp_Triggers_create;

--SELECT * FROM Intranet_backup..sysobjects;