IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Carrier_update' AND TYPE = 'P')
	DROP PROCEDURE sp_Carrier_update;
GO


CREATE PROCEDURE sp_Carrier_update
	@CarrierAbb		NVARCHAR(50),
	@CarrierName		NVARCHAR(50),
	@DSType			NVARCHAR(50),
	@CarrierID		INT
AS

	UPDATE Carrier SET
		CarrierAbb = @CarrierAbb,
		CarrierName = @CarrierName,
		DSType = @DSType
	WHERE
		DSID = @CarrierID;
GO

--EXEC sp_Carrier_update;

