-- BACKUPS
DROP INDEX Backups.IDX_Backups_UserID_BackupDate;
GO
CREATE INDEX IDX_Backups_UserID_BackupDate ON Backups(UserID, BackupDate) ON INDEXES
GO
-- BALANCE
DROP INDEX Balance.IDX_Balance_UserID_BalanceDate;
GO
CREATE INDEX IDX_Balance_UserID_BalanceDate ON Balance(UserID, BalanceDate) ON INDEXES
GO
DROP INDEX Balance.IDX_Balance_UserID;
GO
CREATE INDEX IDX_Balance_UserID ON Balance(UserID) ON INDEXES
GO
DROP INDEX Balance.IDX_Balance_TransactionID;
GO
CREATE INDEX IDX_Balance_TransactionID ON Balance(TransactionID) ON INDEXES
GO
DROP INDEX Balance.IDX_Balance_BalanceDate;
GO
CREATE INDEX IDX_Balance_BalanceDate ON Balance(BalanceDate) ON INDEXES
GO
-- CCBALANCE
DROP INDEX CCBalance.IDX_CCBalance_CCID_CCDate;
GO
CREATE INDEX IDX_CCBalance_CCID_CCDate ON CCBalance(CCID, CCDate) ON INDEXES
GO
DROP INDEX CCBalance.IDX_CCBalance_CCID;
GO
CREATE INDEX IDX_CCBalance_CCID ON CCBalance(CCID) ON INDEXES
GO
DROP INDEX CCBalance.IDX_CCBalance_CCDate;
GO
CREATE INDEX IDX_CCBalance_CCDate ON CCBalance(CCDate) ON INDEXES
GO
-- COMPANIES
DROP INDEX Companies.IDX_Companies_UserID;
GO
CREATE INDEX IDX_Companies_UserID ON Companies(UserID) ON INDEXES
GO
-- CONTACTS
DROP INDEX Contacts.IDX_Contacts_UserID;
GO
CREATE INDEX IDX_Contacts_UserID ON Contacts(UserID) ON INDEXES
GO
-- CREDITCARD
DROP INDEX CreditCard.IDX_CreditCard_UserID;
GO
CREATE INDEX IDX_CreditCard_UserID ON CreditCard(UserID) ON INDEXES
GO
-- CREDITCARD
DROP INDEX CreditCard.IDX_CreditCard_UserID;
GO
CREATE INDEX IDX_CreditCard_UserID ON CreditCard(UserID) ON INDEXES
GO
-- HOURS
DROP INDEX Hours.IDX_Hours_CompanyID;
GO
CREATE INDEX IDX_Hours_CompanyID ON Hours(CompanyID) ON INDEXES
GO
DROP INDEX Hours.IDX_Hours_WorkDate;
GO
CREATE INDEX IDX_Hours_WorkDate ON Hours(WorkDate) ON INDEXES
GO
-- LOGINS
DROP INDEX Logins.IDX_Logins_UserID;
GO
CREATE INDEX IDX_Logins_UserID ON Logins(UserID) ON INDEXES
GO
DROP INDEX Logins.IDX_Logins_LoginDate;
GO
CREATE INDEX IDX_Logins_LoginDate ON Logins(LoginDate) ON INDEXES
GO
-- LOGINS
DROP INDEX Logs.IDX_Logs_LogDate;
GO
CREATE INDEX IDX_Logs_LogDate ON Logs(LogDate) ON INDEXES
GO
-- PAYCHECKS
DROP INDEX Paychecks.IDX_Paychecks_CompanyID;
GO
CREATE INDEX IDX_Paychecks_CompanyID ON Paychecks(CompanyID) ON INDEXES
GO
DROP INDEX Paychecks.IDX_Paychecks_PaymentDate;
GO
CREATE INDEX IDX_Paychecks_PaymentDate ON Paychecks(PaymentDate) ON INDEXES
GO
-- PERSONALDAYS
DROP INDEX PersonalDays.IDX_PersonalDays_CompanyID;
GO
CREATE INDEX IDX_PersonalDays_CompanyID ON PersonalDays(CompanyID) ON INDEXES
GO
DROP INDEX PersonalDays.IDX_PersonalDays_PersonalDate;
GO
CREATE INDEX IDX_PersonalDays_PersonalDate ON PersonalDays(PersonalDate) ON INDEXES
GO
-- PROFILER
DROP INDEX Profiler.IDX_Profiler_EndTime;
GO
CREATE INDEX IDX_Profiler_EndTime ON Profiler(EndTime) ON INDEXES
GO
-- REMINDERS
DROP INDEX Reminders.IDX_Reminders_UserID
GO
CREATE INDEX IDX_Reminders_UserID ON Reminders(UserID) ON INDEXES
GO
DROP INDEX Reminders.IDX_Reminders_ReminderDate
GO
CREATE INDEX IDX_Reminders_ReminderDate ON Reminders(ReminderDate) ON INDEXES
GO
-- SICKDAYS
DROP INDEX Sickdays.IDX_Sickdays_CompanyID;
GO
CREATE INDEX IDX_Sickdays_CompanyID ON Sickdays(CompanyID) ON INDEXES
GO
DROP INDEX Sickdays.IDX_Sickdays_SickDate;
GO
CREATE INDEX IDX_Sickdays_SickDate ON Sickdays(SickDate) ON INDEXES
GO
-- USERS
DROP INDEX Users.UDX_Users_UserName;
GO
CREATE UNIQUE CLUSTERED INDEX UDX_Users_UserName ON Users(UserName) ON INDEXES
GO
DROP INDEX Users.IDX_Users_UserName;
GO
CREATE INDEX IDX_Users_UserName ON Users(UserName) ON INDEXES
GO
DROP INDEX Users.IDX_Users_Password;
GO
CREATE INDEX IDX_Users_Password ON Users(Password) ON INDEXES
GO
