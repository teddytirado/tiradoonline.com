EXEC master..sp_dropdevice teddy_dmp, delfile;
GO
EXEC master..sp_addumpdevice 'DISK', 'teddy_dmp', 'e:\www\teddy\data\teddy.dmp';
GO
BACKUP DATABASE teddy TO teddy_dmp;
GO
BACKUP LOG teddy TO teddy_dmp;
GO
