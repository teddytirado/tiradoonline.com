IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Carrier_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Carrier_get;
GO


CREATE PROCEDURE sp_Carrier_get
	@CarrierID		INT = NULL
AS

	IF @CarrierID IS NULL
		BEGIN 
			SELECT 
				Carrier = CarrierAbb + ' - ' + DSType
			FROM
				Carrier
			ORDER BY
				CarrierAbb;

		END
	ELSE
		BEGIN
			SELECT 
				Carrier = CarrierAbb + ' - ' + DSType
			FROM
				Carrier
			WHERE
				DSID = @CarrierID
			ORDER BY
				CarrierAbb;
		END
GO

EXEC sp_Carrier_get;

