<script language="JavaScript">
<!--
		function LeaveQuotePage(message, redirect_page)
		{
			if(confirm(message))
				location.href = redirect_page;
		}
	
//-->
</script>
<%
	QuoteText = "Create New Quote"
	sql_menu = "SELECT * FROM PreQuote WHERE PreparedByID = " & Session("SalesID")
	Set ors_Menu = oConn.Execute(sql_menu)
	OpenQuote = false
	If NOT ors_Menu.EOF Then
		OpenQuote = true
		QuoteText = "Continue Creating Quote"
		ors_Menu.Close
	End If
	Set ors_Menu = Nothing
	
	Function isQuotePage(redirect_page)
		redirect_page = Replace(redirect_page, "/", "\/")
		If Instr(SCRIPT_NAME, "quote_create2.asp") > 0 OR Instr(SCRIPT_NAME, "quote_create_preview.asp") > 0 Then
			isQuotePage = "javascript:LeaveQuotePage(\'Are you sure you want to leave creating your Quote\', \'" & redirect_page & "\')"
		Else
			isQuotePage = redirect_page
		End If
	End Function
%>
<script language="JavaScript">
<!--
// items structure
// each item is the array of one or more properties:
// [text, link, settings, subitems ...]
// use the builder to export errors free structure if you experience problems with the syntax

var MENU_ITEMS = [
	['Intranet', null, null,
		['Home\/My Profile', '<%= isQuotePage("/home.asp") %>', null,
		],
		['Attendance Calendar', '/administration/attendance_calendar.asp', null,
		],
		// this is how custom javascript code can be called from the item
		// note how apostrophes are escaped inside the string, i.e. 'Don't' must be 'Don\'t'
		['Company Policies', '<%= isQuotePage("/intranet/company_policies/default.asp") %>', null,
		],
		['Telephone Setup Guide', 'javascript:alert(\'Under Construction!\')', null,
		],
		['Internal Phone/Fax', 'javascript:alert(\'Under Construction!\')', null,
		],
		['Credit Application', 'javascript:alert(\'Under Construction!\')', null,
		],
		['Photos', '/intranet/photos/photos.asp', null,
		],
		['Inventory', 'javascript:alert(\'Under Construction!\')', null,],
		['Timesheet', null, null,
			['Timesheet', '/timesheet/timesheet.asp', null,],
			['Reports', '/timesheet/reports.asp', null,],
			['Yearly', '/timesheet/yearly.asp', null,],
			['Settings', '/timesheet/settings.asp', null,],
		]
	],
	['e-Workorder', null, null,
		<% If Session("Quote") = "yes" OR Session("Administrator") Then %>
		['Quotes', null, null,
			<% If Session("Administrator") Then %>['Open Quotes', '<%= isQuotePage("/administration/open_quotes.asp") %>'],<% End IF %>
			<% If Session("Administrator") Then %>['Quote Templates', '<%= isQuotePage("/administration/quote_templates.asp") %>'],<% End IF %>
			['<%= QuoteText %>', '<%= isQuotePage("/eWorkOrder/pre_quote_create.asp") %>'],
			<% If Session("Administrator") Then %>
				['View ALL Quotes', '<%= isQuotePage("/eWorkOrder/quotes.asp") %>'],
			<% Else %>
				['View My Quotes', '<%= isQuotePage("/eWorkOrder/quotes.asp") %>'],
			<% End If %>
			['Search for a Quote', '<%= isQuotePage("/eWorkOrder/quotes_search.asp") %>'],
		],
		<% End If %>
		// this is how custom javascript code can be called from the item
		// note how apostrophes are escaped inside the string, i.e. 'Don't' must be 'Don\'t'
		<% If Session("Quote") = "yes" OR Session("POAllocation") = "yes" OR Session("Accounting") = "yes" OR Session("Warehouse") = "yes" Then %>
		['Work Order', null, null,
			<% If Session("Quote") = "yes" Then %>['Work Orders Still in PO', '<%= isQuotePage("/eWorkOrder/workorders_still_in_po.asp") %>'],<% End If %>
			<% If Session("POAllocation") = "yes" Then %>['PO Allocation', '<%= isQuotePage("/eWorkOrder/workorders_po_allocation.asp") %>'],<% End If %>
			<% If Session("Accounting") = "yes" Then %>['Accounting', '<%= isQuotePage("/eWorkOrder/workorders_accounting.asp") %>'],<% End If %>
			<% If Session("Warehouse") = "yes" Then %>
			['Warehouse', '<%= isQuotePage("/eWorkOrder/workorders_warehouse.asp") %>'],
			<% End If %>
			['Search/Status', '<%= isQuotePage("/eWorkOrder/workorders_search.asp") %>'],

		],
			<% End If %>
			<% If Session("AccessLvl") = "2" Then %>
		['Drop Ship', '<%= isQuotePage("/eWorkOrder/dropship.asp") %>', null,
			['View All Carrier', '<%= isQuotePage("/eWorkOrder/view_carrier.asp") %>'],
			['Add Carrier', '<%= isQuotePage("/eWorkOrder/add_carrier.asp") %>'],
			['Add Carrier Service', '<%= isQuotePage("/eWorkOrder/add_carrier_service.asp") %>'],
		],
		['Vendor List', '<%= isQuotePage("/eWorkOrder/vendor.asp") %>'],
			<% End If %>
	],
	['e-ACCPACC', null, null,
		<% If Session("ARTransaction") = "yes" OR Session("ARID") = "yes" OR Session("ARName") = "yes" OR Session("ARInvoice") = "yes" OR Session("Administrator") Then %>
		['Account Receivable', null, null,
			<% If Session("ARTransaction") = "yes" OR Session("Administrator") Then %>
			['AR/GL Transactions', '<%= isQuotePage("/accpac/argltrans.asp") %>', null],
			<% End If %>
			<% If Session("ARID") = "yes" OR Session("ARName") = "yes" OR Session("Administrator") Then %>
			['Customer Lookup', '<%= isQuotePage("/accpac/customer_lookup.asp") %>', null],
			<% End If %>
			<% If Session("ARInvoice") = "yes" OR Session("Administrator") Then %>
			['Open Invoices', null, null,
				['View&nbsp;All', '<%= isQuotePage("/accpac/open_invoices.asp?StartDate=0&EndDate=0") %>', null],
				['0&nbsp;-&nbsp;30&nbsp;Days', '<%= isQuotePage("/accpac/open_invoices.asp?StartDate=0&EndDate=30") %>', null],
				['31&nbsp;-&nbsp;60&nbsp;Days', '<%= isQuotePage("/accpac/open_invoices.asp?StartDate=31&EndDate=60") %>', null],
				['61&nbsp;-&nbsp;90&nbsp;Days', '<%= isQuotePage("/accpac/open_invoices.asp?StartDate=61&EndDate=90") %>', null],
				['Over&nbsp;90&nbsp;Days', '<%= isQuotePage("/accpac/open_invoices.asp?StartDate=91&EndDate=0") %>', null],
			],
			<% End If %>
		],
			<% End If %>
		// this is how custom javascript code can be called from the item
		// note how apostrophes are escaped inside the string, i.e. 'Don't' must be 'Don\'t'
		<% If Session("OEWork") = "yes" OR Session("OEInvoice") = "yes" OR Session("OEPO") = "yes" OR Session("OEUnInvoice") = "yes" OR Session("Administrator") Then %>
		['Order Entry', null, null,
			<% If Session("OEWork") = "yes" OR Session("Administrator") Then %>
			['Work Order Lookup', '<%= isQuotePage("/accpac/invoicelook.asp") %>', null],
			<% End If %>
			<% If Session("OEInvoice") = "yes" OR Session("Administrator") Then %>
			['Invoice Detail Lookup', '<%= isQuotePage("/accpac/detail_invoicelook.asp") %>', null],
			<% End If %>
			<% If Session("OEPO") = "yes" OR Session("Administrator") Then %>
			['Invoice Lookup by Cust. PO', '<%= isQuotePage("/accpac/invLookup_by_Po.asp") %>', null],
			<% End If %>
			<% If Session("OEUninvoiced") = "yes" OR Session("Administrator") Then %>
			['Uninvoiced Work Orders', '<%= isQuotePage("/accpac/overdue_ord.asp") %>', null],
			<% End If%>
		],
			<% End If%>
		<% If Session("SalesHistoryItemLookup") = "yes" OR Session("Administrator") OR Session("SalesHistoryDescription") = "yes" Then %>
		['Sales History', null, null,
			<% If Session("SalesHistoryItemLookup") = "yes" Then %>
			['Item Lookup', '/accpac/itemlookup.asp', null],
			<% End If%>
			<% If Session("SalesHistoryDescription") = "yes" OR Session("Administrator") Then %>
			['Item Lookup by Description', '<%= isQuotePage("/accpac/itemlookup_desc.asp") %>', null],
			<% End If%>
		],
			<% End If%>
		<% If Session("POPO") = "yes" OR Session("ReportsSales") = "yes" OR Session("ReportsCash") = "yes" OR Session("ReportsDaily") = "yes" OR Session("Administrator") Then %>
		['Reports', null, null,
			<% If Session("POPO") = "yes" OR Session("Administrator") Then %>
			['Category Reports', '<%= isQuotePage("/accpac/reports/compaq_ab.asp") %>', null],
			<% End If %>
			<% If Session("ReportsSales") = "yes" OR Session("Administrator") Then %>
			['Sales History Reports', '<%= isQuotePage("/accpac/reports/sales_history.asp") %>', null],
			<% End If  %>
			<% If Session("ReportsCash") = "yes" OR Session("Administrator") Then %>
			['Cash Receipts', '<%= isQuotePage("/accpac/reports/cashrec.asp") %>', null],
			<% End If %>
			<% If Session("ReportsDaily") = "yes" OR Session("Administrator") Then %>
			['Daily Flash', '<%= isQuotePage("/accpac/reports/dailyflash.asp") %>', null],
			<% End If %>
		],
			<% End If %>
			<% If Session("APCheck") = "yes" OR Session("APInvoice") = "yes" OR Session("APCR") = "yes" OR Session("Administrator") Then %>
		['Accounts Payable', null, null,
			<% If Session("APCheck") = "yes" OR Session("Administrator") Then %>
			['Check Lookup', '<%= isQuotePage("/accpac/check_lookup.asp") %>', null],
			<% End If %>
			<% If Session("APInvoice") = "yes" OR Session("Administrator") Then %>
			['Open Invoice', '<%= isQuotePage("/accpac/overdue_inv_ap.asp") %>', null],
			<% End If %>
			<% If Session("APCR") = "yes" OR Session("Administrator") Then %>
['Vendor Credit Reference', '<%= isQuotePage("/accpac/vendor_credit_reference/vendors.asp") %>', null],
			<% End If %>
		],
			<% End If %>
			<% If Session("ICSerial") = "yes" OR Session("Administrator") Then %>
		['Inventory Control', null, null,
			['Serial Number Lookup', '<%= isQuotePage("/accpac/serial_lookup.asp") %>', null],
		],
			<% End If %>
			<% If Session("GLGL") = "yes" OR Session("Administrator") Then %>
		['General Ledger', null, null,
			['GL Lookup', '<%= isQuotePage("/accpac/gl_detail_lookup.asp") %>', null],
		],
			<% End If %>
		<% If Session("POWO") = "yes" OR Session("POPO") = "yes" OR Session("Administrator") Then %>
		['Purchase Order', null, null,
			<% If Session("POWO") = "yes" OR Session("Administrator") Then %>
			['PO Lookup by WO', '<%= isQuotePage("/accpac/polookup.asp") %>', null],
			<% End If %>
			<% If Session("POPO") = "yes" OR Session("Administrator") Then %>
			['PO Lookup by PO', '<%= isQuotePage("/accpac/polookup_by_po.asp") %>', null],
			<% End If %>
		],
			<% End If %>
		<% If Session("ARReports") = "yes" OR Session("Administrator") Then %>
		['A/R Reports', null, null,
			['A/R Aging by Alpha-All', '<%= isQuotePage("file://s:/crystalreports/ar_aged_sales_byname.exe") %>', null],
			['A/R Aging by Cust-All', '<%= isQuotePage("file://s:/crystalreports/ar_aged_sales_bynumber.exe") %>', null],
			['A/R Againg by Cust-Range', '<%= isQuotePage("file://s:/crystalreports/ar_aged_sales_bysales.exe") %>', null],
			['Statements of Acct-All', '<%= isQuotePage("file://s:/crystalreports/ar_aged_stmt.exe") %>', null],
			['Statements of Acct-Range', '<%= isQuotePage("file://s:/crystalreports/ar_aged_stmt_bycustomer.exe") %>', null],
		],
		<% End If %>
	],
		<% If Session("Service") = "yes" OR Session("Administrator") Then %>
		['Service', null, null,
			['Companies', null, null,
				<% If Session("CreateCompany") = "yes" OR Session("Administrator") Then %>
				['Create a new Company', '<%= isQuotePage("/service/companies.asp?Action=Create") %>', null],
				<% End If %>
				['View all Companies', '<%= isQuotePage("/service/companies.asp") %>', null],
			],
			['Service Reports', null, null,
				['Create New Service Report', '<%= isQuotePage("/service/service_report.asp?Action=Create") %>', null],
				['Last 100 Service Reports', '<%= isQuotePage("/service/service_report_100.asp") %>', null],
				['Search', '<%= isQuotePage("/service/service_report_search.asp") %>', null],
			],
		<% If Session("CreditMemo") = "yes" OR Session("Administrator") Then %>
			['Credit Memos', null, null,
		<% If Session("CreateCreditMemo") = "yes" OR Session("Administrator") Then %>
				['Create Credit Memo', '<%= isQuotePage("/service/credit_memo.asp?Action=Create") %>', null],
			<% End If %>
				['Last 100 Credit Memos', '<%= isQuotePage("/service/credit_memo_100.asp") %>', null],
		<% If Session("CreditMemoVendors") = "yes" OR Session("Administrator") Then %>
				['Vendors', '<%= isQuotePage("/service/vendors.asp?Letter=ALL") %>', null],
		<% End If %>
				['Search', '<%= isQuotePage("/service/credit_memo_search.asp") %>', null],
				],
		<% End If %>
		],
		<% End If %>
	['Help', null, null,
		['How to print a Quote', '<%= isQuotePage("/help/How_to_print_a_Quote.doc") %>', null,
		],
	],
	<% If Session("Administrator") Then %>
	['Control Panel', null, null,
		['Users', null, null,
			['New', '/administration/users.asp?SubmitButton=<%= Server.URLEncode("Create a User") %>'],
			['View All Users', '/administration/users.asp'],
			['Logins', '/administration/logins.asp'],
			['Invalid Logins', '/administration/invalid_logins.asp'],
			['Logged on Users', '/administration/logged_on_users.asp'],
			['Logged on Users', '/administration/logged_on_users.asp'],
		],
		['Vendor Credit Reference', '/administration/vendors_credit_reference.asp'],
		['Attendance Calendar', '/administration/attendance_calendar.asp', null,],
		['News', '/administration/news.asp', null,],
		['Company Policies', '/administration/company_policies.asp', null,],
		['Page Logs', '/administration/pagelogs.asp', null,],
		['Photos', 'javascript:alert(\'Under Construction!\')', null,],
	],
	<% End If %>
	['Logout', '/default.asp?SubmitButton=Logout', null,
	],
];

//-->
</script>