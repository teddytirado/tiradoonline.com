DELETE FROM ShippingAddressBook
--alter table ShippingAddressBook drop column SalesID
INSERT INTO ShippingAddressBook
	(CustomerID, CustomerName, Address1, Address2, Address3, Address4, City, StateID, ZipCode)

Select DISTINCT CustomerNum, CustName, CustAdd1, CustAdd2, CustAdd3, CustAdd4, CustCity, CustState, CustZip FROM CustShipQ
SELECT * FROM ShippingAddressBook
