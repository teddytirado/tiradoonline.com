IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_News_NewsID_get' AND TYPE = 'P')
	DROP PROCEDURE sp_News_NewsID_get;
GO


CREATE PROCEDURE sp_News_NewsID_get
	@NewsID		INT
AS

	SELECT
		NewsDate,
		Title,
		Body,
		create_dt
	FROM
		News
	WHERE
		NewsID = @NewsID;

GO

EXEC sp_News_NewsID_get 26

