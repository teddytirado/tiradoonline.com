IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_ServiceReport_ModelNumber_Search' AND TYPE = 'P')
	DROP PROCEDURE sp_ServiceReport_ModelNumber_Search;
GO


CREATE PROCEDURE sp_ServiceReport_ModelNumber_Search
	@ModelNumber		NVARCHAR(50),
	@StartDate 		DATETIME,
	@EndDate 		DATETIME
AS

	SET NOCOUNT ON;
	DECLARE @SQL_STRING VARCHAR(1000);

	SET @ModelNumber = '%' + @ModelNumber + '%';

	SET @SQL_STRING = 'SELECT 
		DISTINCT a.ModelNumber,
		COUNT(*) AS ServiceReportsTotal
	FROM
		ServicedSerialNumbers a,
		ServiceReport b
	WHERE
		a.ServiceReportNumber = b.ServiceReportNumber AND
		b.CompanyID IS NOT NULL AND
		UPPER(a.ModelNumber) LIKE UPPER(''' + @ModelNumber + ''')
	GROUP BY
		a.ModelNumber';

	PRINT @SQL_STRING;
	EXEC(@SQL_STRING);

GO

sp_ServiceReport_ModelNumber_Search '345', '1/1/2005', '10/12/2010'