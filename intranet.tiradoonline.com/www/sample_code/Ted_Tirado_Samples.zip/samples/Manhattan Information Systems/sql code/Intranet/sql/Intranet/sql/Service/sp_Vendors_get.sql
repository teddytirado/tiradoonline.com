IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Vendors_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Vendors_get;
GO


CREATE PROCEDURE sp_Vendors_get
AS

	SELECT 
		VendorID,
		VendorName
	FROM	
		Vendors
	ORDER BY
		VendorName;
	

GO

