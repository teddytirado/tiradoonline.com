IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_NewItem_insert' AND TYPE = 'P')
	DROP PROCEDURE sp_NewItem_insert;
GO


CREATE PROCEDURE sp_NewItem_insert
	@SalesID		INT,
	@VendorID		INT,
	@VendorItem		VARCHAR(50),
	@MFGPart		VARCHAR(50),
	@Cost			NUMERIC(9, 2),
	@ItemDescription	VARCHAR(3000)
AS

	
	IF NOT EXISTS (SELECT NewItemID FROM NewItem WHERE UPPER(MFGPart) = UPPER(@MFGPart))
		BEGIN
			INSERT INTO NewItem
				(SalesID, VendorID, VendorItem, MFGPart, Cost, ItemDescription)
			VALUES
				(@SalesID, @VendorID, @VendorItem, @MFGPart, @Cost, @ItemDescription)

			SELECT @@IDENTITY;
		END
	ELSE
		SELECT NULL;
	

GO
