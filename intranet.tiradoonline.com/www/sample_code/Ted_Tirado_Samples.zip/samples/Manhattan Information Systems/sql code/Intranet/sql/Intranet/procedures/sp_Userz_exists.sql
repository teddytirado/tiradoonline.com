IF EXISTS (SELECT NAME FROM SYSOBJECTS WHERE NAME = 'sp_Userz_exists' AND TYPE = 'P')
         DROP PROCEDURE sp_Userz_exists;
GO

CREATE PROCEDURE sp_Userz_exists
	@SalesID			VARCHAR(20)
AS

	SELECT 
		*
	FROM 
		Userz
	WHERE
		SalesID = @SalesID		
GO

 

EXEC sp_Userz_exists '999'

 