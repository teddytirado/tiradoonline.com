IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Userz_Attendance_StartTime_NotExists_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Userz_Attendance_StartTime_NotExists_get;
GO


CREATE PROCEDURE sp_Userz_Attendance_StartTime_NotExists_get
	@StartTime		SMALLDATETIME
AS

	SELECT 
		SalesID, 
		FullName = FirstName + ' ' + LastName
	FROM 
		Userz 
	WHERE 
		UserControl = 'yes' AND
		SalesID NOT IN (
					SELECT 
						SalesID 
					FROM 
						AttendanceWorkDays 
					WHERE 
						DATEPART(MONTH, StartTime) = DATEPART(MONTH, @StartTime) AND
						DATEPART(DAY, StartTime) = DATEPART(DAY, @StartTime) AND
						DATEPART(YEAR, StartTime) = DATEPART(YEAR, @StartTime)
				)
	ORDER BY 
		FirstName;

GO


EXEC sp_Userz_Attendance_StartTime_NotExists_get '2/11/08'