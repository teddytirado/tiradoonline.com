IF EXISTS (SELECT NAME FROM SYSOBJECTS WHERE NAME = 'vw_InvoiceHeader' AND TYPE = 'V')
	DROP VIEW vw_InvoiceHeader;
GO

CREATE VIEW vw_InvoiceHeader
AS

	SELECT 
		INVNUMBER AS InvoiceNumber,
		dbo.fn_ConvertToDate(INVDATE) AS InvoiceDate,
		SALESPER1 AS SalesID,
		SalesPerson = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = OEINVH.SALESPER1),
		CUSTOMER AS CustomerID,
		BILNAME AS CustomerName,
		BILADDR1 AS Address1,
		BILADDR2 AS Address2,
		BILCITY AS City,
		BILSTATE AS State,
		BILZIP AS ZipCode,
		BILPHONE AS Phone,
		BILFAX AS Fax,
		SHPNAME AS ShippingName,
		SHPADDR1 AS ShippingAddress1,
		SHPADDR2 AS ShippingAddress2,
		SHPCITY AS ShippingCity,
		SHPSTATE AS ShippingState,
		SHPZIP AS ShippingZipCode,
		SHPPHONE AS ShippingPhone,
		SHPFAX AS ShippingFax,
		PONumber,
		ORDNUMBER AS ReferenceNumber,
		dbo.fn_ConvertToDate(ORDDATE) AS OrderDate,
		SHIPVIA AS ShipVia,
		REFERENCE AS MISWONumber,
		TERMTTLDUE AS TotalDue
	FROM 
		OEINVH;
		
GO

SELECT TOP 2 * FROM vw_InvoiceHeader 