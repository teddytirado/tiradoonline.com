IF EXISTS (SELECT NAME FROM SYSOBJECTS WHERE NAME = 'vw_InvoiceDetail' AND TYPE = 'V')
	DROP VIEW vw_InvoiceDetail;
GO

CREATE VIEW vw_InvoiceDetail
AS

	SELECT 
		INVNUMBER AS InvoiceNumber,
		QTYORDERED AS Quantity,
		ITEM AS ItemNumber,
		[DESC] AS Description,
		Category,
		SerialNumber = 'No Serial',
		UnitPrice,
		ExtendedPrice = UnitPrice * QTYORDERED,
		UnitCost AS Cost,
		ExtendedCost = UnitCost * QTYORDERED,
		Profit = (UnitPrice * QTYORDERED) - (UnitCost * QTYORDERED),
		TAMOUNT1 AS Tax
	FROM 
		OEINVD;
GO

SELECT TOP 20 * FROM vw_InvoiceDetail WHERE InvoiceNumber = '44939'