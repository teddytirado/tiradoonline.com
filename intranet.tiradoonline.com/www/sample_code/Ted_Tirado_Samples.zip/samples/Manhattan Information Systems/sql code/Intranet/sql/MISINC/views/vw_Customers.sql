IF EXISTS (SELECT NAME FROM SYSOBJECTS WHERE NAME = 'vw_Customers' AND TYPE = 'V')
	DROP VIEW vw_Customers;
GO

CREATE VIEW vw_Customers
AS

	SELECT 
		IDCUST AS CustomerID,
		NAMECUST AS CustomerName,
		NAMECTAC AS ContactName,
		TEXTSTRE1 AS Address1,
		TEXTSTRE2 AS Address2,
		NAMECITY AS City,
		CODESTTE AS State,
		CODEPSTL AS ZipCode,
		TEXTPHON1 AS Phone,
		TEXTPHON2 AS Fax,
		CODETAXGRP AS TaxGroup,
		CODESLSP1 AS SalesID,
		SalesPerson = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = ARCUS.CODESLSP1),
		Email1 AS Email,
		Website
	FROM 
		ARCUS;
		
GO

SELECT TOP 2 * FROM ARCUS