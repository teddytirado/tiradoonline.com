IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Companies_delete' AND TYPE = 'P')
	DROP PROCEDURE sp_Companies_delete;
GO


CREATE PROCEDURE sp_Companies_delete
	@CompanyID	INT

AS

	DELETE FROM Companies WHERE CompanyID = @CompanyID;	

GO

