IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Quote_delete' AND TYPE = 'P')
	DROP PROCEDURE sp_Quote_delete;
GO


CREATE PROCEDURE sp_Quote_delete
	@QID		INT
AS

	BEGIN TRAN T1
		DELETE FROM CustShipQ WHERE QID = @QID;
		DELETE FROM QuoteDetail WHERE QID = @QID;
		DELETE FROM Quote WHERE QID = @QID;
	COMMIT TRAN T1

GO

--exec sp_Quote_delete