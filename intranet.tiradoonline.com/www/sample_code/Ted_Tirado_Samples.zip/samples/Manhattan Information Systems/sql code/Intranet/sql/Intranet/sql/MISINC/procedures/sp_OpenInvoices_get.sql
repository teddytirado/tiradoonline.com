IF EXISTS (SELECT NAME FROM SYSOBJECTS WHERE NAME = 'sp_OpenInvoices_get' AND TYPE = 'P')
	DROP PROCEDURE sp_OpenInvoices_get;
GO

CREATE PROCEDURE sp_OpenInvoices_get
	@SalesID		VARCHAR(2),
	@StartDate		INT,
	@EndDate		INT,
	@Administrator		BIT
AS

	IF @EndDate = 0
		BEGIN
			--SET @StartDate = 1
			SET @EndDate = (SELECT DATEDIFF(day, (SELECT MIN(dbo.fn_ConvertToDate(DATEINVC)) FROM AROBL), GETDATE()))
		END

	IF @Administrator = 1
		BEGIN
			SELECT 
				CustomerNumber = IDCUST, 
				CustomerName = (SELECT BILNAME FROM OEINVH WHERE INVNUMBER = AROBL.IDINVC), 
				InvoiceNumber = IDINVC, 
				InvoiceDate = DATEINVC, 
				--InvoiceDate2 = CONVERT(DATETIME, DATEINVC), 
				InvoiceDueDate = DATEDUE, 
				InvoiceAmount = AMTDUEHC, 
				CustomerPO = IDCUSTPO,
				SalesPerson = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = 
					CASE LEFT(AROBL.IDCUST, 2)
						WHEN 'HP' THEN 11
						WHEN 'MI' THEN 12
						WHEN 'TE' THEN 13
						ELSE CONVERT(INT, LEFT(AROBL.IDCUST, 2))
					END),
				InvoiceTotal = (SELECT TERMTTLDUE FROM OEINVH WHERE LTRIM(RTRIM(INVNUMBER)) = LTRIM(RTRIM(AROBL.IDINVC))),
				InvoicePaid = (SELECT ABS(SUM(AMTPAYMHC)) FROM AROBP WHERE LTRIM(RTRIM(IDINVC)) = LTRIM(RTRIM(AROBL.IDINVC))),
				InvoiceNotes = (SELECT TOP 1 InvoiceNoteID FROM Intranet..InvoiceNotes WHERE CONVERT(VARCHAR, InvoiceNo) = LTRIM(RTRIM(AROBL.IDINVC)))
			FROM 
				AROBL 
			WHERE 
				AMTDUEHC <> '0' AND
				DATEDIFF(day, dbo.fn_ConvertToDate(DATEINVC), GETDATE()) >= @StartDate AND
				DATEDIFF(day, dbo.fn_ConvertToDate(DATEINVC), GETDATE()) <= @EndDate
				
			ORDER BY 
				IDCUST;
		
		END
	ELSE
		BEGIN
			SELECT 
				CustomerNumber = IDCUST, 
				CustomerName = (SELECT BILNAME FROM OEINVH WHERE INVNUMBER = AROBL.IDINVC), 
				InvoiceNumber = IDINVC, 
				InvoiceDate = DATEINVC, 
				InvoiceDueDate = DATEDUE, 
				InvoiceAmount = AMTDUEHC, 
				CustomerPO = IDCUSTPO,
				SalesPerson = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = 
					CASE LEFT(AROBL.IDCUST, 2)
						WHEN 'HP' THEN 11
						WHEN 'MI' THEN 12
						WHEN 'TE' THEN 13
						ELSE CONVERT(INT, LEFT(AROBL.IDCUST, 2))
					END),
				InvoiceTotal = (SELECT TERMTTLDUE FROM OEINVH WHERE LTRIM(RTRIM(INVNUMBER)) = LTRIM(RTRIM(AROBL.IDINVC))),
				InvoicePaid = (SELECT ABS(SUM(AMTPAYMHC)) FROM AROBP WHERE LTRIM(RTRIM(IDINVC)) = LTRIM(RTRIM(AROBL.IDINVC))),
				InvoiceNotes = (SELECT TOP 1 InvoiceNoteID FROM Intranet..InvoiceNotes WHERE CONVERT(VARCHAR, InvoiceNo) = LTRIM(RTRIM(AROBL.IDINVC)))
			FROM 
				AROBL 
			WHERE 
				LEFT(IDCUST,2) = @SalesID AND
				AMTDUEHC <> '0' AND
				DATEDIFF(day, dbo.fn_ConvertToDate(DATEINVC), GETDATE()) >= @StartDate AND
				DATEDIFF(day, dbo.fn_ConvertToDate(DATEINVC), GETDATE()) <= @EndDate
			ORDER BY 
				IDCUST;
		END

		
GO

EXEC sp_OpenInvoices_get '99', 0, 0, 1 