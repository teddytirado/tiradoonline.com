IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_CreditMemo_Status_Search' AND TYPE = 'P')
	DROP PROCEDURE sp_CreditMemo_Status_Search;
GO


CREATE PROCEDURE sp_CreditMemo_Status_Search
	@Status				BIT,
	@StartDate			DATETIME,
	@EndDate			DATETIME
AS

	SELECT
		*,
		Vendor = (SELECT VendorName FROM Vendors WHERE VendorID = CreditMemo.VendorID),
		updated_by = (SELECT FirstName + ' '  + LastName FROM Intranet..Userz WHERE SalesID = CreditMemo.update_by),
		created_by = (SELECT FirstName + ' '  + LastName FROM Intranet..Userz WHERE SalesID = CreditMemo.create_by)
	FROM
		CreditMemo
	WHERE
		CreditMemoDate BETWEEN @StartDate AND @EndDate AND
		Status = @Status;
GO

EXEC sp_CreditMemo_Status_Search 0, '5/20/10', '5/27/10'