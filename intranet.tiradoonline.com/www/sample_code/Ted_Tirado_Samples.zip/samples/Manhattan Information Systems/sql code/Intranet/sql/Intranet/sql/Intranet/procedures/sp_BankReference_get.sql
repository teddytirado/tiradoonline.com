IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_BankReference_get' AND TYPE = 'P')
	DROP PROCEDURE sp_BankReference_get;
GO


CREATE PROCEDURE sp_BankReference_get

AS
		
	SELECT
		*
	FROM
		BankReference;

GO

EXEC sp_BankReference_get 