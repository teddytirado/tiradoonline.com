IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Companies_insert' AND TYPE = 'P')
	DROP PROCEDURE sp_Companies_insert;
GO


CREATE PROCEDURE sp_Companies_insert
	@CompanyName		NVARCHAR(50),
	@Address1		NVARCHAR(50),
	@Address2		NVARCHAR(50),
	@City			NVARCHAR(50),
	@StateID		NVARCHAR(3),
	@ZipCode		NVARCHAR(20),
	@create_by		VARCHAR(5)

AS
	
	IF NOT EXISTS (SELECT CompanyName FROM Companies WHERE CompanyName = @CompanyName AND Address1 = @Address1)
		BEGIN 
			INSERT INTO Companies
				(CompanyName,
				Address1,			
				Address2,
				City,
				StateID,
				ZipCode,
				update_by,
				create_by)
			VALUES
				(@CompanyName,
				@Address1,			
				@Address2,
				@City,
				@StateID,
				@ZipCode,
				@create_by,
				@create_by)
			

			SELECT CompanyID = @@IDENTITY;		
		END 
	ELSE
		SELECT CompanyID = 0;
GO

