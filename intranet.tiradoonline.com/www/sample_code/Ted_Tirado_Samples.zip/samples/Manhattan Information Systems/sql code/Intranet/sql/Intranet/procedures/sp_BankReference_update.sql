IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_BankReference_update' AND TYPE = 'P')
	DROP PROCEDURE sp_BankReference_update;
GO


CREATE PROCEDURE sp_BankReference_update
	@BankName 		VARCHAR(50),
	@Address1 		VARCHAR(50),
	@Address2 		VARCHAR(50),
	@City 			VARCHAR(50),
	@StateID 		VARCHAR(2),
	@ZipCode		VARCHAR(20),
	@Contact 		VARCHAR(50),
	@Phone 			VARCHAR(30),
	@Fax 			VARCHAR(20),
	@CheckingAccount 	VARCHAR(20),
	@SavingsAccount 	VARCHAR(20),
	@update_by 		VARCHAR(10)
AS
		
	UPDATE BankReference SET
		BankName = @BankName,
		Address1 = @Address1,
		Address2 = @Address2,
		City = @City,
		ZipCode = @ZipCode,
		StateID = @StateID,
		Contact = @Contact,
		Phone = @Phone,
		Fax = @Fax,
		CheckingAccount = @CheckingAccount,
		SavingsAccount = @SavingsAccount,
		update_by = @update_by
	WHERE 
		BankReferenceID = 1001;

GO

--EXEC sp_BankReference_update 