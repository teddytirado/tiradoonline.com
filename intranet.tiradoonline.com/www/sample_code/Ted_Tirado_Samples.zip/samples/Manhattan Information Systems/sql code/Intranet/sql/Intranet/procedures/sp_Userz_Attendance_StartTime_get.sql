IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Userz_Attendance_StartTime_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Userz_Attendance_StartTime_get;
GO


CREATE PROCEDURE sp_Userz_Attendance_StartTime_get
	@StartTime		SMALLDATETIME
AS

	SELECT 
		a.AttendanceWorkDayID,
		a.SalesID,
		FullName = b.FirstName + ' ' + b.LastName,
		c.AttendanceType,
		a.StartTime
	FROM 
		AttendanceWorkDays a,
		Userz b,
		AttendanceType c
	WHERE 
		a.SalesID = b.SalesID AND
		a.AttendanceTypeID = c.AttendanceTypeID AND
		DATEPART(MONTH, a.StartTime) = DATEPART(MONTH, @StartTime) AND
		DATEPART(DAY, a.StartTime) = DATEPART(DAY, @StartTime) AND
		DATEPART(YEAR, a.StartTime) = DATEPART(YEAR, @StartTime)
	ORDER BY 
		a.StartTime;

GO


EXEC sp_Userz_Attendance_StartTime_get '2/11/08'