IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_WODetail_WOLineNum_WODetailLineNum_move' AND TYPE = 'P')
	DROP PROCEDURE sp_WODetail_WOLineNum_WODetailLineNum_move;
GO


CREATE PROCEDURE sp_WODetail_WOLineNum_WODetailLineNum_move
	@WONumber			INT,
	@WOLineNum		INT,
	@WODetailLineNum	INT
AS

	DECLARE @OldLineNum		INT;
	DECLARE @NewWOLineNum		INT;

	SET @OldLineNum = (SELECT LineNum FROM WODetail WHERE WOLineNum = @WOLineNum);
	--PRINT 'OldLineNum: ' + CONVERT(VARCHAR, @OldLineNum);
	SET @NewWOLineNum = (SELECT WOLineNum FROM WODetail WHERE WONumber = @WONumber AND LineNum = @WODetailLineNum);
	UPDATE WODetail SET LineNum = @WODetailLineNum WHERE WOLineNum = @WOLineNum;
	--PRINT 'NewWOLineNum: ' + CONVERT(VARCHAR, NewWOLineNum);
	UPDATE WODetail SET LineNum = @OldLineNum WHERE WOLineNum = @NewWOLineNum;
GO

--exec sp_WODetail_WOLineNum_WODetailLineNum_move 17000, 36685, 4


--select top 10 * from WODetail order by create_dt desc
--UPDATE WODetail SET linenum = 3 where wolinenum = 36685
