IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_PurchaseOrderServicePrice_ServiceReportNumber_get' AND TYPE = 'P')
	DROP PROCEDURE sp_PurchaseOrderServicePrice_ServiceReportNumber_get;
GO


CREATE PROCEDURE sp_PurchaseOrderServicePrice_ServiceReportNumber_get
	@ServiceReportNumber	NVARCHAR(10)
AS

	SELECT 
		PurchaseOrderServicePriceID,
		PONumber,
		Quantity,
		PartNumber,
		Description,
		UnitPrice
	FROM	
		PurchaseOrderServicePrice
	WHERE
		ServiceReportNumber = @ServiceReportNumber
	ORDER BY
		create_dt
	

GO

