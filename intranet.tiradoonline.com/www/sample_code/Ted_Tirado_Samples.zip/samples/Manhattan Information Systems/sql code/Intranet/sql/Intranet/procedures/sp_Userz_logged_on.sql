IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Userz_logged_on' AND TYPE = 'P')
	DROP PROCEDURE sp_Userz_logged_on;
GO


CREATE PROCEDURE sp_Userz_logged_on
	@Minutes		INT
AS
	
	SELECT
		a.SalesID
	INTO 
		#tmpPageLogs
	FROM
		PageLogs a,
		Userz b
	WHERE
		DATEDIFF(mi, a.create_dt, GETDATE()) <= 180
	ORDER BY 
		a.create_dt;


	SELECT 
		DISTINCT SalesID,
		FullName = (SELECT FirstName + ' ' + LastName FROM Userz WHERE SalesID = #tmpPageLogs.SalesID)
		
	FROM
		#tmpPageLogs

GO

exec sp_Userz_logged_on 180