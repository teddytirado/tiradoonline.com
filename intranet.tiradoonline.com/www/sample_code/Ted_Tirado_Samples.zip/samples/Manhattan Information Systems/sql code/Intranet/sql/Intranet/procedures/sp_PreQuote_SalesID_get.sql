IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_PreQuote_SalesID_get' AND TYPE = 'P')
	DROP PROCEDURE sp_PreQuote_SalesID_get;
GO


CREATE PROCEDURE sp_PreQuote_SalesID_get
	@SalesID		VARCHAR(10)
AS
	SELECT * FROM PreQuote WHERE SalesID = @SalesID;
	SELECT a.* FROM PreQuoteDetail a, PreQuote b WHERE a.PreQID = b.PreQID AND b.SalesID = @SalesID;
	SELECT a.* FROM PreCustShipQ a, PreQuote b WHERE a.PreQID = b.PreQID AND b.SalesID = @SalesID;

GO

exec sp_PreQuote_SalesID_get '999'