IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_States_get' AND TYPE = 'P')
	DROP PROCEDURE sp_States_get;
GO


CREATE PROCEDURE sp_States_get
AS

	SELECT
		StateAbbr,
		StateName
	FROM
		States
	ORDER BY
		StateID;

GO

EXEC sp_States_get