alter TRIGGER tr_WODetail_update ON WODetail FOR UPDATE
AS	
	declare @car varchar(20)
	--INSERT INTO IntranetLogs..WODetail_update
	--SELECT * FROM INSERTED;

GO

drop trigger tr_WODetail_update