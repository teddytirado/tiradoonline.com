IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_TimesheetEntry_update' AND TYPE = 'P')
	DROP PROCEDURE sp_TimesheetEntry_update;
GO


CREATE PROCEDURE sp_TimesheetEntry_update
	@TimesheetEntryID	INT,
	@StartTime		DATETIME,
	@EndTime		DATETIME
AS
	
	UPDATE TimesheetEntry SET 
		start_time = @StartTime,
		end_time = @EndTime
	WHERE 
		TimesheetEntryID = @TimesheetEntryID;

GO

