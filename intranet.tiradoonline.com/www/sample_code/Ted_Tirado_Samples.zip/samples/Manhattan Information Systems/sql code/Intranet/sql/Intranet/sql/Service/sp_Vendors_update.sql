IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Vendors_update' AND TYPE = 'P')
	DROP PROCEDURE sp_Vendors_update;
GO


CREATE PROCEDURE sp_Vendors_update
	@VendorID		INT,
	@VendorName		VARCHAR(20),
	@update_by		VARCHAR(10)
AS

	UPDATE Vendors
		SET VendorName = @VendorName,
		update_by = @update_by,
		update_dt = GETDATE()
	WHERE
		VendorID = @VendorID 	
GO

--EXEC sp_Vendors_update 4545452, 167, 'tiradoonline.com', '999', '0.0825', '7/1/10', '9:00 am', '10:00 am', 'Remarks', 'Problems', 'Solutions', '7/2/10', '10:00 am', 1, 0, 1, 'other description', 'PO Number', 'WO Number', 0, 0.00, 0, 0.00, 0.00, 0.00, 0.00, 'Theodore Tirado', '347.414.1284', '3115', 0.00