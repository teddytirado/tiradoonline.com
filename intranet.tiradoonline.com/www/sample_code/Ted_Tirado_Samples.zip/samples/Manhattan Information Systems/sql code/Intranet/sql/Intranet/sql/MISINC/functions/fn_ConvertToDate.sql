ALTER FUNCTION fn_ConvertToDate (@StringDate VARCHAR(10))
RETURNS SMALLDATETIME
AS

	BEGIN
		DECLARE @StringMonth	VARCHAR(2);
		DECLARE @StringDay	VARCHAR(2);
		DECLARE @StringYear	VARCHAR(4);
		DECLARE @NewStringDate	SMALLDATETIME;

		SET @StringMonth = SUBSTRING(@StringDate, 5, 2);
		SET @StringDay = RIGHT(@StringDate, 2);
		SET @StringYear = LEFT(@StringDate, 4); 
		SET @NewStringDate = CONVERT(SMALLDATETIME, @StringMonth + '/' + @StringDay + '/' + @StringYear);

		--PRINT @NewStringDate;

	   	RETURN(@NewStringDate);
	END
GO

--SELECT TOP 1 DATEINVC, NewDate = (
SELECT TOP 1 dbo.fn_ConvertToDate(DATEINVC) as NewDate, DATEINVC FROM AROBL;

