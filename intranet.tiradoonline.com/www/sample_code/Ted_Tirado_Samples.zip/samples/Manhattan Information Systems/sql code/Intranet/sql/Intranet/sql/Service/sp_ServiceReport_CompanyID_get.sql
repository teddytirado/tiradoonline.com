IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_ServiceReport_CompanyID_get' AND TYPE = 'P')
	DROP PROCEDURE sp_ServiceReport_CompanyID_get;
GO


CREATE PROCEDURE sp_ServiceReport_CompanyID_get
	@CompanyID	INT,
	@StartDate	DATETIME,
	@EndDate	DATETIME,
	@SortBy		VARCHAR(30)

AS
	DECLARE @SQL_STRING VARCHAR(2000);
	SET @SQL_STRING = 'SELECT ServiceReportNumber, 
	RepairDate,
	ServiceDate 
	FROM 
	vw_ServiceReport_Search
	WHERE 
	CompanyID = ' + CONVERT(VARCHAR, @CompanyID) + ' AND 
	(RepairDate BETWEEN ''' + CONVERT(VARCHAR, @StartDate) + ''' AND ''' + 
	CONVERT(VARCHAR, @EndDate) + ''' OR
	ServiceDate BETWEEN ''' + CONVERT(VARCHAR, @StartDate) + ''' AND ''' + 
	CONVERT(VARCHAR, @EndDate) + ''')
	ORDER BY ' + @SortBy

	--PRINT @SQL_STRING
	EXEC(@SQL_STRING);

GO

sp_ServiceReport_CompanyID_get 135, '1/1/2005', '10/15/2010', 'ServiceDate DESC' 