IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Quote_Templates' AND TYPE = 'P')
	DROP PROCEDURE sp_Quote_Templates;
GO


CREATE PROCEDURE sp_Quote_Templates
AS
	
	SELECT
		SalesPerson = b.FirstName + ' ' + b.LastName,
		a.SalesID,
		a.QuoteTemplateName,
		a.create_dt
	FROM
		QuoteTemplates a,
		Userz b
	WHERE
		a.SalesID = b.SalesID COLLATE SQL_Latin1_General_CP1_CI_AS 
	
GO		

exec sp_Quote_Templates
