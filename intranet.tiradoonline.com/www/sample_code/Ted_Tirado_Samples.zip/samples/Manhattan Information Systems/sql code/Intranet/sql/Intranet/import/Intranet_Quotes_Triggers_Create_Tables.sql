	IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'Quote_insert')
		DROP TABLE IntranetLogs..Quote_insert;
	
	CREATE TABLE IntranetLogs.dbo.Quote_insert
	(
		QID int NOT NULL,
		SPNumber nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		PreparedByID nvarchar (10) collate SQL_Latin1_General_CP1_CI_AS NULL,
		Quote_Name varchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		RefNum nvarchar(50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		Attn nvarchar(50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		Phone nvarchar(50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		QuoteDate smalldatetime NULL,
		Terms nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WOCustomer nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		ShippingMeth nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WONote nvarchar (2000) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WODelivery nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WOTaxRate nvarchar(50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WOTax nvarchar(50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WOtaxable nvarchar(50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		Conv  nvarchar(50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		create_dt smalldatetime DEFAULT GETDATE() NULL
	);
	
	IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'Quote_update')
		DROP TABLE IntranetLogs..Quote_update;
	
	CREATE TABLE IntranetLogs.dbo.Quote_update
	(
		QID int NOT NULL,
		SPNumber nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		PreparedByID nvarchar (10) collate SQL_Latin1_General_CP1_CI_AS NULL,
		Quote_Name varchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		RefNum nvarchar(50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		Attn nvarchar(50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		Phone nvarchar(50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		QuoteDate smalldatetime NULL,
		Terms nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WOCustomer nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		ShippingMeth nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WONote nvarchar (2000) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WODelivery nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WOTaxRate nvarchar(50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WOTax nvarchar(50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WOtaxable nvarchar(50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		Conv  nvarchar(50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		create_dt smalldatetime DEFAULT GETDATE() NULL
	);
	
	IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'Quote_delete')
		DROP TABLE IntranetLogs..Quote_delete;
	
	CREATE TABLE IntranetLogs.dbo.Quote_delete
	(
		QID int NOT NULL,
		SPNumber nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		PreparedByID nvarchar (10) collate SQL_Latin1_General_CP1_CI_AS NULL,
		Quote_Name varchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		RefNum nvarchar(50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		Attn nvarchar(50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		Phone nvarchar(50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		QuoteDate smalldatetime NULL,
		Terms nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WOCustomer nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		ShippingMeth nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WONote nvarchar (2000) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WODelivery nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WOTaxRate nvarchar(50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WOTax nvarchar(50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WOtaxable nvarchar(50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		Conv  nvarchar(50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		create_dt smalldatetime DEFAULT GETDATE() NULL
	);
	
	IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'QuoteDetail_insert')
		DROP TABLE IntranetLogs..QuoteDetail_insert;
	
	CREATE TABLE IntranetLogs.dbo.QuoteDetail_insert
	(
		WOLineNum int NOT NULL,
		QID int NULL,
		LineNum int NULL,
		WOCost  nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WOItemNum nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WOQTY  nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WODesc varchar (1000) NULL,
		WOUPrice  nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		VendorID nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CTID nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WOVenNum nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		Conv  nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		create_dt smalldatetime DEFAULT GETDATE() NULL
	);
	
	IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'QuoteDetail_update')
		DROP TABLE IntranetLogs..QuoteDetail_update;
	
	CREATE TABLE IntranetLogs.dbo.QuoteDetail_update
	(
		WOLineNum int NOT NULL,
		QID int NULL,
		LineNum int NULL,
		WOCost  nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WOItemNum nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WOQTY  nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WODesc varchar (1000) NULL,
		WOUPrice  nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		VendorID nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CTID nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WOVenNum nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		Conv  nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		create_dt smalldatetime DEFAULT GETDATE() NULL
	);
	
	IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'QuoteDetail_delete')
		DROP TABLE IntranetLogs..QuoteDetail_delete;
	
	CREATE TABLE IntranetLogs.dbo.QuoteDetail_delete
	(
		WOLineNum int NOT NULL,
		QID int NULL,
		LineNum int NULL,
		WOCost  nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WOItemNum nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WOQTY  nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WODesc varchar (1000) NULL,
		WOUPrice  nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		VendorID nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CTID nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WOVenNum nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		Conv  nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		create_dt smalldatetime DEFAULT GETDATE() NULL
	);
	
	IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'QuoteNums_insert')
		DROP TABLE IntranetLogs..QuoteNums_insert;
	
	CREATE TABLE IntranetLogs.dbo.QuoteNums_insert
	(
		SPNumber nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		RefNum nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		create_dt smalldatetime DEFAULT GETDATE() NULL
	);
	
	
	IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'QuoteNums_update')
		DROP TABLE IntranetLogs..QuoteNums_update;
	
	CREATE TABLE IntranetLogs.dbo.QuoteNums_update
	(
		SPNumber nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		RefNum nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		create_dt smalldatetime DEFAULT GETDATE() NULL
	);
	
	
	IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'QuoteNums_delete')
		DROP TABLE IntranetLogs..QuoteNums_delete;
	
	CREATE TABLE IntranetLogs.dbo.QuoteNums_delete
	(
		SPNumber nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		RefNum nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		create_dt smalldatetime DEFAULT GETDATE() NULL
	);
	
	IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'QuoteTemplates_insert')
		DROP TABLE IntranetLogs..QuoteTemplates_insert;
	
	CREATE TABLE IntranetLogs.dbo.QuoteTemplates_insert
	(
		SalesID varchar (50) collate SQL_Latin1_General_CP1_CI_AS NOT NULL,
		QID int NOT NULL,
		QuoteTemplateName varchar (50) collate SQL_Latin1_General_CP1_CI_AS NOT NULL,
		create_dt smalldatetime DEFAULT GETDATE() NULL
	);
	
	
	IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'QuoteTemplates_update')
		DROP TABLE IntranetLogs..QuoteTemplates_update;
	
	CREATE TABLE IntranetLogs.dbo.QuoteTemplates_update
	(
		SalesID varchar (50) collate SQL_Latin1_General_CP1_CI_AS NOT NULL,
		QID int NOT NULL,
		QuoteTemplateName varchar (50) collate SQL_Latin1_General_CP1_CI_AS NOT NULL,
		create_dt smalldatetime DEFAULT GETDATE() NULL
	);
	
	IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'QuoteTemplates_delete')
		DROP TABLE IntranetLogs..QuoteTemplates_delete;
	
	CREATE TABLE IntranetLogs.dbo.QuoteTemplates_delete
	(
		SalesID varchar (50) collate SQL_Latin1_General_CP1_CI_AS NOT NULL,
		QID int NOT NULL,
		QuoteTemplateName varchar (50) collate SQL_Latin1_General_CP1_CI_AS NOT NULL,
		create_dt smalldatetime DEFAULT GETDATE() NULL
	);
	
	IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'CustShipQ_insert')
		DROP TABLE IntranetLogs..CustShipQ_insert;
	
	CREATE TABLE IntranetLogs.dbo.CustShipQ_insert
	(
		QID int NULL,
		CustomerNum nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NOT NULL,
		CustName nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustAdd1 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustAdd2 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustAdd3 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustAdd4 nvarchar (255) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustState nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustCity nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustZip nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBName nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBAdd1 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBAdd2 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBAdd3 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBAdd4 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBCity nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBState nchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBZip nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		create_dt smalldatetime DEFAULT GETDATE() NULL
	);
	
	
	IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'CustShipQ_update')
		DROP TABLE IntranetLogs..CustShipQ_update;
	
	CREATE TABLE IntranetLogs.dbo.CustShipQ_update
	(
		QID int NULL,
		CustomerNum nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NOT NULL,
		CustName nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustAdd1 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustAdd2 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustAdd3 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustAdd4 nvarchar (255) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustState nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustCity nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustZip nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBName nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBAdd1 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBAdd2 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBAdd3 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBAdd4 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBCity nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBState nchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBZip nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		create_dt smalldatetime DEFAULT GETDATE() NULL
	);
	
	
	IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'CustShipQ_delete')
		DROP TABLE IntranetLogs..CustShipQ_delete;
	
	CREATE TABLE IntranetLogs.dbo.CustShipQ_delete
	(
		QID int NULL,
		CustomerNum nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NOT NULL,
		CustName nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustAdd1 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustAdd2 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustAdd3 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustAdd4 nvarchar (255) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustState nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustCity nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustZip nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBName nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBAdd1 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBAdd2 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBAdd3 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBAdd4 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBCity nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBState nchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBZip nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		create_dt smalldatetime DEFAULT GETDATE() NULL
	);
	
	IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'PreCustShipQ_update')
		DROP TABLE IntranetLogs..PreCustShipQ_update;
	
	CREATE TABLE IntranetLogs.dbo.PreCustShipQ_update
	(
		PreQID int NOT NULL,
		CustomerNum nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustName nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustAdd1 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustAdd2 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustAdd3 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustAdd4 nvarchar (255) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustState nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustCity nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustZip nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBName nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBAdd1 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBAdd2 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBAdd3 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBAdd4 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBCity nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBState nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBZip nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		create_dt datetime DEFAULT GETDATE() NOT NULL 
	);
	
	IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'PreCustShipQ_insert')
		DROP TABLE IntranetLogs..PreCustShipQ_insert;
	
	CREATE TABLE IntranetLogs.dbo.PreCustShipQ_insert
	(
		PreQID int NOT NULL,
		CustomerNum nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustName nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustAdd1 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustAdd2 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustAdd3 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustAdd4 nvarchar (255) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustState nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustCity nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustZip nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBName nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBAdd1 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBAdd2 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBAdd3 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBAdd4 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBCity nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBState nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBZip nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		create_dt datetime DEFAULT GETDATE() NOT NULL 
	);
	
	
	
	IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'PreCustShipQ_delete')
		DROP TABLE IntranetLogs..PreCustShipQ_delete;
	
	CREATE TABLE IntranetLogs.dbo.PreCustShipQ_delete
	(
		PreQID int NOT NULL,
		CustomerNum nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustName nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustAdd1 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustAdd2 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustAdd3 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustAdd4 nvarchar (255) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustState nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustCity nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustZip nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBName nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBAdd1 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBAdd2 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBAdd3 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBAdd4 nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBCity nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBState nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CustBZip nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		create_dt datetime DEFAULT GETDATE() NOT NULL 
	);
	
	IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'PreQuote_insert')
		DROP TABLE IntranetLogs..PreQuote_insert;
	
	CREATE TABLE IntranetLogs.dbo.PreQuote_insert
	(
		PreQID int NOT NULL,
		SalesID nvarchar (255) collate SQL_Latin1_General_CP1_CI_AS NULL,
		PreparedByID nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		PreQuote_Name nvarchar (100) collate SQL_Latin1_General_CP1_CI_AS NULL,
		RefNum nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		Attn nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		Phone nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		PreQuoteDate smalldatetime NULL,
		Terms nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WOCustomer nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		ShippingMeth nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WONote nvarchar(2000) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WODelivery numeric(18, 2) NULL,
		WOTaxRate numeric(18, 3) NULL,
		WOTax numeric(18, 2) NOT NULL,
		WOtaxable bit NULL,
		Conv bit NULL,
		PreQuoteTemplate bit NULL,
		create_dt datetime DEFAULT GETDATE() NOT NULL 
	);
	
	
	IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'PreQuote_update')
		DROP TABLE IntranetLogs..PreQuote_update;
	
	CREATE TABLE IntranetLogs.dbo.PreQuote_update
	(
		PreQID int NOT NULL,
		SalesID nvarchar (255) collate SQL_Latin1_General_CP1_CI_AS NULL,
		PreparedByID nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		PreQuote_Name nvarchar (100) collate SQL_Latin1_General_CP1_CI_AS NULL,
		RefNum nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		Attn nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		Phone nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		PreQuoteDate smalldatetime NULL,
		Terms nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WOCustomer nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		ShippingMeth nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WONote nvarchar(2000) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WODelivery numeric(18, 2) NULL,
		WOTaxRate numeric(18, 3) NULL,
		WOTax numeric(18, 2) NOT NULL,
		WOtaxable bit NULL,
		Conv bit NULL,
		PreQuoteTemplate bit NULL,
		create_dt datetime DEFAULT GETDATE() NOT NULL 
	);
	
	
	IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'PreQuote_delete')
		DROP TABLE IntranetLogs..PreQuote_delete;
	
	CREATE TABLE IntranetLogs.dbo.PreQuote_delete
	(
		PreQID int NOT NULL,
		SalesID nvarchar (255) collate SQL_Latin1_General_CP1_CI_AS NULL,
		PreparedByID nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		PreQuote_Name nvarchar (100) collate SQL_Latin1_General_CP1_CI_AS NULL,
		RefNum nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		Attn nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		Phone nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		PreQuoteDate smalldatetime NULL,
		Terms nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WOCustomer nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		ShippingMeth nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WONote nvarchar(2000) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WODelivery numeric(18, 2) NULL,
		WOTaxRate numeric(18, 3) NULL,
		WOTax numeric(18, 2) NOT NULL,
		WOtaxable bit NULL,
		Conv bit NULL,
		PreQuoteTemplate bit NULL,
		create_dt datetime DEFAULT GETDATE() NOT NULL 
	);
	
	IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'PreQuoteDetail_insert')
		DROP TABLE IntranetLogs..PreQuoteDetail_insert;
	
	CREATE TABLE IntranetLogs.dbo.PreQuoteDetail_insert
	(
		PreQID int NOT NULL,
		LineNum int NULL,
		WOLineNum int NOT NULL,
		WOCost numeric(18, 2) NULL,
		WOItemNum nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WOQTY numeric(18, 2) NULL,
		WODesc nvarchar (1000) NULL,
		WOUPrice numeric(18, 2) NULL,
		VendorID nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CTID nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WOVenNum nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		Conv bit NULL,
		create_dt datetime DEFAULT GETDATE() NOT NULL 
	);
	
	IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'PreQuoteDetail_update')
		DROP TABLE IntranetLogs..PreQuoteDetail_update;
	
	CREATE TABLE IntranetLogs.dbo.PreQuoteDetail_update
	(
		PreQID int NOT NULL,
		LineNum int NULL,
		WOLineNum int NOT NULL,
		WOCost numeric(18, 2) NULL,
		WOItemNum nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WOQTY numeric(18, 2) NULL,
		WODesc nvarchar (1000) NULL,
		WOUPrice numeric(18, 2) NULL,
		VendorID nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CTID nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WOVenNum nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		Conv bit NULL,
		create_dt datetime DEFAULT GETDATE() NOT NULL 
	);
	
	
	IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'PreQuoteDetail_delete')
		DROP TABLE IntranetLogs..PreQuoteDetail_delete;
	
	CREATE TABLE IntranetLogs.dbo.PreQuoteDetail_delete
	(
		PreQID int NOT NULL,
		LineNum int NULL,
		WOLineNum int NOT NULL,
		WOCost numeric(18, 2) NULL,
		WOItemNum nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WOQTY numeric(18, 2) NULL,
		WODesc nvarchar (1000) NULL,
		WOUPrice numeric(18, 2) NULL,
		VendorID nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		CTID nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		WOVenNum nvarchar (50) collate SQL_Latin1_General_CP1_CI_AS NULL,
		Conv bit NULL,
		create_dt datetime DEFAULT GETDATE() NOT NULL 
	);
	
	IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'PreQuoteTemplates_insert')
		DROP TABLE IntranetLogs..PreQuoteTemplates_insert;
	
	CREATE TABLE IntranetLogs.dbo.PreQuoteTemplates_insert
	(
		SalesID varchar (50) NOT NULL,
		PreQID int NOT NULL,
		PreQuoteTemplateName varchar (50) collate SQL_Latin1_General_CP1_CI_AS NOT NULL ,
		create_dt datetime DEFAULT GETDATE() NOT NULL 
	);
	
	
	IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'PreQuoteTemplates_update')
		DROP TABLE IntranetLogs..PreQuoteTemplates_update;
	
	CREATE TABLE IntranetLogs.dbo.PreQuoteTemplates_update
	(
		SalesID varchar (50) NOT NULL,
		PreQID int NOT NULL,
		PreQuoteTemplateName varchar (50) collate SQL_Latin1_General_CP1_CI_AS NOT NULL ,
		create_dt datetime DEFAULT GETDATE() NOT NULL 
	);
	
	
	IF EXISTS (SELECT NAME FROM IntranetLogs..sysobjects WHERE NAME = 'PreQuoteTemplates_delete')
		DROP TABLE IntranetLogs..PreQuoteTemplates_delete;
	
	CREATE TABLE IntranetLogs.dbo.PreQuoteTemplates_delete
	(
		SalesID varchar (50) NOT NULL,
		PreQID int NOT NULL,
		PreQuoteTemplateName varchar (50) collate SQL_Latin1_General_CP1_CI_AS NOT NULL ,
		create_dt datetime DEFAULT GETDATE() NOT NULL 
	);
