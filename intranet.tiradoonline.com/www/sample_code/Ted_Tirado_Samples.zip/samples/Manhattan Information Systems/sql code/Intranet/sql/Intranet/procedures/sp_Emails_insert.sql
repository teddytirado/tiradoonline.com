IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Emails_insert' AND TYPE = 'P')
	DROP PROCEDURE sp_Emails_insert;
GO


CREATE PROCEDURE sp_Emails_insert
	@ToEmail		NVARCHAR(100),
	@FromEmail		NVARCHAR(100),
	@Subject		NVARCHAR(255),
	@BodyText		NTEXT,
	@isHTML			INT

AS

	INSERT INTO Emails
		(ToEmail, FromEmail, Subject, BodyText, isHTML)
	VALUES
		(@ToEmail, @FromEmail, @Subject, @BodyText, @isHTML);

GO


--EXEC sp_Emails_insert '2/11/08'