IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Userz_SalesID_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Userz_SalesID_get;
GO


CREATE PROCEDURE sp_Userz_SalesID_get
	@SalesID		nvarchar(255)
AS

	SELECT
		FullName = FirstName + ' ' + LastName,
		*
	FROM
		Userz
	WHERE
		SalesID = @SalesID;

GO

EXEC sp_Userz_SalesID_get '999'