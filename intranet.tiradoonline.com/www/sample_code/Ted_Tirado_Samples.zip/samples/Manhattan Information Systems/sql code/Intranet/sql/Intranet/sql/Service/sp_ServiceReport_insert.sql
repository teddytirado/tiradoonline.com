IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_ServiceReport_insert' AND TYPE = 'P')
	DROP PROCEDURE sp_ServiceReport_insert;
GO


CREATE PROCEDURE sp_ServiceReport_insert
	@ServiceReportNumber	VARCHAR(10),
	@ServiceReportNumberExt VARCHAR(5),
	@CompanyID		INT,
	@CompanyName		VARCHAR(30),
	@CompanyAddress		VARCHAR(50),
	@CompanyAddress2	VARCHAR(50),
	@CompanyCity		VARCHAR(50),
	@CompanyStateID		VARCHAR(2),
	@CompanyZipCode		VARCHAR(20),
	@SalesID		VARCHAR(10),
	@SalesTax		VARCHAR(10),
	@Remarks		NVARCHAR(2000),
	@Problems		NVARCHAR(2000),
	@Solutions		NVARCHAR(2000),
	@Notes			NVARCHAR(2000),
	@ServiceDate		VARCHAR(10),
	@ServiceTime		VARCHAR(10),
	@Contract		BIT,
	@T_M			BIT,
	@Warranty		BIT,
	@OtherDescription	VARCHAR(100),
	@PONumber		NVARCHAR(50),
	@WorkOrderNumber	NVARCHAR(50),
	@LaborHours		REAL,
	@LaborRate		MONEY,
	@TravelHours		REAL,
	@TravelRate		MONEY,
	@MiscCharges		MONEY,
	@Shipping		MONEY,
	@Contact		NVARCHAR(50),
	@Phone			NVARCHAR(20),
	@Ext			NVARCHAR(5),
	@create_by		VARCHAR(10)	

AS
	
	IF NOT EXISTS (SELECT 
				ServiceReportNumber 
			FROM 
				ServiceReport 
			WHERE 
				ServiceReportNumber = @ServiceReportNumber AND
				 ServiceReportNumberExt = @ServiceReportNumberExt)
		BEGIN
			BEGIN TRANSACTION TranServiceReport

			IF @CompanyName <> ''
				BEGIN
					IF NOT EXISTS (SELECT CompanyID FROM Companies WHERE CompanyName = @CompanyName AND Address1 = @CompanyAddress)
						BEGIN 
							INSERT INTO Companies 
								(CompanyName, 
								 Address1,
								 Address2,
								 City,
								 StateID,
								 ZipCode,
								 update_by,
								 update_dt,
								 create_by,
							         create_dt) 
							VALUES 
								(@CompanyName, 
								@CompanyAddress,
								@CompanyAddress2,
								@CompanyCity,
								@CompanyStateID,
								@CompanyZipCode,
								@create_by,
								GETDATE(),
								 @create_by,
							         GETDATE()); 

							SET @CompanyID = @@IDENTITY;
						END
				END

			INSERT INTO ServiceReport
				(ServiceReportNumber,
				ServiceReportNumberExt,
				CompanyID,
				SalesID,
				SalesTax,
				Remarks,
				Problems,
				Notes,
				Solutions,
				ServiceDate,
				ServiceTime,
				Contract,
				T_M,
				Warranty,
				OtherDescription,
				PONumber,
				WONumber,
				LaborHours,
				LaborRate,
				TravelHours,
				TravelRate,
				MiscCharges,
				Shipping,
				Contact,
				Phone,
				Ext,
				update_by,
				update_dt,
				create_by,
				create_dt)
			VALUES 
				(@ServiceReportNumber,
				@ServiceReportNumberExt,
				@CompanyID,
				@SalesID,
				@SalesTax,
				@Remarks,
				@Problems,
				@Solutions,
				@Notes,
				@ServiceDate,
				@ServiceTime,
				@Contract,
				@T_M,
				@Warranty,
				@OtherDescription,
				@PONumber,
				@WorkOrderNumber,
				@LaborHours,
				@LaborRate,
				@TravelHours,
				@TravelRate,
				@MiscCharges,
				@Shipping,
				@Contact,
				Service.dbo.fn_PhoneNumber(@Phone),
				@Ext,
				@create_by,
				GETDATE(),
				@create_by,
				GETDATE());

			IF @@ERROR <> 0
				ROLLBACK TRAN TranServiceReport;
			ELSE
				COMMIT TRAN TranServiceReport;

			SELECT @ServiceReportNumber;
		END
	ELSE
		SELECT ServiceReportNumber = 0;
GO

--EXEC sp_ServiceReport_insert '14141414', 140, '', '', '', '', 'NY', '', '999', '', 'remarks', 'problems', 'solutions', 'notes', '', '', 0, 0, 1, 'other', 'po', 'wo', 0, 0.00, 0, 0.00, 0.00, 0.00, 'Theodore Tirado', '347.414.1284', '3115', '999'