IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Timesheet_Userz_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Timesheet_Userz_get;
GO


CREATE PROCEDURE sp_Timesheet_Userz_get
	@Timesheet_dt	DATETIME
AS

	SELECT
		a.*,
		b.*,
		LastLoggedInStatus = (SELECT TOP 1 start_time FROM TimesheetEntry WHERE TimesheetID = a.TimesheetID ORDER BY TimesheetEntryID DESC),
		LastLoggedOutStatus = (SELECT TOP 1 end_time FROM TimesheetEntry WHERE TimesheetID = a.TimesheetID ORDER BY TimesheetEntryID DESC)
	FROM
		Timesheet a,
		Userz b
	WHERE
		a.SalesID = b.SalesID COLLATE SQL_Latin1_General_CP1_CI_AS AND
		a.Timesheet_dt = @Timesheet_dt AND
		b.Timesheet = 'yes'
	ORDER BY 
		b.LastName;

GO

exec sp_Timesheet_Userz_get '1/18/10'