
IF EXISTS (SELECT NAME FROM SYSOBJECTS WHERE NAME = 'sp_ShippingAddressBook_get' AND TYPE = 'P')

         DROP PROCEDURE sp_ShippingAddressBook_get;

GO

 

 

CREATE PROCEDURE sp_ShippingAddressBook_get
         @SalesID                          VARCHAR(10),
         @CustomerID                    VARCHAR(10),
         @ShippingAddressBookID              INT = NULL
AS

         IF @ShippingAddressBookID IS NULL
                  BEGIN
                            SELECT 
                                      *
                                      --CustomerName = (SELECT TEXTSNAM FROM MISINC..ARCUS WHERE IDCUST = ShippingAddressBook.CustomerID COLLATE SQL_Latin1_General_CP1_CI_AS)
                            FROM
                                      ShippingAddressBook
                            WHERE
                                      CustomerID = @CustomerID AND
                                      SalesID = @SalesID
                            ORDER BY
                                      CustomerName;
                  END
         ELSE
                  BEGIN
                            SELECT 
                                      *
                                      --CustomerName = (SELECT TEXTSNAM FROM MISINC..ARCUS WHERE IDCUST = ShippingAddressBook.CustomerID COLLATE SQL_Latin1_General_CP1_CI_AS)
                            FROM
                                      ShippingAddressBook
                            WHERE
                                      CustomerID = @CustomerID AND
                                      ShippingAddressBookID = @ShippingAddressBookID
                            ORDER BY
                                      CustomerName;
                  END
GO

 

EXEC sp_ShippingAddressBook_get '6', '06FIRE1000'

 