IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_PreQuoteDetail_PreQID_get' AND TYPE = 'P')
	DROP PROCEDURE sp_PreQuoteDetail_PreQID_get;
GO


CREATE PROCEDURE sp_PreQuoteDetail_PreQID_get
	@PreQID		INT
AS
	
	SELECT 
		a.*, 
		b.*,
		Total = (SELECT COUNT(*) FROM PreQuoteDetail WHERE PreQID = @PreQID) 
	FROM 
		PreQuote a,
		PreQuoteDetail b
	WHERE 
		a.PreQID = b.PreQID AND
		a.PreQID = @PreQID
	ORDER BY 
		b.LineNum;

GO

EXEC sp_PreQuoteDetail_PreQID_get 2576