IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_TimesheetEntry_insert' AND TYPE = 'P')
	DROP PROCEDURE sp_TimesheetEntry_insert;
GO


CREATE PROCEDURE sp_TimesheetEntry_insert
	@TimeSheetID		INT
	--@StartTime		DATETIME,
	--@EndTime		DATETIME
AS

	DECLARE @TimesheetEntryID	INT;
	
	IF NOT EXISTS (SELECT * FROM TimesheetEntry WHERE TimesheetID = @TimesheetID)
		BEGIN
			INSERT INTO TimesheetEntry 
				(TimesheetID, start_time, end_time)
			VALUES
				(@TimesheetID, GETDATE(), NULL)
		END
	ELSE
		BEGIN
			DECLARE @Start_Time	DATETIME;
			DECLARE @End_Time	DATETIME;

			SELECT TOP 1
				@TimesheetEntryID = TimesheetEntryID,				 
				@Start_Time = start_time,
				@End_Time = end_time
			FROM 
				TimesheetEntry
			WHERE
				TimesheetID = @TimesheetID
			ORDER BY 
				start_time DESC;

			IF @Start_Time IS NOT NULL AND @End_Time IS NOT NULL
				BEGIN
					INSERT INTO TimesheetEntry 
						(TimesheetID, start_time, end_time)
					VALUES
						(@TimesheetID, GETDATE(), NULL)
				END
			ELSE 
				BEGIN
					UPDATE TimesheetEntry SET
						end_time = GETDATE()
					WHERE
						TimesheetEntryID = @TimesheetEntryID;
				END
		END

GO

SELECT * FROM TimesheetEntry