IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Customer_Purchases_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Customer_Purchases_get;
GO


CREATE PROCEDURE sp_Customer_Purchases_get
	@CustomerID			VARCHAR(10),
	@CurrentYear			VARCHAR(10),
	@SalesID			VARCHAR(10),
	@Administrator			TINYINT
AS

	IF @Administrator = 1
		BEGIN	
			SELECT 
				a.InvoiceNumber,
				a.InvoiceDate, 
				a.PONumber,
				b.Quantity,
				b.ItemNumber,
				b.Description,
				b.Category,
				b.UnitPrice
			FROM 
				vw_InvoiceHeader a, 
				vw_InvoiceDetail b 
			WHERE 
				b.InvoiceNumber IN 
				(SELECT 
					InvoiceNumber 
				FROM 
					vw_InvoiceHeader 
				WHERE 
					InvoiceNumber = a.InvoiceNumber AND 
					CustomerID = @CustomerID AND 
					DATEPART(YYYY, InvoiceDate) = @CurrentYear) AND 
					UPPER(b.ItemNumber) <> 'FRT' AND
					UPPER(b.Description) <> 'FREIGHT'
				ORDER BY 
					InvoiceNumber;
		END
	ELSE
		BEGIN
			SET @CustomerID = ''
		END
GO

EXEC sp_Customer_Purchases_get '05SOCG0001', 2002, '999', 1