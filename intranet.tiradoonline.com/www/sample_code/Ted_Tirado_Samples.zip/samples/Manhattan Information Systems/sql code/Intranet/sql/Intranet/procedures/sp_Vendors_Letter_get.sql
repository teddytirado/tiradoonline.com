 IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Companies_Letter_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Companies_Letter_get;
GO


CREATE PROCEDURE sp_Companies_Letter_get
	@Letter		VARCHAR(3)

AS

	IF @Letter = 'ALL'
		BEGIN
			SELECT 
				VendorID,
				VendorName
			FROM 
				Vendor
			ORDER BY 
				VendorName
		END
	ELSE
		BEGIN
			SET @Letter = @Letter + '%';
			
			SELECT 
				VendorID,
				VendorName
			FROM 
				Vendor
			WHERE
				VendorName LIKE @Letter
			ORDER BY 
				VendorName;
		END	

GO

EXEC sp_Companies_Letter_get 'A'
