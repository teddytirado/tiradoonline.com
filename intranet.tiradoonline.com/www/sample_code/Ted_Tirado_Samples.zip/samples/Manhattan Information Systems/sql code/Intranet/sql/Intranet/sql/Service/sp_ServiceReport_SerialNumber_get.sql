IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_ServiceReport_SerialNumber_get' AND TYPE = 'P')
	DROP PROCEDURE sp_ServiceReport_SerialNumber_get;
GO


CREATE PROCEDURE sp_ServiceReport_SerialNumber_get
	@SerialNumber		NVARCHAR(50),
	@SortBy			VARCHAR(30)
AS

	DECLARE @SQL_STRING VARCHAR(1000);

	SET @SQL_STRING = 'SELECT 
		b.ServiceReportNumber,
		RepairDate = (SELECT TOP 1 b.RepairDate FROM ServiceReport WHERE b.ServiceReportNumber = a.ServiceReportNumber ORDER BY b.RepairDate DESC),
		Service_Date = b.ServiceDate
	FROM
		ServicedSerialNumbers a,
		ServiceReport b
	WHERE
		a.ServiceReportNumber = b.ServiceReportNumber AND
		a.SerialNumber = ''' + @SerialNumber + '''
	ORDER BY 
		' + @SortBy;

	--PRINT @SQL_STRING;
	EXEC(@SQL_STRING);


GO

EXEC sp_ServiceReport_SerialNumber_get 'HP 2200', 'Service_Date DESC'