IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Companies_update' AND TYPE = 'P')
	DROP PROCEDURE sp_Companies_update;
GO


CREATE PROCEDURE sp_Companies_update
	@CompanyID		INT,
	@CompanyName		NVARCHAR(50),
	@Address1		NVARCHAR(50),
	@Address2		NVARCHAR(50),
	@City			NVARCHAR(50),
	@StateID		NVARCHAR(3),
	@ZipCode		NVARCHAR(20),
	@update_by		VARCHAR(5)
AS
	

	UPDATE Companies SET
		CompanyName = @CompanyName,
		Address1 = @Address1,			
		Address2 = @Address2,
		City = @City,
		StateID = @StateID,
		ZipCode = @ZipCode,
		update_by = @update_by,
		update_dt = GETDATE()
	WHERE
		CompanyID = @CompanyID;
			

GO

