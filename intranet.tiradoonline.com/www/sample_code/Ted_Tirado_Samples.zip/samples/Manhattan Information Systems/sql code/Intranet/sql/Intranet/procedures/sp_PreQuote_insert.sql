IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_PreQuote_insert' AND TYPE = 'P')
	DROP PROCEDURE sp_PreQuote_insert;
GO


CREATE PROCEDURE sp_PreQuote_insert
	@SalesID		NVARCHAR(255),
	@PreparedByID		NVARCHAR(255),
	@PreQuote_Name		NVARCHAR(100),
	@RefNum			NVARCHAR(50),
	@Attn			NVARCHAR(50),
	@Phone			NVARCHAR(50),
	@Terms			NVARCHAR(50),
	@WOCustomer		NVARCHAR(50),
	@PreQuoteTemplate	BIT,
	@PreQuoteTemplateName	NVARCHAR(50)
AS

	DECLARE @WOTaxRate		DECIMAL(9,5);
	SET @WOTaxRate = (SELECT TOP 1 
		CONVERT(DECIMAL(9,5), c.ITEMRATE1) AS TaxRate
	FROM
		MISINC..ARCUS a,
		MISINC..TXGRP b,
		MISINC..TXRATE c
	WHERE
		a.IDCUST = @WOCustomer AND
		a.CODETAXGRP = b.GROUPID AND
		b.AUTHORITY1 = c.AUTHORITY
	);
	
	IF @WOTaxRate IS NULL
		SET @WOTaxRate = 0.00;
	--SET @WOTaxRate = 9.5;
	SET @WOTaxRate = CONVERT(DECIMAL(9,5), @WOTaxRate);
	print @WOTaxRate;

	INSERT INTO PreQuote 
		(SalesID, PreparedByID, PreQuote_Name, RefNum, Attn, Phone, PreQuoteDate, Terms, WOCustomer, WODelivery, WOTaxRate, WOTax, WOtaxable, Conv)
	VALUES
		(@SalesID, @PreparedByID, @PreQuote_Name, @RefNum, @Attn, @Phone, GETDATE(), @Terms, @WOCustomer, '0.00', @WOTaxRate, 0.00, '0', '0');

	DECLARE @PreQID		INT;
	SET @PreQID = @@IDENTITY;

	IF @PreQuoteTemplate = 1
		BEGIN
			INSERT INTO PreQuoteTemplates
				(SalesID, PreQID, PreQuoteTemplateName)
			VALUES
				(@SalesID, @PreQID, @PreQuoteTemplateName);
		END

	SELECT PreQID = @PreQID;
GO

--exec sp_PreQuote_insert '999', 'Test', 'Q99900058', 'Ted Tirado', '347.414.1284', 'N30', '05SOCG0001', 0, 'Test';
--select * from prequote
--delete from prequote

