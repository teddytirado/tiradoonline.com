IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_QuoteDetail_insert' AND TYPE = 'P')
	DROP PROCEDURE sp_QuoteDetail_insert;
GO


CREATE PROCEDURE sp_QuoteDetail_insert
	@QID		INT,
	@VendorID	NVARCHAR(50),
	@WOCost		NVARCHAR(50),
	@WOItemNum	NVARCHAR(50),
	@WODesc		VARCHAR(2000),
	@WOVenNum	NVARCHAR(50)
AS
	
	DECLARE @LineNum 	INT;

	SET @LineNum = (SELECT MAX(LineNum) FROM QuoteDetail WHERE QID = @QID)
	IF @LineNum IS NULL
		SET @LineNum = 1;
	ELSE
		SET @LineNum = @LineNum + 1;

	INSERT INTO QuoteDetail 
		(QID, LineNum, WOCost, WOItemNum, WOQTY, WODesc, WOUPrice, VendorID, CTID, WOVenNum, Conv)
	VALUES
		(@QID, @LineNum, @WOCost, @WOItemNum, '0', @WODesc, '0.00', @VendorID, 'NONE', @WOVenNum, '0');

	SELECT @@IDENTITY;

GO

--exec sp_QuoteDetail_insert