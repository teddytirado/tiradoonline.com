IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_TimesheetEntry_Personal' AND TYPE = 'P')
	DROP PROCEDURE sp_TimesheetEntry_Personal;
GO


CREATE PROCEDURE sp_TimesheetEntry_Personal
	@TimesheetID	INT,
	@Status		BIT
AS
	
	UPDATE Timesheet
		SET Personal = @Status
	WHERE
		TimesheetID = @TimesheetID;

GO

