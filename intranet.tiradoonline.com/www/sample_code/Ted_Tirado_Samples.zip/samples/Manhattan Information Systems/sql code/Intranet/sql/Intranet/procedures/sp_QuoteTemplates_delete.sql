IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_QuoteTemplates_delete' AND TYPE = 'P')
	DROP PROCEDURE sp_QuoteTemplates_delete;
GO


CREATE PROCEDURE sp_QuoteTemplates_delete
	@QuoteTemplateID		INT
AS

	DECLARE @TemplateName		VARCHAR(100);

	SET @TemplateName = (SELECT QuoteTemplateName FROM QuoteTemplates WHERE QuoteTemplateID = @QuoteTemplateID);

	DELETE FROM QuoteTemplates WHERE QuoteTemplateID = @QuoteTemplateID	

	SELECT TemplateName = @TemplateName;		
GO		

--exec sp_QuoteTemplates_delete
