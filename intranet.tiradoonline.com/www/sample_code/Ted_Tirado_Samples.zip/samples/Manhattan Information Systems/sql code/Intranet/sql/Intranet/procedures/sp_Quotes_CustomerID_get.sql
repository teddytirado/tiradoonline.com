IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Quotes_CustomerID_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Quotes_CustomerID_get;
GO


CREATE PROCEDURE sp_Quotes_CustomerID_get
	@CustomerID		VARCHAR(50),
	@SalesID		NVARCHAR(50),
	@UserType		TINYINT
AS
	
	IF @UserType > 0
		BEGIN
			SELECT 
				CustomerName = (SELECT NAMECUST FROM MISINC..ARCUS WHERE IDCUST = @CustomerID COLLATE SQL_Latin1_General_CP1_CI_AS),
				SalesPerson = (SELECT FirstName + ' ' + LastName FROM Userz WHERE SalesID = Quote.SPNumber COLLATE SQL_Latin1_General_CP1_CI_AS),
				QuoteTotal = (SELECT (SUM(WOUPrice * WOQTY) + WOTax) + WODelivery FROM QuoteDetail WHERE QID = Quote.QID),
				QuoteID = Quote.QID,
				*
			FROM 
				Quote 
			WHERE 
				WOCustomer = @CustomerID AND		
				Conv ='0' 
			ORDER BY 
				QID DESC
		END
	ELSE
		BEGIN
			SELECT 
				CustomerName = (SELECT NAMECUST FROM MISINC..ARCUS WHERE IDCUST = @CustomerID COLLATE SQL_Latin1_General_CP1_CI_AS),
				SalesPerson = (SELECT FirstName + ' ' + LastName FROM Userz WHERE SalesID = Quote.SPNumber COLLATE SQL_Latin1_General_CP1_CI_AS),
				QuoteTotal = (SELECT (SUM(WOUPrice * WOQTY) + WOTax) + WODelivery FROM QuoteDetail WHERE QID = Quote.QID),
				QuoteID = Quote.QID,
				* 
			FROM 
				Quote 
			WHERE 
				WOCustomer = @CustomerID AND		
				LEFT(WOCustomer, 2) = @SalesID AND 
				Conv = '0' 
			ORDER BY 
				QID DESC
		END

GO

EXEC sp_Quotes_CustomerID_get '01AOLT1000', '999', 1