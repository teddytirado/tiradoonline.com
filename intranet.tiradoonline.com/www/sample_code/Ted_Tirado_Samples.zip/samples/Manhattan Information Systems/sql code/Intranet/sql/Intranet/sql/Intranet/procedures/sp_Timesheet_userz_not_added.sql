IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Timesheet_userz_not_added' AND TYPE = 'P')
	DROP PROCEDURE sp_Timesheet_userz_not_added;
GO


CREATE PROCEDURE sp_Timesheet_userz_not_added
	@Timesheet_dt	DATETIME
AS

	SELECT
		SalesID,
		FullName = LastName + ', ' + FirstName
	FROM
		Userz
	WHERE
		SalesID NOT IN (SELECT SalesID COLLATE SQL_Latin1_General_CP1_CI_AS FROM Timesheet WHERE Timesheet_dt = @Timesheet_dt) AND
		Timesheet = 'yes'
	ORDER BY 
		LastName;

GO

exec sp_Timesheet_userz_not_added '1/18/10'