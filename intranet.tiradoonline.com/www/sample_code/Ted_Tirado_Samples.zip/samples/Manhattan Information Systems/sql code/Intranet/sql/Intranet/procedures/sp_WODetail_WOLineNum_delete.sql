IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_WODetail_WOLineNum_delete' AND TYPE = 'P')
	DROP PROCEDURE sp_WODetail_WOLineNum_delete;
GO


CREATE PROCEDURE sp_WODetail_WOLineNum_delete
	@WOLineNum		INT
AS
	
	DELETE FROM WODetail WHERE WOLineNum = @WOLineNum;
GO

