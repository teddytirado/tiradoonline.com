IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Quote_duplicate' AND TYPE = 'P')
	DROP PROCEDURE sp_Quote_duplicate;
GO


CREATE PROCEDURE sp_Quote_duplicate
	@SalesID		VARCHAR(50),
	@QuoteID		INT
AS

	BEGIN TRANSACTION TranQuote

	/*****************************
		GET QUOTE REFERENCE#
	******************************/
	CREATE TABLE #QuoteReference
	(
		QuoteReference		VARCHAR(50)
	);

	INSERT INTO #QuoteReference EXEC sp_QuoteReference_SalesID_get @SalesID;

	DECLARE @QuoteReference		VARCHAR(50)
	SET @QuoteReference = (SELECT * FROM #QuoteReference);

	/*****************************
		QUOTE 
	******************************/
	INSERT INTO PreQuote
		(SalesID, PreparedByID, PreQuote_Name, RefNum, Attn, Phone, PreQuoteDate, Terms, WOCustomer, ShippingMeth, WONote, WODelivery, WOTaxRate, WOTax, WOtaxable, Conv)
	SELECT
		SPNumber, PreparedByID, Quote_Name, @QuoteReference, Attn, Phone, GETDATE(), Terms, WOCustomer, ShippingMeth, WONote, WODelivery, WOTaxRate, WOTax, WOtaxable, 0
	FROM 
		Quote
	WHERE
		QID = @QuoteID;

	DECLARE @PreQuoteID	INT;
	SET @PreQuoteID = @@IDENTITY;
	
	/*****************************
		QUOTEDETAIL
	******************************/
	INSERT INTO PreQuoteDetail
		(PreQID, LineNum, WOCost, WOItemNum, WOQTY, WODesc, WOUPrice, VendorID, CTID, WOVenNum, Conv)
	SELECT
		@PreQuoteID, LineNum, WOCost, WOItemNum, WOQTY, WODesc, WOUPrice, VendorID, CTID, WOVenNum, 0
	FROM 
		QuoteDetail
	WHERE
		QID = @QuoteID;
	
	/*****************************
		CUSTSHIPQ
	******************************/
	INSERT INTO PreCustShipQ
		(PreQID, CustomerNum, CustName, CustAdd1, CustAdd2, CustAdd3, CustAdd4, CustState, CustCity, CustZip, CustBName, CustBAdd1, CustBAdd2, CustBAdd3, CustBAdd4, CustBCity, CustBState, CustBZip)
	SELECT
		@PreQuoteID, CustomerNum, CustName, CustAdd1, CustAdd2, CustAdd3, CustAdd4, CustState, CustCity, CustZip, CustBName, CustBAdd1, CustBAdd2, CustBAdd3, CustBAdd4, CustBCity, CustBState, CustBZip
	FROM 
		CustShipQ
	WHERE
		QID = @QuoteID;


	IF @@ERROR <> 0
		ROLLBACK TRAN TranQuote;
	ELSE
		COMMIT TRAN TranQuote;

	SELECT PreQID = @PreQuoteID;	
		
GO

exec sp_Quote_duplicate '6', 19000
