IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_PreQuote_update' AND TYPE = 'P')
	DROP PROCEDURE sp_PreQuote_update;
GO


CREATE PROCEDURE sp_PreQuote_update
	@PreQID			INT,
	@WOCustomer 		NVARCHAR(50),
	@Attention 		NVARCHAR(100),
	@ShippingMethod 	NVARCHAR(50),
	@ShippingComments	NTEXT,
	@WODelivery	 	NUMERIC(9, 2),
	@WOTaxRate		NUMERIC(9, 2),
	@WOTaxable		BIT
AS
	
	DECLARE @WOTax 		NUMERIC(9, 2);
	
	IF @WOTaxRate IS NOT NULL AND CONVERT(INT, @WOTaxRate) <> 0
		BEGIN
			SET @WOTax = (SELECT SUM(WOUPrice * WOQTY) * (@WOTaxRate / 100) FROM PreQuoteDetail WHERE PreQID = @PreQID);
			IF @WOTax IS NULL
				SET @WOTax = 0.00;
		END
	ELSE
		BEGIN
			SET @WOTax = 0.00;
		END
	

	UPDATE PreQuote SET 
		WOCustomer = @WOCustomer,
		ShippingMeth = @ShippingMethod,
		WONote = @ShippingComments,
		WODelivery = @WODelivery,
		WOTaxRate = @WOTaxRate,
		WOTax = @WOTax,
		WOtaxable = @WOTaxable
	WHERE 
		PreQID = @PreQID;
	
GO		

--sp_PreQuote_update 7, '01SPEC1000', 'TRUCK', '', 0.00, 0

