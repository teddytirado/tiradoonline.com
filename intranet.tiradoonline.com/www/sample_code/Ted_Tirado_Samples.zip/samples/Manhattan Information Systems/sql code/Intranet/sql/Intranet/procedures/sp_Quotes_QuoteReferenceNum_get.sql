IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Quotes_QuoteReferenceNum_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Quotes_QuoteReferenceNum_get;
GO


CREATE PROCEDURE sp_Quotes_QuoteReferenceNum_get
	@QuoteReferenceNum		NVARCHAR(50)
AS
	
	SELECT
		CustomerName = (SELECT NAMECUST FROM MISINC..ARCUS WHERE IDCUST = Quote.WOCustomer COLLATE SQL_Latin1_General_CP1_CI_AS),
		SalesPerson = (SELECT FirstName + ' ' + LastName FROM Userz WHERE SalesID = Quote.SPNumber COLLATE SQL_Latin1_General_CP1_CI_AS),
		QuoteTotal = (SELECT (SUM(WOUPrice * WOQTY) + WOTax) + WODelivery FROM QuoteDetail WHERE QID = Quote.QID),
		QuoteID = Quote.QID,
		*
	FROM 
		Quote
	WHERE 
		LTRIM(RTRIM(RefNum)) = @QuoteReferenceNum;

GO

EXEC sp_Quotes_QuoteReferenceNum_get 'TN9500'