IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_CreditMemo_CheckNumber_Exisits' AND TYPE = 'P')
	DROP PROCEDURE sp_CreditMemo_CheckNumber_Exisits;
GO


CREATE PROCEDURE sp_CreditMemo_CheckNumber_Exisits
	@CheckNumber		INT
AS

	IF NOT EXISTS (SELECT CheckNumber FROM CreditMemo WHERE CheckNumber = @CheckNumber)
		BEGIN
			SELECT CheckNumber = 1;
		END
	ELSE
		BEGIN
			SELECT CheckNumber = 0;
		END
GO

EXEC sp_CreditMemo_CheckNumber_Exisits 1001