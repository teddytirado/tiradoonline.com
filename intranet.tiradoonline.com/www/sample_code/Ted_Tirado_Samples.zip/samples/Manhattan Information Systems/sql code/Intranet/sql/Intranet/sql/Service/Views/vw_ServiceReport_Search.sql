IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'vw_ServiceReport_Search' AND TYPE = 'V')
	DROP VIEW vw_ServiceReport_Search;
GO


CREATE VIEW vw_ServiceReport_Search
AS

	SELECT 
		ServiceReportNumber,
		CompanyID,
		Customer = (SELECT CompanyName FROM Companies WHERE CompanyID = ServiceReport.CompanyID),
		RepairDate = (SELECT TOP 1 RepairDate FROM DateServicePerformed WHERE ServiceReportNumber = ServiceReport.ServiceReportNumber ORDER BY RepairDate DESC),
		ServiceDate,
		create_by,
		create_dt
	FROM
		ServiceReport
GO

SELECT TOP 100 * FROM vw_ServiceReport_Search ORDER BY create_dt DESC
