IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Userz_SalesID_Password_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Userz_SalesID_Password_get;
GO


CREATE PROCEDURE sp_Userz_SalesID_Password_get
	@SalesID		nvarchar(255),
	@Password		nvarchar(255)
AS

	SELECT
		*
	FROM
		Userz
	WHERE
		SalesID = @SalesID AND
		UPassword = @Password AND
		UserControl = 'yes';

GO