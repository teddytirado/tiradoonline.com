IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Timesheet_delete' AND TYPE = 'P')
	DROP PROCEDURE sp_Timesheet_delete;
GO


CREATE PROCEDURE sp_Timesheet_delete
	@TimesheetID	INT
AS
	
	DELETE FROM TimesheetEntry WHERE TimesheetID = @TimesheetID;
	DELETE FROM Timesheet WHERE TimesheetID = @TimesheetID;

GO

