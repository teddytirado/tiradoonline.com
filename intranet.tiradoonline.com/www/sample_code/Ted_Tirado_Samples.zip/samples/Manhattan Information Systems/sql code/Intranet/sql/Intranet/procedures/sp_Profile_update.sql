IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Profile_update' AND TYPE = 'P')
	DROP PROCEDURE sp_Profile_update;
GO


CREATE PROCEDURE sp_Profile_update
	@SalesID		NVARCHAR(255),
	@UPassword		NVARCHAR(255),
	@Email			NVARCHAR(255),
	@FaxNum			NVARCHAR(50),
	@CellPhone		NVARCHAR(50),
	@AIM			NVARCHAR(50),
	@Hotmail		NVARCHAR(50),
	@Yahoo			NVARCHAR(50)
AS

	UPDATE Userz SET
		UPassword = @UPassword, 
		Email = @Email,
		FAXNum = @FaxNum,
		CellPhone = @CellPhone,
		AIM = @AIM,
		Hotmail = @Hotmail,
		Yahoo = @Yahoo
		
	WHERE
		SalesID = @SalesID;
GO

--EXEC sp_Profile_update