IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Serviced_Serial_Numbers_ServiceReportNumber_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Serviced_Serial_Numbers_ServiceReportNumber_get;
GO


CREATE PROCEDURE sp_Serviced_Serial_Numbers_ServiceReportNumber_get
	@ServiceReportNumber	NVARCHAR(10)
AS

	SELECT 
		ServicedSerialNumberID,
		LineNumber,
		ModelNumber,
		SerialNumber
	FROM	
		ServicedSerialNumbers
	WHERE
		ServiceReportNumber = @ServiceReportNumber
	ORDER BY
		LineNumber
	

GO

