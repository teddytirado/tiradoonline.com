IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Quotes_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Quotes_get;
GO


CREATE PROCEDURE sp_Quotes_get
	@SalesID		NVARCHAR(50),
	@UserType		TINYINT,
	@StartRow		TINYINT,
	@EndRow			TINYINT

AS
	DECLARE @TOTALROWS 	INT;

	IF @UserType > 0
		BEGIN
			SELECT
				CustomerName = (SELECT NAMECUST FROM MISINC..ARCUS WHERE IDCUST = Quote.WOCustomer COLLATE SQL_Latin1_General_CP1_CI_AS),
				SalesID = @SalesID,
				SalesPerson = (SELECT FirstName + ' ' + LastName FROM Userz WHERE SalesID = Quote.SPNumber COLLATE SQL_Latin1_General_CP1_CI_AS),
				WOCustomer,
				QuoteDate,
				QuoteID = Quote.QID,
				RefNum,
				QuoteTotal = (SELECT (SUM(WOUPrice * WOQTY) + WOTax) + WODelivery FROM QuoteDetail WHERE QID = Quote.QID COLLATE SQL_Latin1_General_CP1_CI_AS)
			INTO
				#Quotes
			FROM 
				Quote 
			WHERE 
				Conv ='0'
			ORDER BY 
				QID DESC

			PRINT '1'
			SET @TOTALROWS = (SELECT COUNT(*) FROM #Quotes);
			DECLARE quoteCursor CURSOR FOR SELECT * FROM #Quotes;
		END
	ELSE
		BEGIN
			SELECT
				CustomerName = (SELECT NAMECUST FROM MISINC..ARCUS WHERE IDCUST = Quote.WOCustomer COLLATE SQL_Latin1_General_CP1_CI_AS),
				SalesID = @SalesID,
				SalesPerson = (SELECT FirstName + ' ' + LastName FROM Userz WHERE SalesID = Quote.SPNumber COLLATE SQL_Latin1_General_CP1_CI_AS),
				WOCustomer,
				QuoteDate,
				QuoteID = Quote.QID,
				RefNum,
				QuoteTotal = (SELECT (SUM(WOUPrice * WOQTY) + WOTax) + WODelivery FROM QuoteDetail WHERE QID = Quote.QI COLLATE SQL_Latin1_General_CP1_CI_ASD)
			INTO
				#Quotes2
			FROM 
				Quote 
			WHERE 
				(SPNumber = @SalesID  COLLATE SQL_Latin1_General_CP1_CI_AS OR
				SPNumber IN (SELECT SalesID COLLATE SQL_Latin1_General_CP1_CI_AS FROM SalesAssistants WHERE AssistantSalesID = @SalesID)) AND
				Conv = '0'
			ORDER BY 
				QID DESC
			
			PRINT '2'
			SET @TOTALROWS = (SELECT COUNT(*) FROM #Quotes2);
			DECLARE quoteCursor CURSOR FOR SELECT * FROM #Quotes2;
		END

	PRINT @TOTALROWS;
	
	OPEN quoteCursor
	
	DECLARE @CustomerName 		VARCHAR(100);
	DECLARE @SalesPerson		VARCHAR(50);
	DECLARE @WOCustomer		VARCHAR(50);
	DECLARE @QuoteDate		VARCHAR(50);
	DECLARE @QuoteID		INT;
	DECLARE @RefNum			VARCHAR(50);
	DECLARE @QuoteTotal		NUMERIC(9, 2);

	FETCH NEXT FROM quoteCursor INTO @CustomerName, @SalesID, @SalesPerson, @WOCustomer, @QuoteDate, @QuoteID, @RefNum, @QuoteTotal

	CREATE TABLE #QuoteTable
	(	
		CustomerName 		VARCHAR(100),
		SalesID			INT,
		SalesPerson		VARCHAR(50),
		WOCustomer		VARCHAR(50),
		QuoteDate		VARCHAR(50),
		QuoteID			INT,
		RefNum			VARCHAR(50),
		QuoteTotal		NUMERIC(9, 2)
	)

	DECLARE @COUNTER	INT;
	SET @COUNTER = 1;
	WHILE @@FETCH_STATUS = 0
		BEGIN
			IF @COUNTER >= @StartRow AND @COUNTER < @EndRow
				BEGIN
					INSERT INTO #QuoteTable
						(CustomerName, SalesID, SalesPerson, WOCustomer, QuoteDate, QuoteID, RefNum, QuoteTotal)
					VALUES
						(@CustomerName, @SalesID, @SalesPerson, @WOCustomer, @QuoteDate, @QuoteID, @RefNum, @QuoteTotal);
				END
			SET @COUNTER = @COUNTER + 1;
			FETCH NEXT FROM quoteCursor INTO @CustomerName, @SalesID, @SalesPerson, @WOCustomer, @QuoteDate, @QuoteID, @RefNum, @QuoteTotal

		END

	CLOSE quoteCursor	
	DEALLOCATE quoteCursor	

	UPDATE #QuoteTable SET QuoteTotal = 0 WHERE QuoteTotal IS NULL;

	SELECT 
		*, 
		TotalRows = @TOTALROWS
	FROM 
		#QuoteTable;
GO

exec sp_Quotes_get '999', 1, 1, 31 