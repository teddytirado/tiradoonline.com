IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_QuoteDetail_delete' AND TYPE = 'P')
	DROP PROCEDURE sp_QuoteDetail_delete;
GO


CREATE PROCEDURE sp_QuoteDetail_delete
	@QID		INT
AS
	DELETE FROM QuoteDetail WHERE QID = @QID;

GO

--exec sp_QuoteDetail_delete