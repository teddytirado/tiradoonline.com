IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_WODetail_WorkOrderID_get' AND TYPE = 'P')
	DROP PROCEDURE sp_WODetail_WorkOrderID_get;
GO


CREATE PROCEDURE sp_WODetail_WorkOrderID_get
	@WorkOrderID		INT
AS
	
	SELECT 
		*,
		
		ShipVia = 
			CASE 
				WHEN CTID = 'NONE' THEN 'NONE'
				ELSE (SELECT CarrierAbb + '&nbsp;-&nbsp;' + DSType FROM Carrier WHERE DSID = WODetail.CTID)
			END,
		Vendor = (SELECT VendorNameAbb FROM Vendor WHERE VendorID = WODetail.VendorID),
		POID = (SELECT POIDs FROM WOPO where POID = WODetail.ItemPO)
	FROM 
		WODetail 
	WHERE 
		WONumber = @WorkOrderID;

GO

EXEC sp_WODetail_WorkOrderID_get 21485
EXEC sp_WODetail_WorkOrderID_get 21785 
