IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_TimesheetSetting_get' AND TYPE = 'P')
	DROP PROCEDURE sp_TimesheetSetting_get;
GO


CREATE PROCEDURE sp_TimesheetSetting_get
AS

	SELECT 
		FullName = b.LastName + ', ' + b.FirstName,
		a.*
	FROM 
		TimesheetSetting a, 
		Userz b 
	WHERE 
		a.SalesID = b.SalesID COLLATE SQL_Latin1_General_CP1_CS_AS 
	ORDER BY 
		b.LastName;

GO

EXEC sp_TimesheetSetting_geT