IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_TradeReference_update' AND TYPE = 'P')
	DROP PROCEDURE sp_TradeReference_update;
GO


CREATE PROCEDURE sp_TradeReference_update
	@TradeReferenceID	INT,
	@CompanyName		VARCHAR(50),
	@Address1 		VARCHAR(50),
	@Address2 		VARCHAR(50),
	@City 			VARCHAR(50),
	@StateID 		VARCHAR(2),
	@ZipCode 		VARCHAR(20),
	@Contact 		VARCHAR(50),
	@Phone 			VARCHAR(30),
	@Fax 			VARCHAR(20)
AS
		
	UPDATE TradeReference SET
		CompanyName = @CompanyName,
		Address1 = @Address1,
		Address2 = @Address2,
		City = @City,
		StateID = @StateID,
		ZipCode = @ZipCode,
		Contact = @Contact,
		Phone = @Phone,
		Fax = @Fax
	WHERE 
		TradeReferenceID = @TradeReferenceID;

GO

--EXEC sp_TradeReference_update 