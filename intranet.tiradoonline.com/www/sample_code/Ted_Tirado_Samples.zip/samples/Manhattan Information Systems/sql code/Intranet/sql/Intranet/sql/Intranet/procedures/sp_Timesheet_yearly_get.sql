IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Timesheet_yearly_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Timesheet_yearly_get;
GO


CREATE PROCEDURE sp_Timesheet_yearly_get
	@TimesheetYear		INT
AS

	
	SELECT 
		b.SalesID,
		FullName = b.LastName + ', ' + b.FirstName,
		TotalDaysWorked = (SELECT COUNT(*) FROM Timesheet WHERE TimesheetID IN (SELECT TimesheetID FROM Timesheet WHERE SalesID = b.SalesID COLLATE SQL_Latin1_General_CP1_CS_AS AND DATEPART(YEAR, Timesheet_dt) = @TimesheetYear)),
		TotalPersonal = (SELECT COUNT(*) FROM Timesheet WHERE SalesID = b.SalesID COLLATE SQL_Latin1_General_CP1_CS_AS AND Personal = 1 AND DATEPART(YEAR, Timesheet_dt) = @TimesheetYear),
		a.Personal,
		TotalVacation = (SELECT COUNT(*) FROM Timesheet WHERE SalesID = b.SalesID COLLATE SQL_Latin1_General_CP1_CS_AS AND Vacation = 1 AND DATEPART(YEAR, Timesheet_dt) = @TimesheetYear),
		a.Vacation,
		TotalSick = (SELECT COUNT(*) FROM Timesheet WHERE SalesID = b.SalesID COLLATE SQL_Latin1_General_CP1_CS_AS AND Sick = 1 AND DATEPART(YEAR, Timesheet_dt) = @TimesheetYear),
		a.Sick,
		TotalWorkFromHome = (SELECT COUNT(*) FROM Timesheet WHERE SalesID = b.SalesID COLLATE SQL_Latin1_General_CP1_CS_AS AND Sick = 1 AND DATEPART(YEAR, Timesheet_dt) = @TimesheetYear),
		a.WorkFromHome
		
	FROM 
		TimesheetSetting a,
		Userz b
	WHERE 
		a.SalesID = b.SalesID COLLATE SQL_Latin1_General_CP1_CS_AS
	ORDER BY 
		b.LastName;


GO

EXEC sp_Timesheet_yearly_get '2011'