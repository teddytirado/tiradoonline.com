--UPDATE CreditMemoImport SET CreditMemoDate = getdate() where CreditMemoDate IS NULL
TRUNCATE TABLE CreditMemo

update CreditMemoImport set VendorID = (SELECT VendorID FROM Vendors WHERE UPPER(VendorName) = UPPER(CreditMemoImport.Vendor))
update CreditMemoImport set LaborReimbursement = 0 WHERE LaborReimbursementNo = 'X';
update CreditMemoImport set LaborReimbursement = 1 WHERE LaborReimbursementYes = 'X';


INSERT INTO CreditMemo 
	(CreditMemoNumber, ServiceReportNumber, ReferenceNumber, CreditMemoDate, VendorID, LaborReimbursement, PartNumber, PartDescription, PaidDate, PaidAmount)
SELECT
	CreditMemoNumber, ServiceReportNumber, ReferenceNumber, CreditMemoDate, VendorID, LaborReimbursement, PartNumber, PartDescription, PaidDate, PaidAmount
FROM
	CreditMemoImport


update CreditMemo set 
	Status = 1,
	update_by = 7,
	create_by = 7

update CreditMemo Set LaborReimbursement = 0 where LaborReimbursement is null

update CreditMemo set Status = 1 

update CreditMemo set Status = 0 WHERE UPPER(PartDescription) = 'CLOSED'
update CreditMemo set Status = 0 WHERE UPPER(PartDescription) = 'V O I D'

select * from CreditMemo

