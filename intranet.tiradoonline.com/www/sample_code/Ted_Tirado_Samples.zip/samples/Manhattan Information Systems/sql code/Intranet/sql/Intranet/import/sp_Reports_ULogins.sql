CREATE PROCEDURE sp_Reports_ULogins
as
select a.salesid, SalesPerson = (select firstname + ' ' + lastname from userz where salesid = a.salesid), count(*) as logins from userz a, ulogins b where a.SalesID = b.salesid group by a.salesid, a.firstname order by count(*) desc

go

exec sp_Reports_ULogins;