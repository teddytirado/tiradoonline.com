update ServiceReport SET
--	CompanyID = (SELECT TOP 1 b.CompanyID FROM Companies b WHERE UPPER(SOUNDEX(b.CompanyName)) = UPPER(SOUNDEX(ServiceReport.Company)))
	CompanyID = (SELECT TOP 1 b.CompanyID FROM Companies b WHERE UPPER(b.CompanyName) = UPPER(ServiceReport.Company))
	
select count(*) from ServiceReport;
select count(*) from ServiceReport WHERE CompanyID is not null;
select count(*) from ServiceReport WHERE CompanyID is null;
select distinct CompanyID, count(*) from ServiceReport group by CompanyID order by count(*) DESC