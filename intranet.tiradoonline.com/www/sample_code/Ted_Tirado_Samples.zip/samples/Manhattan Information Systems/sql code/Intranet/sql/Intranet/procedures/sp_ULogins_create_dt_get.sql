IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_ULogins_create_dt_get' AND TYPE = 'P')
	DROP PROCEDURE sp_ULogins_create_dt_get;
GO


CREATE PROCEDURE sp_ULogins_create_dt_get
	@create_dt	DATETIME = GETDATE
AS

	SELECT
		TOP 100
		a.create_dt,
		SalesPerson = b.FirstName + ' ' + b.LastName
	FROM
		ULogins a,
		Userz b
	WHERE
		a.SalesID = b.SalesID AND
		DATEPART(month, a.create_dt) = DATEPART(month, @create_dt) AND 
		DATEPART(day, a.create_dt) = DATEPART(day, @create_dt) AND 
		DATEPART(year, a.create_dt) = DATEPART(year, @create_dt)
	ORDER BY 
		a.create_dt DESC;

GO

EXEC sp_ULogins_create_dt_get '2/4/08'