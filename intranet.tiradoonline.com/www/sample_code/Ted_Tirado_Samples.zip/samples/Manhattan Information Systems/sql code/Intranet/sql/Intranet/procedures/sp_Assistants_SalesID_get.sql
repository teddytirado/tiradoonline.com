IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Assistants_SalesID_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Assistants_SalesID_get;
GO


CREATE PROCEDURE sp_Assistants_SalesID_get
	@SalesID		NVARCHAR(50)

AS
	SELECT
		a.SalesID,
		SalesPerson = (CASE
			      	WHEN b.FirstName = '' THEN b.LastName
			      	WHEN b.LastName = '' THEN b.FirstName
			      	ELSE b.FirstName + ' ' + b.LastName
	END)
	FROM		      
		SalesAssistants a,
		Userz b
	WHERE
		a.SalesID = b.SalesID AND
		a.AssistantSalesID = @SalesID
				
GO

exec sp_Assistants_SalesID_get '111'