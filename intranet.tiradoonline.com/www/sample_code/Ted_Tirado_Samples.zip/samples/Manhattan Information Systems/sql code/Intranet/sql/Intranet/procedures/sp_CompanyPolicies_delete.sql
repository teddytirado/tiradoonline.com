IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_CompanyPolicies_delete' AND TYPE = 'P')
	DROP PROCEDURE sp_CompanyPolicies_delete;
GO


CREATE PROCEDURE sp_CompanyPolicies_delete
	@CompanyPolicyID		INT
AS

	DELETE FROM CompanyPolicies WHERE CompanyPolicyID = @CompanyPolicyID;

GO

--EXEC sp_CompanyPolicies_delete 1010

