IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Quote_update' AND TYPE = 'P')
	DROP PROCEDURE sp_Quote_update;
GO


CREATE PROCEDURE sp_Quote_update
	@QID			INT,
	@SPNumber		NVARCHAR(10),
	@ShippingMethod 	NVARCHAR(50),
	@ShippingComments	NTEXT,
	@WODelivery	 	NUMERIC(9, 2),
	@WOTaxRate		NUMERIC(9, 2),
	@WOTaxable		NVARCHAR(50)
AS
	
	DECLARE @WOTax 		NUMERIC(9, 2);
	
	IF @WOTaxRate IS NOT NULL AND CONVERT(INT, @WOTaxRate) <> 0
		BEGIN
			SET @WOTax = (SELECT SUM(WOUPrice * WOQTY) * (@WOTaxRate / 100) FROM QuoteDetail WHERE QID = @QID);
			IF @WOTax IS NULL
				SET @WOTax = 0.00;
		END
	ELSE
		BEGIN
			SET @WOTax = 0.00;
		END
	

	UPDATE Quote SET 
		SPNumber = @SPNumber,
		ShippingMeth = @ShippingMethod,
		WONote = @ShippingComments,
		WODelivery = @WODelivery,
		WOTaxRate = @WOTaxRate,
		WOTax = @WOTax,
		WOtaxable = @WOTaxable
	WHERE 
		QID = @QID;
	
GO		

--sp_Quote_update 7, '01SPEC1000', 'TRUCK', '', 0.00, 0