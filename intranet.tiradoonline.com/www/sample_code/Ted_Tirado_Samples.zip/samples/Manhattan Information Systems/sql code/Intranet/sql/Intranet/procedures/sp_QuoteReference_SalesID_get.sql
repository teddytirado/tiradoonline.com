IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_QuoteReference_SalesID_get' AND TYPE = 'P')
	DROP PROCEDURE sp_QuoteReference_SalesID_get;
GO


CREATE PROCEDURE sp_QuoteReference_SalesID_get
	@SalesID		NVARCHAR(255)
AS

	DECLARE @QuoteReferenceNumber		NVARCHAR(255);

	SELECT @QuoteReferenceNumber = RefNum FROM QuoteNums WHERE SPNumber = @SalesID

	IF @QuoteReferenceNumber IS NULL	
		BEGIN
			SET @QuoteReferenceNumber = '00001';

			INSERT INTO QuoteNums
				(SPNumber, RefNum)
			VALUES
				(@SalesID, @QuoteReferenceNumber);
		END		
	ELSE
		BEGIN
			IF EXISTS (SELECT RefNum FROM Quote WHERE RefNum = @QuoteReferenceNumber)
				BEGIN
					PRINT '1';
					PRINT @QuoteReferenceNumber;
					SET @QuoteReferenceNumber = REPLACE(@QuoteReferenceNumber, @SalesID, '');
					PRINT @QuoteReferenceNumber;
					SET @QuoteReferenceNumber = CONVERT(NVARCHAR, (CONVERT(INT, @QuoteReferenceNumber) + 1));
					UPDATE QuoteNums SET 
						RefNum = @QuoteReferenceNumber 
					WHERE 
						SPNumber = @SalesID;
					SELECT QuoteReferenceNumber = 'Q' + @SalesID + REPLICATE ('0', 5 - LEN(@QuoteReferenceNumber)) + @QuoteReferenceNumber;
				END
			ELSE
				BEGIN
					IF LEN(@QuoteReferenceNumber) > 5
						BEGIN
					PRINT '2';
							SELECT QuoteReferenceNumber = 'Q' + CONVERT(VARCHAR, (CONVERT(INT, @QuoteReferenceNumber) + 1));
						END
					ELSE
						BEGIN
					PRINT '3';
							SELECT QuoteReferenceNumber = 'Q' + REPLICATE ('0', 5 - LEN(CONVERT(VARCHAR, @QuoteReferenceNumber))) + @QuoteReferenceNumber;
						END
				END
		END


GO

-- select 
-- 	spnumber,
-- 	salesperson = (select firstname + ' ' + lastname from userz where salesid = quotenums.spnumber),
-- 	refnum,
-- 	totalquotes = (select count(*) from quote where spnumber = quotenums.spnumber)
-- from quotenums 
-- order by convert(int, spnumber)

EXEC sp_QuoteReference_SalesID_get '105'
