IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'fn_PhoneNumber' AND TYPE = 'FN')
	DROP FUNCTION fn_PhoneNumber;
GO


CREATE FUNCTION fn_PhoneNumber
	(@PhoneNumber	VARCHAR(20))
RETURNS VARCHAR(20)

AS
	BEGIN
		
		SET @PhoneNumber = REPLACE(@PhoneNumber, '(', '');
		SET @PhoneNumber = REPLACE(@PhoneNumber, ')', '');
		SET @PhoneNumber = REPLACE(@PhoneNumber, '-', '');
		SET @PhoneNumber = REPLACE(@PhoneNumber, ' ', '');
		SET @PhoneNumber = REPLACE(@PhoneNumber, '.', '');

		SET @PhoneNumber = '(' + SUBSTRING(@PhoneNumber, 1, 3) + ') ' + 
			     SUBSTRING(@PhoneNumber, 4, 3) + '-' + 
			     SUBSTRING(@PhoneNumber, 7, 4);

		RETURN(@PhoneNumber);
		
	END

GO

SELECT Service.dbo.fn_PhoneNumber('(347374979-SS')