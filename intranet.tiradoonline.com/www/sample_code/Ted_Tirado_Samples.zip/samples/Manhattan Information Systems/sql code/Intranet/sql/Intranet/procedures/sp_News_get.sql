IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_News_get' AND TYPE = 'P')
	DROP PROCEDURE sp_News_get;
GO


CREATE PROCEDURE sp_News_get
AS

	SELECT
		NewsID,
		NewsDate,
		Title,
		Body
	FROM
		News
	ORDER BY
		NewsDate DESC;

GO

EXEC sp_News_get