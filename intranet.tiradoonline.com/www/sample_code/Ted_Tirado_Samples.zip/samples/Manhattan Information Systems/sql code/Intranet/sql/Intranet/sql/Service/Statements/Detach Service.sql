EXEC clearDBUsers 13
GO
EXEC sp_detach_db 'Service'
GO