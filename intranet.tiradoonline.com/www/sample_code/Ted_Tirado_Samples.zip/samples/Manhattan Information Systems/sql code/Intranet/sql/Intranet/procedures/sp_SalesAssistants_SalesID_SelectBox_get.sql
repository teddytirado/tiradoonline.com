IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_SalesAssistants_SalesID_SelectBox_get' AND TYPE = 'P')
	DROP PROCEDURE sp_SalesAssistants_SalesID_SelectBox_get;
GO


CREATE PROCEDURE sp_SalesAssistants_SalesID_SelectBox_get
	@SalesID			NVARCHAR(255)
AS

	SELECT 
		SalesID,
		FullName = (CASE
			      	WHEN FirstName = '' THEN LastName
			      	WHEN LastName = '' THEN FirstName
			      	ELSE LastName + ', ' + FirstName
	END)
	FROM 
		Userz 
	WHERE 
		SalesID NOT IN (SELECT AssistantSalesID FROM SalesAssistants WHERE SalesID = @SalesID) AND 
		SalesID <> @SalesID AND
		MakeSale = 'yes' AND
		UserControl = 'yes'
	ORDER BY 
		LastName;
GO

EXEC sp_SalesAssistants_SalesID_SelectBox_get 1