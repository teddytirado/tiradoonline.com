IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_TradeReference_get' AND TYPE = 'P')
	DROP PROCEDURE sp_TradeReference_get;
GO


CREATE PROCEDURE sp_TradeReference_get
	@TradeReferenceID	INT
AS
		
	SELECT
		*
	FROM
		TradeReference
	WHERE
		TradeReferenceID = @TradeReferenceID;

GO

EXEC sp_TradeReference_get 1001