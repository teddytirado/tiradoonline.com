IF EXISTS (SELECT NAME FROM SYSOBJECTS WHERE NAME = 'sp_ShippingAddressBook_search' AND TYPE = 'P')
	DROP PROCEDURE sp_ShippingAddressBook_search;
GO


CREATE PROCEDURE sp_ShippingAddressBook_search
	@CustomerID		VARCHAR(20),
	@SearchString		VARCHAR(50)
AS

	SET @SearchString = '%' + @SearchString + '%';	

	SELECT 
		*
	FROM
		ShippingAddressBook
	WHERE
		CustomerID = @CustomerID AND
		(
			
			CustomerName LIKE @SearchString OR
			Address1 LIKE @SearchString OR
			Address2 LIKE @SearchString OR
			Address3 LIKE @SearchString OR
			Address4 LIKE @SearchString OR
			City LIKE @SearchString OR
			StateID LIKE @SearchString OR
			ZipCode LIKE @SearchString
		)
	ORDER BY
		CustomerName;

GO

EXEC sp_ShippingAddressBook_search '06FIRE1000', '96001' 
