IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Triggers_Tables_drop' AND TYPE = 'P')
	DROP PROCEDURE sp_Triggers_Tables_drop;
GO


CREATE PROCEDURE sp_Triggers_Tables_drop
AS
	DECLARE @DatabaseName	VARCHAR(30);
	DECLARE @TableName	VARCHAR(30);
	DECLARE @SQL		NVARCHAR(3000);
	DECLARE @TriggerMethod	NVARCHAR(100);

	SET @DatabaseName = 'IntranetLogs';

	DECLARE triggerCursor CURSOR FOR SELECT NAME FROM IntranetLogs.dbo.sysobjects WHERE XTYPE = 'U' AND LEFT(NAME, 2) <> 'dt' ORDER BY NAME;
	OPEN triggerCursor
	FETCH NEXT FROM triggerCursor INTO @TableName;



	WHILE @@FETCH_STATUS = 0
		BEGIN
			--PRINT @TableName;
		
			/********* INSERT *****************/
			SET @TriggerMethod = 'insert';
			SET @SQL = 'IF EXISTS (SELECT NAME FROM ' + @DatabaseName + '.dbo.sysobjects WHERE NAME = ''' + @TableName + ''' AND XTYPE = ''U'')' + CHAR(10);
			SET @SQL = @SQL + CHAR(9) + 'DROP TABLE ' + @DatabaseName + '.dbo.' + @TableName + ';' + CHAR(10);
			
			PRINT @SQL;
			EXEC sp_executesql @SQL;
			--PRINT 'EXECUTED';

			/********* UPDATE *****************/
			SET @TriggerMethod = 'update';
			SET @SQL = 'IF EXISTS (SELECT NAME FROM ' + @DatabaseName + '.dbo.sysobjects WHERE NAME = ''' + @TableName + ''' AND XTYPE = ''U'')' + CHAR(10);
			SET @SQL = @SQL + CHAR(9) + 'DROP TABLE ' + @DatabaseName + '.dbo.' + @TableName + ';' + CHAR(10);
			PRINT @SQL;
			EXEC sp_executesql @SQL;
			--PRINT 'EXECUTED';

			/********* DELETE *****************/
			SET @TriggerMethod = 'delete';
			SET @SQL = 'IF EXISTS (SELECT NAME FROM ' + @DatabaseName + '.dbo.sysobjects WHERE NAME = ''' + @TableName + ''' AND XTYPE = ''U'')' + CHAR(10);
			SET @SQL = @SQL + CHAR(9) + 'DROP TABLE ' + @DatabaseName + '.dbo.' + @TableName + ';' + CHAR(10);
			PRINT @SQL;
			EXEC sp_executesql @SQL;
			--PRINT 'EXECUTED';

			FETCH NEXT FROM triggerCursor INTO @TableName;
		END

	--PRINT @TotalSQL;

	CLOSE triggerCursor	
	DEALLOCATE triggerCursor	

GO

EXEC sp_Triggers_Tables_drop;
--select * from IntranetLogs.dbo.sysobjects WHERE XTYPE = 'U' order by name
--SELECT * FROM Intranet_backup..sysobjects;