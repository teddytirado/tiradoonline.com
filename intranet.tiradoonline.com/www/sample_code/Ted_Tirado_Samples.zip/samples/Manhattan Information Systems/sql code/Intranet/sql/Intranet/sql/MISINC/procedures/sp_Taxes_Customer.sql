IF EXISTS (SELECT NAME FROM SYSOBJECTS WHERE NAME = 'sp_Taxes_Customer_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Taxes_Customer_get;
GO

CREATE PROCEDURE sp_Taxes_Customer_get
	@CustomerID	CHAR(12)	
AS

	SELECT TOP 1
		a.CODETAXGRP,
		b.AUTHORITY1,
		c.ITEMRATE1 AS TaxRate
	FROM
		ARCUS a,
		TXGRP b,
		TXRATE c
	WHERE
		a.IDCUST = @CustomerID AND
		a.CODETAXGRP = b.GROUPID AND
		b.AUTHORITY1 = C.AUTHORITY


GO

EXEC sp_Taxes_Customer_get '05SOCG0001'