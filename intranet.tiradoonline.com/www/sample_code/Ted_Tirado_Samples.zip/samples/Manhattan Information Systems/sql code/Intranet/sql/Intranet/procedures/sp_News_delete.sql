IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_News_delete' AND TYPE = 'P')
	DROP PROCEDURE sp_News_delete;
GO


CREATE PROCEDURE sp_News_delete
	@NewsID		INT
AS

	DELETE News WHERE NewsID = @NewsID;

GO

--EXEC sp_News_delete 26

