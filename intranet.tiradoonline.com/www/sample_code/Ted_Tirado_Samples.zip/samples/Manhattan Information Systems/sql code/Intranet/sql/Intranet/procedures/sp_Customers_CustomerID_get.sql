IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Customers_CustomerID_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Customers_CustomerID_get;
GO


CREATE PROCEDURE sp_Customers_CustomerID_get
	@CustomerID		VARCHAR(20)
AS

	SELECT 
		* 
	FROM 
		MISINC..ARCUS
	WHERE
		LTRIM(RTRIM(IDCUST)) = LTRIM(RTRIM(@CustomerID));


GO


EXEC sp_Customers_CustomerID_get '18STBA1000'