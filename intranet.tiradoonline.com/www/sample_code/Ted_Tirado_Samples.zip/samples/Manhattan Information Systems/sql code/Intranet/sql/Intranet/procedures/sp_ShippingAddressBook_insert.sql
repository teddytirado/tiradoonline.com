IF EXISTS (SELECT NAME FROM SYSOBJECTS WHERE NAME = 'sp_ShippingAddressBook_insert' AND TYPE = 'P')
	DROP PROCEDURE sp_ShippingAddressBook_insert;
GO


CREATE PROCEDURE sp_ShippingAddressBook_insert
	@SalesID			VARCHAR(10),
	@CustomerID			VARCHAR(50),
	@CustomerName			VARCHAR(50),
	@Address1			VARCHAR(50),
	@Address2			VARCHAR(50),
	@Address3			VARCHAR(50),
	@Address4			VARCHAR(50),
	@City				VARCHAR(20),
	@StateID			VARCHAR(2),
	@ZipCode			VARCHAR(20)
AS

	INSERT INTO ShippingAddressBook
		(SalesID, CustomerID, CustomerName, Address1, Address2, Address3, Address4, City, StateID, ZipCode)
	VALUES
		(@SalesID, @CustomerID, @CustomerName, @Address1, @Address2, @Address3, @Address4, @City, @StateID, @ZipCode);

GO

--EXEC sp_ShippingAddressBook_insert '999', 1001 
