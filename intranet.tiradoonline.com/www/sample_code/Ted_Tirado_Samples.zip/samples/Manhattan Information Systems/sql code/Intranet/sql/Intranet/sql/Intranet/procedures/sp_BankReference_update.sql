IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_BankReference_update' AND TYPE = 'P')
	DROP PROCEDURE sp_BankReference_update;
GO


CREATE PROCEDURE sp_BankReference_update
	@BankName 		VARCHAR(50),
	@Address1 		VARCHAR(50),
	@Address2 		VARCHAR(50),
	@City 			VARCHAR(50),
	@StateID 		VARCHAR(2),
	@Contact 		VARCHAR(50),
	@Phone 			VARCHAR(30),
	@Fax 			VARCHAR(20),
	@CheckingAccount 	VARCHAR(20),
	@SavingsAccount 	VARCHAR(20),
	@update_by 		VARCHAR(50)
AS
		
	SELECT
		*
	FROM
		BankReference;

GO

EXEC sp_BankReference_update 