IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_ServiceReport_SerialNumber_Search' AND TYPE = 'P')
	DROP PROCEDURE sp_ServiceReport_SerialNumber_Search;
GO


CREATE PROCEDURE sp_ServiceReport_SerialNumber_Search
	@SerialNumber		NVARCHAR(50),
	@StartDate 		DATETIME,
	@EndDate 		DATETIME
AS

	SET @SerialNumber = '%' + @SerialNumber + '%';
	SELECT 
		DISTINCT a.SerialNumber,
		COUNT(*) AS ServiceReportsTotal
	FROM
		ServicedSerialNumbers a,
		ServiceReport b
	WHERE
		a.ServiceReportNumber = b.ServiceReportNumber AND
		b.CompanyID IS NOT NULL AND
		UPPER(a.SerialNumber) LIKE UPPER(@SerialNumber)
	GROUP BY
		a.SerialNumber;

GO

EXEC sp_ServiceReport_SerialNumber_Search 'hp', '1/1/05', '2/2/10'