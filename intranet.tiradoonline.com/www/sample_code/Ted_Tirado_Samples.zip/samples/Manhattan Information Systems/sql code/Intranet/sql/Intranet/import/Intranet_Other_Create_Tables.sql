CREATE TABLE AccessLvl
(
	AccessLvl nvarchar (50) NOT NULL,
	AccessLvlName varchar (20) NOT NULL 
);

CREATE TABLE AttendanceAMPM 
(
	AMPM varchar (2) NOT NULL 
);

CREATE TABLE AttendanceType 
(
	AttendanceTypeID int NOT NULL,
	AttendanceType varchar (50) NOT NULL,
	AttendanceTypeColor varchar (7) NOT NULL 
);

CREATE TABLE AttendanceWorkDays 
(
	AttendanceWorkDayID int IDENTITY (1, 1) NOT NULL,
	SalesID nvarchar (255) NOT NULL,
	AttendanceWorkPeriodID int NULL,
	AttendanceTypeID int NOT NULL,
	StartTime datetime NOT NULL,
	Comment nvarchar (2000) NULL,
	create_dt datetime DEFAULT GETDATE() NULL 
);

CREATE TABLE AttendanceWorkPeriod 
(
	AttendanceWorkPeriodID int IDENTITY (1, 1) NOT NULL,
	StartPeriodDate smalldatetime NOT NULL,
	EndPeriodDate smalldatetime NOT NULL,
	PayPeriodDate smalldatetime NULL,
	create_dt datetime DEFAULT GETDATE() NULL 
);

CREATE TABLE Carrier 
(
	DSID int NOT NULL,
	CarrierName nvarchar (50) NULL,
	CarrierAbb nvarchar (50) NULL,
	DSType nvarchar (50) NULL ,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);

CREATE TABLE CarrierType 
(
	CTID int NOT NULL,
	CarrierID nvarchar (50) NULL,
	DSType nvarchar (50) NULL,
	DSColor nvarchar (50) NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);

CREATE TABLE Division 
(
	DivisionID int NOT NULL,
	Division nvarchar (50) NULL, 
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);

CREATE TABLE Emails 
(
	EmailID int IDENTITY (1, 1) NOT NULL,
	ToEmail nvarchar (100) NULL,
	FromEmail nvarchar (100) NULL,
	Subject nvarchar (255) NULL,
	BodyText ntext NULL,
	isHTML int NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);

CREATE TABLE InvalidLogins 
(
	InvalidLoginID int IDENTITY (1, 1) NOT NULL,
	SalesID nvarchar (50) NULL,
	UPassword nvarchar (50) NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);

CREATE TABLE ItemCategory 
(
	ItemCategoryID int IDENTITY (1001, 1) NOT NULL,
	CategoryValue varchar (10) NOT NULL,
	Category varchar (30) NOT NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);

CREATE TABLE News 
(
	NewsID int NOT NULL,
	NewsDate smalldatetime NULL,
	Title varchar (150) NULL,
	Body text NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);

CREATE TABLE PageLogs 
(
	PageLogID int IDENTITY (1, 1) NOT NULL,
	SalesID nvarchar (255) NOT NULL,
	SCRIPT_NAME varchar (255) NOT NULL,
	REQUEST_METHOD varchar (20) NULL,
	QUERY_STRING text NULL,
	FORM text NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);

CREATE TABLE SalesAssistants 
(
	SalesAssistantID int IDENTITY (1, 1) NOT NULL,
	SalesID nvarchar (255) NOT NULL,
	AssistantSalesID nvarchar (255) NOT NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);

CREATE TABLE States
(
	StateID int IDENTITY (1, 1) NOT NULL,
	StateAbbr varchar (3) NOT NULL,
	StateName varchar (50) NOT NULL,
	create_dt smalldatetime NOT NULL 
);

CREATE TABLE Userz
(
	UserID int IDENTITY (1, 1) NOT NULL,
	SalesID nvarchar (255) NOT NULL,
	UPassword nvarchar (255) NULL,
	FirstName nvarchar (255) NULL,
	LastName nvarchar (50) NULL,
	Email nvarchar (50) NULL,
	Extension nvarchar (50) NULL,
	CellPhone nvarchar (50) NULL,
	DivisionID int NULL,
	MakeSale nvarchar (50) NULL,
	AccessLvl nvarchar (50) NULL,
	FAXNum nvarchar (50) NULL,
	ARTransaction nvarchar (255) NULL,
	ARName nvarchar (255) NULL,
	ARID nvarchar (255) NULL,
	ARInvoice nvarchar (255) NULL,
	OEWork nvarchar (50) NULL,
	OEPO nvarchar (50) NULL,
	OEInvoice nvarchar (50) NULL,
	OEUninvoiced nvarchar (50) NULL,
	APCheck nvarchar (50) NULL,
	APInvoice nvarchar (50) NULL,
	ICSerial nvarchar (50) NULL,
	GLGL nvarchar (50) NULL,
	POWO nvarchar (50) NULL,
	POPO nvarchar (50) NULL,
	ReportsCategory nvarchar (50) NULL,
	ReportsSales nvarchar (50) NULL,
	ReportsCash nvarchar (50) NULL,
	ReportsDaily nvarchar (50) NULL,
	ARReports nvarchar (50) NULL,
	SHItem nvarchar (50) NULL,
	SHDesc nvarchar (50) NULL,
	UserControl nvarchar (50) NULL,
	EWQ nvarchar (50) NULL,
	EWPOA nvarchar (50) NULL,
	EWAcct nvarchar (50) NULL,
	EWWare nvarchar (50) NULL,
	APCR nvarchar (50) NULL,
	TPE nvarchar (50) NULL,
	CCA nvarchar (50) NULL,
	NEWS nvarchar (50) NULL,
	Invent nvarchar (50) NULL,
	Terminated bit NOT NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);

CREATE TABLE Vendor
(
	VendorID int IDENTITY (1, 1) NOT NULL,
	SalesID nvarchar (50) NULL,
	VendorName nvarchar (50) NULL,
	VendorNameAbb nvarchar (50) NULL,
	VendorContact nvarchar (50) NULL,
	VendorEmail nvarchar (50) NULL,
	VendorPhone nvarchar (50) NULL,
	VendorFax nvarchar (50) NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);

CREATE TABLE NewItem
(
	NewItemID int IDENTITY (1, 1) NOT NULL,
	ItemID nvarchar (50) NULL,
	SPNumber nvarchar (50) NULL,
	ItemDesc nvarchar (255) NULL,
	WONum nvarchar (50) NULL,
	create_dt smalldatetime DEFAULT GETDATE() NULL 
);

