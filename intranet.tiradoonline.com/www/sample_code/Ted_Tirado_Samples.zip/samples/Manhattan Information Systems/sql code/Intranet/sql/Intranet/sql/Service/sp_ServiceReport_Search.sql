IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_ServiceReport_Search' AND TYPE = 'P')
	DROP PROCEDURE sp_ServiceReport_Search;
GO


CREATE PROCEDURE sp_ServiceReport_Search
	@Company 		NVARCHAR(50),
	@ServiceReportNumber	INT,
	@RepairYear 		INT,
	@SearchBy		VARCHAR(20)
AS
	IF @SearchBy = 'Company' 
		BEGIN
			IF @Company IS NULL
				BEGIN
					SELECT 
						DISTINCT a.Company,
						COUNT(*) AS ServiceReportsTotal,
						LastServiceReportDate = (SELECT TOP 1 RepairDate FROM ServiceReport WHERE CompanyID = a.CompanyID ORDER BY RepairDate DESC)
					FROM 
						ServiceReport a,
						Company b
					WHERE 
						a.CompanyID = b.CompanyID AND
						DATEPART("year", a.RepairDate) >= @RepairYear
					GROUP BY 
						a.Company
					ORDER BY 
						a.Company;
				END
			ELSE
				BEGIN
					SET @Company = '%' + UPPER(@Company) + '%';
		
					SELECT 
						DISTINCT a.Company,
						COUNT(*) AS ServiceReportsTotal,
						LastServiceReportDate = (SELECT TOP 1 RepairDate FROM ServiceReport WHERE Company = a.Company ORDER BY RepairDate DESC)
					FROM 
						ServiceReport a
					WHERE 
						UPPER(a.Company) LIKE @Company AND
						DATEPART("year", RepairDate) >= @RepairYear
					GROUP BY 
						a.Company
					ORDER BY 
						a.Company;
	
		
			
				END
		END
	ELSE IF @SearchBy = 'ServiceReportNumber'
		BEGIN
			SELECT 
				*
			FROM 
				ServiceReport
			WHERE 
				ServiceReportNumber = @ServiceReportNumber
	
		END
		

GO

EXEC sp_ServiceReport_Search '', 1234, 2005, 'ServiceReportNumber' 