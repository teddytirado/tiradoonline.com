IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_WorkOrders_MFGPart_get' AND TYPE = 'P')
	DROP PROCEDURE sp_WorkOrders_MFGPart_get;
GO


CREATE PROCEDURE sp_WorkOrders_MFGPart_get
	@MFGPart		NVARCHAR(50),
	@SalesID		NVARCHAR(50),
	@UserType		TINYINT
AS
	
	IF @UserType > 0
		BEGIN
			SELECT
				CustomerName = (SELECT NAMECUST FROM MISINC..ARCUS WHERE IDCUST = a.WOCustomer COLLATE SQL_Latin1_General_CP1_CI_AS),
				SalesPerson = (SELECT FirstName + ' ' + LastName FROM Userz WHERE SalesID = a.SPNumber COLLATE SQL_Latin1_General_CP1_CI_AS),
				WorkOrderTotal = (SELECT (SUM(WOUPrice * WOQTY) + WOTax) + WODelivery FROM WODetail WHERE WONumber = a.WONumber),
				WorkOrderID = a.WONumber,
				WorkOrderDate = a.WODate,
				a.*,
				b.*
			FROM 
				WorkOrder a,
				WODetail b
			WHERE 
				a.WONumber = b.WONumber AND
				LTRIM(RTRIM(b.WOItemNum)) = @MFGPart
			ORDER BY 
				a.WONumber DESC
		END
	ELSE
		BEGIN
			SELECT
				CustomerName = (SELECT NAMECUST FROM MISINC..ARCUS WHERE IDCUST = a.WOCustomer COLLATE SQL_Latin1_General_CP1_CI_AS),
				SalesPerson = (SELECT FirstName + ' ' + LastName FROM Userz WHERE SalesID = a.SPNumber COLLATE SQL_Latin1_General_CP1_CI_AS),
				WorkOrderTotal = (SELECT (SUM(WOUPrice * WOQTY) + WOTax) + WODelivery FROM WODetail WHERE WONumber = a.WONumber),
				WorkOrderID = a.WONumber,
				WorkOrderDate = a.WODate,
				a.*,
				b.*
			FROM 
				WorkOrder a,
				WODetail b
			WHERE 
				a.WONumber = b.WONumber AND
				(a.SPNumber = @SalesID OR
				a.SPNumber IN (SELECT SalesID COLLATE SQL_LATIN1_GENERAL_CP1_CI_AS FROM SalesAssistants WHERE AssistantSalesID = @SalesID)) AND
				LTRIM(RTRIM(b.WOItemNum)) = @MFGPart
			ORDER BY 
				a.WONumber DESC

		END

GO

EXEC sp_WorkOrders_MFGPart_get '102667403', '999', 1
