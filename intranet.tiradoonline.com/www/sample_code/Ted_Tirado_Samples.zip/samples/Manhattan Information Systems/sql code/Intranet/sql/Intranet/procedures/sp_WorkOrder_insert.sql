IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_WorkOrder_insert' AND TYPE = 'P')
	DROP PROCEDURE sp_WorkOrder_insert;
GO


CREATE PROCEDURE sp_WorkOrder_insert
	@QID		INT,
	@CustomerPO	VARCHAR(50)
AS

	--IF NOT EXISTS (SELECT * FROM WorkOrder WHERE QID = @QID)
		--BEGIN
			BEGIN TRANSACTION TranWorkOrder
			
			
			/*****************************
				QUOTE 
			******************************/
			INSERT INTO WorkOrder
				(QID, SPNumber, PreparedByID, Attn, Phone, QuoteDate, Terms, WOCustomer, WODate, ShippingMeth, CustomerPO, WONote, WODelivery, WOTaxRate, WOTax, WOTaxable, Status)
			SELECT
				QID, SPNumber, PreparedByID, Attn, Phone, QuoteDate, Terms, WOCustomer, GETDATE(), ShippingMeth, @CustomerPO, WONote, WODelivery, WOTaxRate, WOTax, WOTaxable, 1
			FROM 
				Quote
			WHERE
				QID = @QID;
			
			DECLARE @WorkOrderID 		INT;
			SET @WorkOrderID = @@IDENTITY;
		
			UPDATE WorkOrder SET
				WONumbers = @WorkOrderID 
			WHERE
				WONumber = @WorkOrderID;
		
			/*****************************
				WORK ORDER DETAIL
			******************************/
			INSERT INTO WODetail
				(WONumber, LineNum, WODesc, WOCost, Markup, WOItemNum, WOQTY, WOUPrice, VendorID, CTID, WOVenNum, ItemPO)
			SELECT
				@WorkOrderID, LineNum, WODesc, WOCost, Markup, WOItemNum, WOQTY, WOUPrice, VendorID, CTID, WOVenNum, 0
			FROM 
				QuoteDetail
			WHERE
				QID = @QID;
			
			/*****************************
				CUSTSHIP
			******************************/
			INSERT INTO CustShip
				(WONumber, QID, CustomerNum, CustName, CustAdd1, CustAdd2, CustAdd3, CustAdd4, CustState, CustCity, CustZip)
			SELECT
				@WorkOrderID, QID, CustomerNum, CustName, CustAdd1, CustAdd2, CustAdd3, CustAdd4, CustState, CustCity, CustZip
			FROM 
				CustShipQ
			WHERE
				QID = @QID;
		
			
			/*****************************
				CONVERT QUOTE, QUOTEDETAIL
			******************************/
			UPDATE Quote SET Conv = 1 WHERE QID = @QID;
			UPDATE QuoteDetail SET Conv = 1 WHERE QID = @QID;
		
			IF @@ERROR <> 0
				ROLLBACK TRAN TranWorkOrder;
			ELSE
				COMMIT TRAN TranWorkOrder;
		
			
			SELECT 
				WorkOrderID = @WorkOrderID, 
				SalesPersonID = SPNumber, 
				CustomerID = WOCustomer 
			FROM 
				WorkOrder
			WHERE
				WONumber = @WorkOrderID;
		--END	
		
GO

--exec sp_WorkOrder_insert 18634, 'sdfg'