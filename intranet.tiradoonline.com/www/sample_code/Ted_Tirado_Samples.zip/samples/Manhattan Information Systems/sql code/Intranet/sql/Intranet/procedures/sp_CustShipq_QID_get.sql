IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_CustShipq_QID_get' AND TYPE = 'P')
	DROP PROCEDURE sp_CustShipq_QID_get;
GO


CREATE PROCEDURE sp_CustShipq_QID_get
	@QID			INT
AS

	SELECT
		* 
	FROM
		CustShipQ
	WHERE
		QID = @QID;

GO

exec sp_CustShipq_QID_get 18589