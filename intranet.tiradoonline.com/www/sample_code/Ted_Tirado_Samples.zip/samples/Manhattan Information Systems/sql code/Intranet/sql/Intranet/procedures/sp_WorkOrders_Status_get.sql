IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_WorkOrders_Status_get' AND TYPE = 'P')
	DROP PROCEDURE sp_WorkOrders_Status_get;
GO


CREATE PROCEDURE sp_WorkOrders_Status_get
	@Status		TINYINT

AS
			SELECT
				CustomerName = (SELECT NAMECUST FROM MISINC..ARCUS WHERE IDCUST = WorkOrder.WOCustomer COLLATE SQL_Latin1_General_CP1_CI_AS),
				SalesPerson = (SELECT FirstName + ' ' + LastName FROM Userz WHERE SalesID = WorkOrder.SPNumber COLLATE SQL_Latin1_General_CP1_CI_AS),
				PO = CustomerPO,
				WOCustomer,
				WorkOrderDate = WODate,
				WorkOrderID = WONumber,
				WorkOrderTotal = (SELECT SUM(WOUPrice * WOQTY) + WOTax + WODelivery FROM WODetail WHERE WONumber = WorkOrder.WONumber)
			FROM 
				WorkOrder
			WHERE 
				Status = @Status
			ORDER BY 
				WONumber DESC

GO

exec sp_WorkOrders_Status_get 2;
exec sp_WorkOrders_Status_get 4;
