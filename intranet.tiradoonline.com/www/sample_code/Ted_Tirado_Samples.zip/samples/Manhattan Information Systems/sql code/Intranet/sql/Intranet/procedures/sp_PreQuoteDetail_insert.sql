IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_PreQuoteDetail_insert' AND TYPE = 'P')
	DROP PROCEDURE sp_PreQuoteDetail_insert;
GO


CREATE PROCEDURE sp_PreQuoteDetail_insert
	@PreQID		INT,
	@VendorID	NVARCHAR(50),
	@WOCost		NVARCHAR(50),
	@Markup		NUMERIC(18,2),
	@WOItemNum	NVARCHAR(50),
	@WODesc		VARCHAR(2000),
	@WOVenNum	NVARCHAR(50)
AS
	
	DECLARE @LineNum 	INT;

	SET @LineNum = (SELECT MAX(LineNum) FROM PreQuoteDetail WHERE PreQID = @PreQID)
	IF @LineNum IS NULL
		SET @LineNum = 1;
	ELSE
		SET @LineNum = @LineNum + 1;

	IF NOT EXISTS (SELECT * FROM Vendor WHERE CONVERT(VARCHAR, VendorID) = CONVERT(VARCHAR, @VendorID))
		SET @VendorID = NULL;

	INSERT INTO PreQuoteDetail 
		(PreQID, LineNum, WOCost, Markup, WOItemNum, WOQTY, WODesc, WOUPrice, VendorID, CTID, WOVenNum, Conv)
	VALUES
		(@PreQID, @LineNum, @WOCost, @Markup, @WOItemNum, '0', @WODesc, '0.00', @VendorID, 'NONE', @WOVenNum, '0');

	SELECT @@IDENTITY;

GO
--SELECT * FROM Vendor WHERE CONVERT(VARCHAR, VendorID) = CONVERT(VARCHAR, '43979G')
--EXEC sp_PreQuoteDetail_insert '1684', '43979G', '53.99', '910000240', 'Logitech Cordless Laser Mouse', 'TECH1000' 