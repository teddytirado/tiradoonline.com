IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_AttendanceType_get' AND TYPE = 'P')
	DROP PROCEDURE sp_AttendanceType_get;
GO


CREATE PROCEDURE sp_AttendanceType_get
AS

	SELECT
			*
	FROM
		AttendanceType
	ORDER BY
		AttendanceType;
	
	
GO



exec sp_AttendanceType_get