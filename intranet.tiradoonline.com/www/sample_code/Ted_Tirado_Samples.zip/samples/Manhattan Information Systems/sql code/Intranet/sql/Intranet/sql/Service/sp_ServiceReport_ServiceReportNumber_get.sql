IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_ServiceReport_ServiceReportNumber_get' AND TYPE = 'P')
	DROP PROCEDURE sp_ServiceReport_ServiceReportNumber_get;
GO


CREATE PROCEDURE sp_ServiceReport_ServiceReportNumber_get
	@ServiceReportNumber	VARCHAR(10)

AS
	DECLARE @TotalAmount 	MONEY;

	SELECT 
		*,
		close_by = (SELECT FirstName + ' ' + Lastname FROM Intranet..Userz WHERE SalesID = ServiceReport.close_by),
		update_by = (SELECT FirstName + ' ' + Lastname FROM Intranet..Userz WHERE SalesID = ServiceReport.update_by),
		create_by = (SELECT FirstName + ' ' + Lastname FROM Intranet..Userz WHERE SalesID = ServiceReport.create_by)
	FROM 
		ServiceReport 
	WHERE 
		ServiceReportNumber = @ServiceReportNumber;

GO

EXEC sp_ServiceReport_ServiceReportNumber_get '988'