IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_PageLogs_SalesID_get' AND TYPE = 'P')
	DROP PROCEDURE sp_PageLogs_SalesID_get;
GO


CREATE PROCEDURE sp_PageLogs_SalesID_get
AS

	DECLARE @create_dt 	DATETIME
	SET @create_dt = GETDATE();


	SELECT
		DISTINCT a.SalesID
		SalesPerson = b.FirstName + '' '' + b.LastName
	FROM
		PageLogs a,
		Userz b
	WHERE
		a.SalesID = b.SalesID AND
		DATEPART(month, a.create_dt) = DATEPART(month, @create_dt) AND
		DATEPART(day, a.create_dt) = DATEPART(day, @create_dt) AND 
		DATEPART(year, a.create_dt) = DATEPART(year, @create_dt)
	ORDER BY
		a.create_dt DESC;
	
GO

EXEC sp_PageLogs_SalesID_get '8/14/08'