IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_CreditMemo_update' AND TYPE = 'P')
	DROP PROCEDURE sp_CreditMemo_update;
GO


CREATE PROCEDURE sp_CreditMemo_update
	@CreditMemoNumber 		VARCHAR(20),
	@CreditMemoDate 		DATETIME,
	@ReferenceNumber		VARCHAR(20),
	@ServiceReportNumber		VARCHAR(10),
	@SalesID			VARCHAR(10),
	@ServiceDate			DATETIME,
	@PONumber			VARCHAR(10),
	@PartNumber			VARCHAR(20),
	@PartDescription		VARCHAR(50),
	@Claim				VARCHAR(20),
	@VendorID			INT,
	@LaborReimbursement		BIT,
	@LaborAmount			MONEY,
	@CheckNumber			INT,
	@PaidDate			DATETIME,
	@PaidAmount			MONEY,
	@Notes				VARCHAR(1000)

AS
	
			BEGIN TRANSACTION TranCreditMemo
			UPDATE CreditMemo SET
				CreditMemoDate = @CreditMemoDate,
				ReferenceNumber = @ReferenceNumber,
				ServiceReportNumber = @ServiceReportNumber,
				PartNumber = @PartNumber,
				PartDescription = @PartDescription,
				Claim = @Claim,
				VendorID = @VendorID,
				LaborReimbursement = @LaborReimbursement,
				LaborAmount = @LaborAmount,
				CheckNumber = @CheckNumber,
				PaidDate = @PaidDate,
				PaidAmount = @PaidAmount,
				Notes = @Notes,
				update_by = @SalesID,
				update_dt = GETDATE()
			WHERE
				CreditMemoNumber = @CreditMemoNumber;
			
			UPDATE ServiceReport SET
				ServiceDate = @ServiceDate,
				PONumber = @PONumber
			WHERE
				ServiceReportNumber = @ServiceReportNumber;
				
			IF @@ERROR <> 0
				ROLLBACK TRAN TranCreditMemo;
			ELSE
				COMMIT TRAN TranCreditMemo;
GO

