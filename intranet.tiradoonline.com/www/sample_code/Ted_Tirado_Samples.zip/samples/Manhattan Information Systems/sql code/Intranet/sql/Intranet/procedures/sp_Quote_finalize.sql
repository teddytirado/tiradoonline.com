IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Quote_finalize' AND TYPE = 'P')
	DROP PROCEDURE sp_Quote_finalize;
GO


CREATE PROCEDURE sp_Quote_finalize
	@QID		INT
AS
	
	BEGIN TRAN T1
		UPDATE QuoteDetail SET Conv = '1' WHERE QID = @QID;
		UPDATE Quote SET Conv = '1' WHERE QID = @QID;
		IF @@ERROR <> 0 ROLLBACK TRAN T1
	COMMIT TRAN
GO		

--exec sp_Quote_finalize