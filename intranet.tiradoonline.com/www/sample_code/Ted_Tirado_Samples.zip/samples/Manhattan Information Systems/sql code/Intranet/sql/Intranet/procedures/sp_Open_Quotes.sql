IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Open_Quotes' AND TYPE = 'P')
	DROP PROCEDURE sp_Open_Quotes;
GO


CREATE PROCEDURE sp_Open_Quotes
AS
	
	SELECT
		SalesPerson = b.FirstName + ' ' + b.LastName,
		a.SalesID,
		a.PreparedByID,
		a.create_dt
	FROM
		PreQuote a,
		Userz b
	WHERE
		a.SalesID = b.SalesID COLLATE SQL_Latin1_General_CP1_CI_AS 
	
GO		

exec sp_Open_Quotes
