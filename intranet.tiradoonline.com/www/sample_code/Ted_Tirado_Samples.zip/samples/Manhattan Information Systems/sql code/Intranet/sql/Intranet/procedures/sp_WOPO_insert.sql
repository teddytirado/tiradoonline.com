IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_WOPO_insert' AND TYPE = 'P')
	DROP PROCEDURE sp_WOPO_insert;
GO


CREATE PROCEDURE sp_WOPO_insert
	@WONumber		INT,
	@POIDs			VARCHAR(50), 
	@PONum			VARCHAR(50), 
	@POShip			VARCHAR(50), 
	@Method			VARCHAR(50)
AS

	INSERT INTO WOPO 
		(WONumber, POIDs, PONum, POShip, Method) 	
	VALUES
		(@WONumber, @POIDs, @PONum, @POShip, @Method);

GO

