IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Vendors_insert' AND TYPE = 'P')
	DROP PROCEDURE sp_Vendors_insert;
GO


CREATE PROCEDURE sp_Vendors_insert
	@VendorName		VARCHAR(20),
	@create_by		VARCHAR(10)
AS
	
	IF NOT EXISTS (SELECT VendorName FROM Vendors WHERE VendorName = @VendorName)
		BEGIN
			INSERT INTO Vendors
				(VendorName,
				update_by,
				create_by)
			VALUES 
				(@VendorName,
				@create_by,
				@create_by);

			SELECT VendorID = @@IDENTITY;
		END
	ELSE
		SELECT VendorID = 0;
GO

--EXEC sp_Vendors_insert 4545452, 167, 'tiradoonline.com', '999', '0.0825', '7/1/10', '9:00 am', '10:00 am', 'Remarks', 'Problems', 'Solutions', '7/2/10', '10:00 am', 1, 0, 1, 'other description', 'PO Number', 'WO Number', 0, 0.00, 0, 0.00, 0.00, 0.00, 0.00, 'Theodore Tirado', '347.414.1284', '3115', 0.00