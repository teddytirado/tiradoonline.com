IF EXISTS (SELECT NAME FROM SYSOBJECTS WHERE NAME = 'vw_ItemLookup' AND TYPE = 'V')
	DROP VIEW vw_ItemLookup;
GO

CREATE VIEW vw_ItemLookup
AS

	SELECT 
		a.INVNUMBER AS InvoiceNumber,
		RevisedInvoiceDate = CONVERT(VARCHAR, (SUBSTRING(CONVERT(VARCHAR, a.INVDATE), 5, 2) + '/' + 
				     RIGHT(CONVERT(VARCHAR, a.INVDATE), 2) + '/' + 
				     LEFT(CONVERT(VARCHAR, a.INVDATE), 4))), 
		a.BILNAME,
		a.PONUMBER,
		a.SALESPER1,
		b.QTYSHIPPED AS Quantity,
		b.PRIUNTPRC AS Unit_Price,
		b.UNITCOST AS Unit_Cost,
		TotalCost = b.UNITCOST * b.QTYSHIPPED,
		Profit = b.PRIUNTPRC - (b.UNITCOST * b.QTYSHIPPED),
		b.ITEM AS ItemNumber,
		a.SHIPVIA,
		a.REFERENCE
	FROM 
		OEINVH a, 
		OEINVD b
	WHERE 
		a.INVNUMBER = b.INVNUMBER;		
GO

SELECT TOP 5 * FROM MISINC..vw_ItemLookup WHERE CONVERT(DATETIME, RevisedInvoiceDate) >= '20110401' AND CONVERT(DATETIME, RevisedInvoiceDate) <= '20110430' ORDER BY RevisedInvoiceDate DESC 
