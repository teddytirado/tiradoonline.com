IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_AttendanceWorkDays_delete' AND TYPE = 'P')
	DROP PROCEDURE sp_AttendanceWorkDays_delete;
GO


CREATE PROCEDURE sp_AttendanceWorkDays_delete
	@AttendanceWorkDayID		INT
AS

	DELETE FROM AttendanceWorkDays WHERE AttendanceWorkDayID = @AttendanceWorkDayID;
GO


--EXEC sp_AttendanceWorkDays_delete '2/11/08'