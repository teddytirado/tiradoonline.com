IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Reports_AttendanceWorkPeriod_TotalTime' AND TYPE = 'P')
	DROP PROCEDURE sp_Reports_AttendanceWorkPeriod_TotalTime;
GO

CREATE PROCEDURE sp_Reports_AttendanceWorkPeriod_TotalTime
	@SalesID	NVARCHAR(255)
AS
	SELECT
		StartPeriodDate,
		EndPeriodDate,
		PayPeriodDate,
		TotalTime = (SELECT SUM((DATEPART(hh, StartTime) * 60) + DATEPART(mi, StartTime))
				FROM AttendanceWorkDays WHERE AttendanceWorkPeriodID = AttendanceWorkPeriod.AttendanceWorkPeriodID AND SalesID = @SalesID)
		--,Hours = (SELECT SUM((DATEPART(hh, StartTime) * 60) + DATEPART(mi, StartTime))
		--		FROM AttendanceWorkDays WHERE AttendanceWorkPeriodID = AttendanceWorkPeriod.AttendanceWorkPeriodID AND SalesID = '999') / 60
	FROM
		AttendanceWorkPeriod
	ORDER BY 
		StartPeriodDate DESC
GO

EXEC sp_Reports_AttendanceWorkPeriod_TotalTime '999'