IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Vendors_Letter_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Vendors_Letter_get;
GO


CREATE PROCEDURE sp_Vendors_Letter_get
	@Letter		VARCHAR(3)

AS

	IF @Letter = 'ALL'
		BEGIN
			SELECT 
				TotalCreditMemos = (SELECT COUNT(*) FROM CreditMemo WHERE VendorID = Vendors.VendorID),
				VendorID,
				VendorName,
				update_by = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = Vendors.create_by  COLLATE SQL_Latin1_General_CP1_CS_AS),
				update_dt,
				create_by = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = Vendors.create_by  COLLATE SQL_Latin1_General_CP1_CS_AS),
				create_dt
			FROM 
				Vendors 
			ORDER BY 
				VendorName
		END
	ELSE
		BEGIN
			SET @Letter = @Letter + '%';
			
			SELECT 
				TotalCreditMemos = (SELECT COUNT(*) FROM CreditMemo WHERE VendorID = Vendors.VendorID),
				VendorID,
				VendorName,
				update_by = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = Vendors.create_by  COLLATE SQL_Latin1_General_CP1_CS_AS),
				update_dt,
				create_by = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = Vendors.create_by  COLLATE SQL_Latin1_General_CP1_CS_AS),
				create_dt
			FROM 
				Vendors 
			WHERE 
				UPPER(VendorName) LIKE @Letter
			ORDER BY 
				VendorName;
		END	

GO

EXEC sp_Vendors_Letter_get 'all'