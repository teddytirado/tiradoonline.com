IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_CreditMemo_100_get' AND TYPE = 'P')
	DROP PROCEDURE sp_CreditMemo_100_get;
GO


CREATE PROCEDURE sp_CreditMemo_100_get
	@CreditMemoNumber 	VARCHAR(10) = NULL
AS

	IF @CreditMemoNumber IS NULL
		BEGIN
			SELECT TOP 100
				CreditMemoNumber,
				CreditMemoDate,
				ReferenceNumber,
				ServiceReportNumber,
				Vendor = (SELECT VendorName FROM Vendors WHERE VendorID = CreditMemo.VendorID),
				PartNumber,
				PartDescription,
				LaborReimbursement,
				LaborAmount,
				PaidAmount,
				PaidDate,
				Status,
				update_by = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = CreditMemo.update_by COLLATE SQL_Latin1_General_CP1_CI_AS),
				update_dt,
				close_by = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = CreditMemo.closed_by COLLATE SQL_Latin1_General_CP1_CI_AS),
				close_dt = closed_dt,
				created_by = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = CreditMemo.create_by COLLATE SQL_Latin1_General_CP1_CI_AS),
				create_dt
			FROM
				CreditMemo
			ORDER BY
				CreditMemoNumber DESC
		END
	ELSE
		BEGIN
			SET @CreditMemoNumber = '%' + @CreditMemoNumber + '%';
			SELECT TOP 100
				CreditMemoNumber,
				CreditMemoDate,
				ReferenceNumber,
				ServiceReportNumber,
				Vendor = (SELECT VendorName FROM Vendors WHERE VendorID = CreditMemo.VendorID),
				PartNumber,
				PartDescription,
				LaborReimbursement,
				LaborAmount,
				PaidAmount,
				PaidDate,
				Status,
				update_by = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = CreditMemo.update_by COLLATE SQL_Latin1_General_CP1_CI_AS),
				update_dt,
				close_by = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = CreditMemo.closed_by COLLATE SQL_Latin1_General_CP1_CI_AS),
				close_dt = closed_dt,
				created_by = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = CreditMemo.create_by COLLATE SQL_Latin1_General_CP1_CI_AS),
				create_dt
			FROM
				CreditMemo
			WHERE
				CreditMemoNumber LIKE @CreditMemoNumber
			ORDER BY
				CreditMemoNumber DESC
		END
GO

EXEC sp_CreditMemo_100_get