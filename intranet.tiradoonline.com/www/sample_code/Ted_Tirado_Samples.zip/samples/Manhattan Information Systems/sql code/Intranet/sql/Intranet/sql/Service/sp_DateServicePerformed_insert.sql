IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_DateServicePerformed_insert' AND TYPE = 'P')
	DROP PROCEDURE sp_DateServicePerformed_insert;
GO


CREATE PROCEDURE sp_DateServicePerformed_insert
	@ServiceReportNumber	NVARCHAR(10),
	@RepairDate		DATETIME,
	@RepairStartTime	VARCHAR(10),
	@RepairEndTime		VARCHAR(10)
AS
	IF NOT EXISTS (SELECT DateServicePerformedID FROM DateServicePerformed WHERE 
				ServiceReportNumber = @ServiceReportNumber AND
				RepairDate = @RepairDate AND 
				RepairStartTime = @RepairStartTime)
		BEGIN 
			INSERT INTO DateServicePerformed
				(ServiceReportNumber,
				RepairDate,
				RepairStartTime,
				RepairEndTime)
			VALUES
				(@ServiceReportNumber,
				@RepairDate,
				@RepairStartTime,
				@RepairEndTime);
		END		
GO

