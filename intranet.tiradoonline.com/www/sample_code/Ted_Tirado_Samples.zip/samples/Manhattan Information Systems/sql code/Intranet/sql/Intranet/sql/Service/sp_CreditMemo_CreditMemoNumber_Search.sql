IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_CreditMemo_CreditMemoNumber_Search' AND TYPE = 'P')
	DROP PROCEDURE sp_CreditMemo_CreditMemoNumber_Search;
GO


CREATE PROCEDURE sp_CreditMemo_CreditMemoNumber_Search
	@CreditMemoNumber		VARCHAR(10),
	@StartDate			DATETIME,
	@EndDate			DATETIME
AS

	SET @CreditMemoNumber = @CreditMemoNumber;

	SET @CreditMemoNumber = '%' + @CreditMemoNumber + '%';

	SELECT
		*,
		Vendor = (SELECT VendorName FROM Vendors WHERE VendorID = CreditMemo.VendorID),
		updated_by = (SELECT FirstName + ' '  + LastName FROM Intranet..Userz WHERE SalesID = CreditMemo.update_by),
		created_by = (SELECT FirstName + ' '  + LastName FROM Intranet..Userz WHERE SalesID = CreditMemo.create_by)
	FROM
		CreditMemo
	WHERE
		CreditMemoDate BETWEEN @StartDate AND @EndDate AND
		CreditMemoNumber LIKE @CreditMemoNumber;
GO

EXEC sp_CreditMemo_CreditMemoNumber_Search '10', '5/20/10', '5/27/10'