IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Convert_Quote_WorkOrder' AND TYPE = 'P')
	DROP PROCEDURE sp_Convert_Quote_WorkOrder;
GO


CREATE PROCEDURE sp_Convert_Quote_WorkOrder
	@QID		INT,
	@WODate		NVARCHAR(50),
	@CustomerPO	NVARCHAR(50)
AS

	DECLARE @WorkOrderID		INT;

	BEGIN TRAN TRANS1
		BEGIN 
			/*  
			 ***************************************
			 INSERT INTO WORKORDER
			 ***************************************
			*/  
			INSERT INTO WorkOrder
				(SPNumber, QID, Attn, Phone, QuoteDate, Terms, WOCustomer, WODate, 
				 ShippingMeth, CustomerPO, WONote, WODelivery, WOTax, WOtaxable)
			SELECT
				 SPNumber, QID, Attn, Phone, QuoteDate, Terms, WOCustomer, @WODate, 
				 ShippingMeth, @CustomerPO, WONote, WODelivery, WOTax, WOtaxable
			FROM 
				Quote
			WHERE
				QID = @QID;
			

			SET @WorkOrderID = (SELECT @@IDENTITY);
			
			PRINT 'WorkOrder: ' + CONVERT(VARCHAR, @@ROWCOUNT);
			PRINT 'ERROR: ' + CONVERT(VARCHAR, @@ERROR);
			IF @@ERROR <> 0 
				ROLLBACK TRAN TRANS1;

			/*  
			 ***************************************
			 INSERT INTO WORKORDER DETAIL
			 ***************************************
			*/  
			INSERT INTO WODetail
				(WONumber, WOLineNum, LineNum, WOCost, WOItemNum, WOQTY, WOUPrice, VendorID, CTID, WOVenNum)
			SELECT
				@WorkOrderID, WOLineNum, LineNum, WOCost, WOItemNum, WOQTY, WOUPrice, VendorID, CTID, WOVenNum
			FROM 
				QuoteDetail
			WHERE
				QID = @QID;
			
			PRINT 'WODetail: ' + CONVERT(VARCHAR, @@ROWCOUNT);
			PRINT 'ERROR: ' + CONVERT(VARCHAR, @@ERROR);
			IF @@ERROR <> 0 
				ROLLBACK TRAN TRANS1;

			/*  
			 ***************************************
			 INSERT INTO CUSTSHIP
			 ***************************************
			*/  
			INSERT INTO CustShip
				(WONumber, QID, CustomerNum, CustName, CustAdd1, CustAdd2, CustAdd3, CustAdd4,
				 CustState, CustCity, CustZip)
			SELECT
				 @WorkOrderID, @QID, CustomerNum, CustName, CustAdd1, CustAdd2, CustAdd3, CustAdd4,
				 CustState, CustCity, CustZip
			FROM
				CustShipQ
			WHERE
				QID = @QID;

			PRINT 'CustShip: ' + CONVERT(VARCHAR, @@ROWCOUNT);
			PRINT 'ERROR: ' + CONVERT(VARCHAR, @@ERROR);

			IF @@ERROR <> 0 
				ROLLBACK TRAN TRANS1;
				
			/*  
			 ***************************************
			 SET Conv on Quote to 1
			 ***************************************
			*/  
			UPDATE Quote SET Conv = '1' WHERE QID = @QID;

			IF @@ERROR <> 0 
				ROLLBACK TRAN TRANS1;
				
			/*  
			 ***************************************
			 SET Conv on QuoteDetail to 1
			 ***************************************
			*/  
			UPDATE QuoteDetail SET Conv = '1' WHERE QID = @QID;

			IF @@ERROR <> 0 
				ROLLBACK TRAN TRANS1;
				
			
			/*  
			 ***************************************
			 COMMIT TRANSACTION
			 ***************************************
			*/  
			COMMIT TRAN TRANS1;

		END

	SELECT WorkOrderID = @WorkOrderID;
GO

EXEC sp_Convert_Quote_WorkOrder 16999, '2/10/08', '345679'

SELECT TOP 10 * FROM workorder order by create_dt desc;
SELECT TOP 10 * FROM wodetail order by create_dt desc;
SELECT TOP 10 * FROM custship order by create_dt desc;


