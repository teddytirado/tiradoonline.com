IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'tr_PreQuote_update' AND TYPE = 'TR')
	DROP TRIGGER tr_PreQuote_update;
GO


drop TRIGGER tr_QuoteDetail_update ON Quote FOR UPDATE
AS
	DECLARE @CAR VARCHAR(20)
	
	--INSERT INTO IntranetLogs.dbo.PreQuote_update SELECT * FROM inserted;

GO  

CREATE TRIGGER tr_PreQuote_update ON PreQuote FOR UPDATE
AS

	INSERT INTO IntranetLogs.dbo.PreQuote_update SELECT * FROM inserted;

GO  

IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'tr_PreQuote_delete' AND TYPE = 'TR')
	DROP TRIGGER tr_PreQuote_delete;
GO


CREATE TRIGGER tr_PreQuote_delete ON PreQuote FOR DELETE
AS

	INSERT INTO IntranetLogs.dbo.PreQuote_delete SELECT * FROM deleted;

GO  

IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'tr_PreQuoteDetail_update' AND TYPE = 'TR')
	DROP TRIGGER tr_PreQuoteDetail_update;
GO


CREATE TRIGGER tr_PreQuoteDetail_update ON PreQuoteDetail FOR UPDATE
AS

	INSERT INTO IntranetLogs.dbo.PreQuoteDetail_update SELECT * FROM inserted;

GO  

IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'tr_PreQuoteDetail_delete' AND TYPE = 'TR')
	DROP TRIGGER tr_PreQuoteDetail_delete;
GO


CREATE TRIGGER tr_PreQuoteDetail_delete ON PreQuoteDetail FOR DELETE
AS

	INSERT INTO IntranetLogs.dbo.PreQuoteDetail_delete SELECT * FROM deleted;

GO  

IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'tr_PreCustShipQ_update' AND TYPE = 'TR')
	DROP TRIGGER tr_PreCustShipQ_update;
GO


CREATE TRIGGER tr_PreCustShipQ_update ON PreCustShipQ FOR UPDATE
AS

	INSERT INTO IntranetLogs.dbo.PreCustShipQ_update SELECT * FROM inserted;

GO  

IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'tr_PreCustShipQ_delete' AND TYPE = 'TR')
	DROP TRIGGER tr_PreCustShipQ_delete;
GO


CREATE TRIGGER tr_PreCustShipQ_delete ON PreCustShipQ FOR DELETE
AS

	INSERT INTO IntranetLogs.dbo.PreCustShipQ_delete SELECT * FROM deleted;

GO  

IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'tr_Quote_update' AND TYPE = 'TR')
	DROP TRIGGER tr_Quote_update;
GO


CREATE TRIGGER tr_Quote_update ON Quote FOR UPDATE
AS

	INSERT INTO IntranetLogs.dbo.Quote_update SELECT * FROM inserted;

GO  

IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'tr_Quote_delete' AND TYPE = 'TR')
	DROP TRIGGER tr_Quote_delete;
GO


CREATE TRIGGER tr_Quote_delete ON Quote FOR DELETE
AS

	INSERT INTO IntranetLogs.dbo.Quote_delete SELECT * FROM deleted;

GO  

IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'tr_QuoteDetail_update' AND TYPE = 'TR')
	DROP TRIGGER tr_QuoteDetail_update;
GO


CREATE TRIGGER tr_QuoteDetail_update ON QuoteDetail FOR UPDATE
AS

	INSERT INTO IntranetLogs.dbo.QuoteDetail_update SELECT * FROM inserted;

GO  

IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'tr_QuoteDetail_delete' AND TYPE = 'TR')
	DROP TRIGGER tr_QuoteDetail_delete;
GO


CREATE TRIGGER tr_QuoteDetail_delete ON QuoteDetail FOR DELETE
AS

	INSERT INTO IntranetLogs.dbo.QuoteDetail_delete SELECT * FROM deleted;

GO  

IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'tr_CustShipQ_update' AND TYPE = 'TR')
	DROP TRIGGER tr_CustShipQ_update;
GO


CREATE TRIGGER tr_CustShipQ_update ON CustShipQ FOR UPDATE
AS

	INSERT INTO IntranetLogs.dbo.CustShipQ_update SELECT * FROM inserted;

GO  

IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'tr_CustShipQ_delete' AND TYPE = 'TR')
	DROP TRIGGER tr_CustShipQ_delete;
GO


CREATE TRIGGER tr_CustShipQ_delete ON CustShipQ FOR DELETE
AS

	INSERT INTO IntranetLogs.dbo.CustShipQ_delete SELECT * FROM deleted;

GO  

IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'tr_WorkOrder_update' AND TYPE = 'TR')
	DROP TRIGGER tr_WorkOrder_update;
GO


CREATE TRIGGER tr_WorkOrder_update ON WorkOrder FOR UPDATE
AS

	INSERT INTO IntranetLogs.dbo.WorkOrder_update SELECT * FROM inserted;

GO  

IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'tr_WorkOrder_delete' AND TYPE = 'TR')
	DROP TRIGGER tr_WorkOrder_delete;
GO


CREATE TRIGGER tr_WorkOrder_delete ON WorkOrder FOR DELETE
AS

	INSERT INTO IntranetLogs.dbo.WorkOrder_delete SELECT * FROM deleted;

GO  

IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'tr_WODetail_update' AND TYPE = 'TR')
	DROP TRIGGER tr_WODetail_update;
GO


CREATE TRIGGER tr_WODetail_update ON WODetail FOR UPDATE
AS

	INSERT INTO IntranetLogs.dbo.WODetail_update SELECT * FROM inserted;

GO  

IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'tr_WODetail_delete' AND TYPE = 'TR')
	DROP TRIGGER tr_WODetail_delete;
GO


CREATE TRIGGER tr_WODetail_delete ON WODetail FOR DELETE
AS

	INSERT INTO IntranetLogs.dbo.WODetail_delete SELECT * FROM deleted;

GO  

IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'tr_CustShip_update' AND TYPE = 'TR')
	DROP TRIGGER tr_CustShip_update;
GO


CREATE TRIGGER tr_CustShip_update ON CustShip FOR UPDATE
AS

	INSERT INTO IntranetLogs.dbo.CustShip_update SELECT * FROM inserted;

GO  

IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'tr_CustShip_delete' AND TYPE = 'TR')
	DROP TRIGGER tr_CustShip_delete;
GO


CREATE TRIGGER tr_CustShip_delete ON CustShip FOR DELETE
AS

	INSERT INTO IntranetLogs.dbo.CustShip_delete SELECT * FROM deleted;

GO  

