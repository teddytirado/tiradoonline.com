IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Userz_Email_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Userz_Email_get;
GO

CREATE PROCEDURE sp_Userz_Email_get
	@Email		nvarchar(255)
AS

	SELECT
		FullName = FirstName + ' ' + LastName,
		*
	FROM
		Userz
	WHERE
		Email = @Email AND
		UserControl = 'yes';


GO

