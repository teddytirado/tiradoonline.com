IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_CustShipq_Shipping_update' AND TYPE = 'P')
	DROP PROCEDURE sp_CustShipq_Shipping_update;
GO


CREATE PROCEDURE sp_CustShipq_Shipping_update
	@QID			INT,
	@CustomerNum		NVARCHAR(50),
	@CustName		NVARCHAR(50),
	@CustAdd1		NVARCHAR(50),
	@CustAdd2		NVARCHAR(50),
	@CustAdd3		NVARCHAR(50),
	@CustAdd4		NVARCHAR(255),
	@CustCity		NVARCHAR(50),
	@CustState		NVARCHAR(50),
	@CustZip		NVARCHAR(50)
AS

	UPDATE CustShipq SET 
		CustomerNum = @CustomerNum,
		CustName = @CustName,
		CustAdd1 = @CustAdd1,
		CustAdd2 = @CustAdd2,
		CustAdd3 = @CustAdd3,
		CustAdd4 = @CustAdd4,
		CustCity = @CustCity,
		CustState = @CustState,
		CustZip = @CustZip
	WHERE 
		QID = @QID;

GO