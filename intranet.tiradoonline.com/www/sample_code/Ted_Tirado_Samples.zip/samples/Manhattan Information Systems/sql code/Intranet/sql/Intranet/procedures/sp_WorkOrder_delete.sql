IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_WorkOrder_delete' AND TYPE = 'P')
	DROP PROCEDURE sp_WorkOrder_delete;
GO


CREATE PROCEDURE sp_WorkOrder_delete
	@WONumber		INT
AS

	BEGIN TRANSACTION TranWorkOrder
	
	
	--DELETE FROM CustShip WHERE WONumber = @WONumber;
	--DELETE FROM WODetail WHERE WONumber = @WONumber;
	--DELETE FROM WorkOrder WHERE WONumber = @WONumber;
	UPDATE WORKORDER SET Active = 0;

	IF @@ERROR <> 0
		ROLLBACK TRAN TranWorkOrder;
	ELSE
		COMMIT TRAN TranWorkOrder;

	
		
GO

--exec sp_WorkOrder_delete 9
