IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Vendor_Letter_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Vendor_Letter_get;
GO


CREATE PROCEDURE sp_Vendor_Letter_get
	@Letter		VARCHAR(3)

AS

	IF @Letter = 'ALL'
		BEGIN
			SELECT 
				TotalServiceReports = (SELECT COUNT(*) FROM ServiceReport WHERE CompanyID = Vendor.CompanyID), *, 
				State = (SELECT StateName 
			FROM 
				Intranet..States 
			WHERE 
				StateAbbr = Vendor.StateID COLLATE SQL_Latin1_General_CP1_CI_AS),
				update_by = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = Vendor.update_by),
				create_by = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = Vendor.create_by)
			FROM 
				Vendor 
			ORDER BY 
				CompanyName
		END
	ELSE
		BEGIN
			SET @Letter = @Letter + '%';
			
			SELECT 
				TotalServiceReports = (SELECT COUNT(*) FROM ServiceReport WHERE CompanyID = Vendor.CompanyID),
				*, 
				State = (SELECT StateName FROM Intranet..States WHERE 
				StateAbbr = Vendor.StateID COLLATE SQL_Latin1_General_CP1_CI_AS),
				update_by = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = Vendor.update_by)
			FROM 
				Intranet..States 
			WHERE 
				UPPER(CompanyName) LIKE @Letter AND
				StateAbbr = Vendor.StateID COLLATE SQL_Latin1_General_CP1_CI_AS,
				update_by = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = Vendor.update_by),
				create_by = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = Vendor.create_by)
			ORDER BY 
				CompanyName;
		END	

GO

EXEC sp_Vendor_Letter_get 'ALL'