IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_PreQuoteDetail_WOLineNum_delete' AND TYPE = 'P')
	DROP PROCEDURE sp_PreQuoteDetail_WOLineNum_delete;
GO


CREATE PROCEDURE sp_PreQuoteDetail_WOLineNum_delete
	@WOLineNum		INT
AS
	DECLARE @PreQID			INT;
	DECLARE @WOLineNum2		INT;
	DECLARE @LineNum		INT;
	DECLARE @SQL			VARCHAR(1000);

	
	SET @PreQID = (SELECT PreQID FROM PreQuoteDetail WHERE WOLineNum = @WOLineNum);
	--PRINT 'PreQID: ' + CONVERT(VARCHAR, @PreQID);

	DELETE FROM PreQuoteDetail WHERE WOLineNum = @WOLineNum;

	DECLARE PreQuoteDetailCursor CURSOR 
		FOR SELECT WOLineNum FROM PreQuoteDetail WHERE PreQID = @PreQID;

	--PRINT 'TOTAL ROWS: ' + CONVERT(VARCHAR, @@CURSOR_ROWS);
	OPEN PreQuoteDetailCursor;

	FETCH NEXT FROM PreQuoteDetailCursor INTO @WOLineNum2;

	SET @LineNum = 1;	
	--PRINT 'LINENUM: ' + CONVERT(VARCHAR, @LineNum);
	WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @SQL = 'UPDATE PreQuoteDetail SET LineNum = ' + CONVERT(VARCHAR, @LineNum) + 'WHERE WOLineNum = ' + CONVERT(VARCHAR, @WOLineNum2);
			--PRINT @SQL;
			EXEC (@SQL);
			SET @LineNum = @LineNum + 1;	
			--PRINT 'LINENUM: ' + CONVERT(VARCHAR, @LineNum);
			FETCH NEXT FROM PreQuoteDetailCursor INTO @WOLineNum2;
		END

	CLOSE PreQuoteDetailCursor;
	DEALLOCATE PreQuoteDetailCursor;
GO

exec sp_PreQuoteDetail_WOLineNum_delete  36672


select top 10 * from PreQuoteDetail order by create_dt desc
