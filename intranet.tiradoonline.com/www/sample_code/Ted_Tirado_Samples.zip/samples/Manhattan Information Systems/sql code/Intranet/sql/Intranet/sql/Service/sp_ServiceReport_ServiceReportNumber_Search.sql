IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_ServiceReport_ServiceReportNumber_Search' AND TYPE = 'P')
	DROP PROCEDURE sp_ServiceReport_ServiceReportNumber_Search;
GO


CREATE PROCEDURE sp_ServiceReport_ServiceReportNumber_Search
	@ServiceReportNumber	NVARCHAR(10),
	@StartDate 		DATETIME,
	@EndDate 		DATETIME,
	@SortBy			VARCHAR(30)

AS

	SET NOCOUNT ON;
	DECLARE @SQL_STRING VARCHAR(1000);

	/***********************************/
	/* SEARCH BY SERVICE REPORT NUMBER */
	/***********************************/

	SET @ServiceReportNumber = '%' + @ServiceReportNumber + '%';

	SET @SQL_STRING = 'SELECT *, Customer = (SELECT CompanyName FROM Companies WHERE CompanyID = ServiceReport.CompanyID), 
			Service_Date = ServiceReport.ServiceDate, close_by = (SELECT FirstName + '' '' + LastName FROM Intranet..Userz WHERE 
			SalesID = ServiceReport.close_by), update_by = (SELECT FirstName + '' '' + LastName FROM Intranet..Userz WHERE 
			SalesID = ServiceReport.update_by), create_by = (SELECT FirstName + '' '' + LastName FROM Intranet..Userz WHERE 
			SalesID = ServiceReport.create_by) FROM ServiceReport WHERE CompanyID IS NOT NULL AND ServiceReportNumber 
			LIKE ''' + @ServiceReportNumber + ''' AND ServiceReport.ServiceDate BETWEEN ''' + CONVERT(VARCHAR, @StartDate) + ''' AND ''' + CONVERT(VARCHAR, @EndDate) + ''' ORDER BY ' + @SortBy;
	--PRINT @SQL_STRING;
	EXEC(@SQL_STRING);



GO

sp_ServiceReport_ServiceReportNumber_Search '4', '1/1/2008', '10/12/2010', 'RepairDate DESC' 