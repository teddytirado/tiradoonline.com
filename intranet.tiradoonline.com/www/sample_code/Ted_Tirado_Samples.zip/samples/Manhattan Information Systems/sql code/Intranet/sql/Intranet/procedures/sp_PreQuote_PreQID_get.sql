IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_PreQuote_PreQID_get' AND TYPE = 'P')
	DROP PROCEDURE sp_PreQuote_PreQID_get;
GO


CREATE PROCEDURE sp_PreQuote_PreQID_get
	@PreQID			INT
AS

	SELECT
		a.*,
		SalesPerson = b.FirstName + ' ' + b.LastName 

	FROM
		PreQuote a,
		Userz b
	WHERE
		a.SalesID = b.SalesID COLLATE SQL_Latin1_General_CP1_CI_AS AND
		a.PreQID = @PreQID;

GO

exec sp_PreQuote_PreQID_get 55