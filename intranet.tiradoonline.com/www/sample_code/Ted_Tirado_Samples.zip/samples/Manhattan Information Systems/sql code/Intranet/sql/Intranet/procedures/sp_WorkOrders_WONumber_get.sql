
	DROP PROCEDURE sp_WorkOrders_WONumber_get;
GO


CREATE PROCEDURE sp_WorkOrders_WONumber_get
	@WONumber		INT
AS
	
	SELECT
		CustomerName = (SELECT NAMECUST FROM MISINC..ARCUS WHERE IDCUST = WorkOrder.WOCustomer COLLATE SQL_Latin1_General_CP1_CI_AS),
		SalesID = SPNumber,
		SalesPerson = (SELECT FirstName + ' ' + LastName FROM Userz WHERE SalesID = WorkOrder.SPNumber COLLATE SQL_Latin1_General_CP1_CI_AS),
		PreparedBy = (SELECT FirstName + ' ' + LastName FROM Userz WHERE SalesID = WorkOrder.PreparedByID COLLATE SQL_Latin1_General_CP1_CI_AS),
		WorkOrderTotal = (SELECT (SUM(WOUPrice * WOQTY) + WOTax) + WODelivery FROM WODetail WHERE QID = WorkOrder.QID),
		WorkOrderDate = WoDate,
		WorkOrderID = WONumber,
		TaxRate = WOTaxRate,
		*
	FROM 
		WorkOrder
	WHERE 
		WONumber = @WONumber;

GO

EXEC sp_WorkOrders_WONumber_get 16007