IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Userz_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Userz_get;
GO


CREATE PROCEDURE sp_Userz_get
	@ViewTypeUsers 		TINYINT = 0
AS

	IF @ViewTypeUsers = 0
		BEGIN
			SELECT
				*,
				Division = (SELECT Division FROM Division WHERE DivisionID = Userz.DivisionID)
			FROM
				Userz
			ORDER BY 
				LastName;
		END
	ELSE IF @ViewTypeUsers = 1
		BEGIN
			SELECT
				*,
				Division = (SELECT Division FROM Division WHERE DivisionID = Userz.DivisionID)
			FROM
				Userz
			WHERE
				UserControl = 'yes'
			ORDER BY 
				LastName;
		END
	ELSE IF @ViewTypeUsers = 2
		BEGIN
			SELECT
				*,
				Division = (SELECT Division FROM Division WHERE DivisionID = Userz.DivisionID)
			FROM
				Userz
			WHERE
				UserControl = 'no'
			ORDER BY 
				LastName;
		END

GO

exec sp_Userz_get