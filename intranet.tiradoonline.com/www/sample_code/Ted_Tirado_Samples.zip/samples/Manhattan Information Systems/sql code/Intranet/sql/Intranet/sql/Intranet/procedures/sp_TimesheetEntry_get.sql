IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_TimesheetEntry_get' AND TYPE = 'P')
	DROP PROCEDURE sp_TimesheetEntry_get;
GO


CREATE PROCEDURE sp_TimesheetEntry_get
	@TimeSheetID		INT
AS
	
	SELECT 
		* 
	FROM 
		TimesheetEntry 
	WHERE 
		TimesheetID = @TimesheetID
	ORDER BY
		start_time;

GO

