select top 10 * from ServiceReport order by create_dt desc
SELECT top 3 * FROM Companies order by create_dt desc
select top 3 * from DateServicePerformed order by create_dt desc
select top 3 * from ServicedSerialNumbers order by create_dt desc
select top 3 * from PurchaseOrderServicePrice order by create_dt desc
select top 3 * from CreditMemo order by create_dt desc
