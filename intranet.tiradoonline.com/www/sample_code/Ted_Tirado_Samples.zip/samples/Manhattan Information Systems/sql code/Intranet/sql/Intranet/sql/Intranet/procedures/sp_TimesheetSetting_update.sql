IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_TimesheetSetting_update' AND TYPE = 'P')
	DROP PROCEDURE sp_TimesheetSetting_update;
GO


CREATE PROCEDURE sp_TimesheetSetting_update
	@TimesheetSettingID		INT,
	@Personal			INT,
	@Vacation			INT,
	@Sick				INT,
	@WorkFromHome			INT

	
AS

	UPDATE TimesheetSetting SET
		Personal = @Personal,
		Vacation = @Vacation,
		Sick = @Sick,
		WorkFromHome = @WorkFromHome
	WHERE
		TimesheetSettingID = @TimesheetSettingID

GO

