IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_TradeReference_get' AND TYPE = 'P')
	DROP PROCEDURE sp_TradeReference_get;
GO


CREATE PROCEDURE sp_TradeReference_get
	@BankReferenceID		INT
AS
		
	SELECT
		*
	FROM
		TradeReference
	WHERE 
		BankReferenceID = @BankReferenceID;

GO

EXEC sp_TradeReference_get 1001