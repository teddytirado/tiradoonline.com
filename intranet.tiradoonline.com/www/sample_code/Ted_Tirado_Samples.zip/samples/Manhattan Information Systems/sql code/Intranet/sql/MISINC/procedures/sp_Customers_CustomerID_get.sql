IF EXISTS (SELECT NAME FROM SYSOBJECTS WHERE NAME = 'sp_Customers_CustomerID_get' AND TYPE = 'P')
	DROP PROCEDURE sp_Customers_CustomerID_get;
GO


CREATE PROCEDURE sp_Customers_CustomerID_get
	@CustomerID		VARCHAR(20),
	@SalesID		VARCHAR(10),
	@Administrator		TINYINT	
AS

	SET @CustomerID = '%' + @CustomerID + '%';
	
	--PRINT @Administrator;

	IF @Administrator = 1
		BEGIN
			SELECT 
				CustomerID, 
				CustomerName,
				ContactName, 
				Address1, 
				Address2,
				City,
				State,
				ZipCode,
				Phone, 
				Fax,
				SalesPerson = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = vw_Customers.SalesID),
				Email,
				Website,
				InvoiceNumber = (SELECT TOP 1 InvoiceNumber FROM vw_InvoiceHeader WHERE CustomerID = vw_Customers.CustomerID ORDER BY InvoiceDate DESC),
				LastSale = (SELECT MAX(InvoiceDate) FROM vw_InvoiceHeader WHERE CustomerID = vw_Customers.CustomerID),
				SalesTotal = (SELECT TOP 1 TotalDue FROM vw_InvoiceHeader WHERE CustomerID = vw_Customers.CustomerID ORDER BY InvoiceDate DESC) 
			FROM 
				vw_Customers
			WHERE 
				UPPER(CustomerID) LIKE UPPER(@CustomerID)
			ORDER BY 
				CustomerID;
		END
	ELSE
		BEGIN
			SELECT 
				CustomerID, 
				CustomerName, 
				ContactName,
				Address1, 
				Address2,
				City,
				State,
				ZipCode,
				Phone, 
				Fax,
				SalesPerson = (SELECT FirstName + ' ' + LastName FROM Intranet..Userz WHERE SalesID = vw_Customers.SalesID),
				Email,
				Website,
				InvoiceNumber = (SELECT TOP 1 InvoiceNumber FROM vw_InvoiceHeader WHERE CustomerID = vw_Customers.CustomerID ORDER BY InvoiceDate DESC),
				LastSale = (SELECT MAX(InvoiceDate) FROM vw_InvoiceHeader WHERE CustomerID = vw_Customers.CustomerID),
				SalesTotal = (SELECT TOP 1 TotalDue FROM vw_InvoiceHeader WHERE CustomerID = vw_Customers.CustomerID ORDER BY InvoiceDate DESC) 
			FROM 
				vw_Customers
			WHERE 
				SalesID = @SalesID AND 
				UPPER(CustomerID) LIKE UPPER(@CustomerID)
			ORDER BY 
				CustomerID;
		END
GO

EXEC sp_Customers_CustomerID_get '05ACCE1000', '999', 1 
