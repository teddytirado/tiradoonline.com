IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_CustShipq_delete' AND TYPE = 'P')
	DROP PROCEDURE sp_CustShipq_delete;
GO


CREATE PROCEDURE sp_CustShipq_delete
	@QID		INT
AS

	DELETE FROM CustShipQ WHERE QID = @QID
GO

--exec sp_CustShipq_delete