IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_ServiceReport_Company_rename' AND TYPE = 'P')
	DROP PROCEDURE sp_ServiceReport_Company_rename;
GO


CREATE PROCEDURE sp_ServiceReport_Company_rename
	@Company 	NVARCHAR(50),
	@NewCompany 	NVARCHAR(50)
AS

	UPDATE ServiceReport
	SET
		Company = @NewCompany
	WHERE	
		Company = @Company;	

GO

