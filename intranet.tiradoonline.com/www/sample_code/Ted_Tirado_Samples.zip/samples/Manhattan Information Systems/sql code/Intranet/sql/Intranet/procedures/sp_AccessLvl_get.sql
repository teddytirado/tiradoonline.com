IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_AccessLvl_get' AND TYPE = 'P')
	DROP PROCEDURE sp_AccessLvl_get;
GO


CREATE PROCEDURE sp_AccessLvl_get
AS

	SELECT
		AccessLvl,
		AccessLvlName
	FROM
		AccessLvl;

GO

exec sp_AccessLvl_get