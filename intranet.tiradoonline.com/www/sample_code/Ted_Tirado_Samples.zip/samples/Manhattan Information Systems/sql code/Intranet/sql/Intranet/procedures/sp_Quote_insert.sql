IF EXISTS (SELECT NAME FROM sysobjects WHERE NAME = 'sp_Quote_insert' AND TYPE = 'P')
	DROP PROCEDURE sp_Quote_insert;
GO


CREATE PROCEDURE sp_Quote_insert
	@SalesID	VARCHAR(50),
	@PreQID		INT
AS

	BEGIN TRANSACTION TranQuote
	
	
	/*****************************
		QUOTE 
	******************************/
	INSERT INTO Quote
		(SPNumber, PreparedByID, Quote_Name, RefNum, Attn, Phone, QuoteDate, Terms, WOCustomer, ShippingMeth, WONote, WODelivery, WOTaxRate, WOTax, WOtaxable, Conv)
	SELECT
		SalesID, PreparedByID, PreQuote_Name, RefNum, Attn, Phone, GETDATE(), Terms, WOCustomer, ShippingMeth, WONote, WODelivery, WOTaxRate, WOTax, WOtaxable, Conv
	FROM 
		PreQuote
	WHERE
		PreQID = @PreQID;

	DECLARE @QuoteID	INT;
	SET @QuoteID = @@IDENTITY;
	
	/*****************************
		QUOTEDETAIL
	******************************/
	INSERT INTO QuoteDetail
		(QID, LineNum, WOCost, Markup, WOItemNum, WOQTY, WODesc, WOUPrice, VendorID, CTID, WOVenNum, Conv)
	SELECT
		@QuoteID, LineNum, WOCost, Markup, WOItemNum, WOQTY, WODesc, WOUPrice, VendorID, CTID, WOVenNum, Conv
	FROM 
		PreQuoteDetail
	WHERE
		PreQID = @PreQID;
	
	/*****************************
		CUSTSHIPQ
	******************************/
	INSERT INTO CustShipQ
		(QID, CustomerNum, CustName, CustAdd1, CustAdd2, CustAdd3, CustAdd4, CustState, CustCity, CustZip, CustBName, CustBAdd1, CustBAdd2, CustBAdd3, CustBAdd4, CustBCity, CustBState, CustBZip)
	SELECT
		@QuoteID, CustomerNum, CustName, CustAdd1, CustAdd2, CustAdd3, CustAdd4, CustState, CustCity, CustZip, CustBName, CustBAdd1, CustBAdd2, CustBAdd3, CustBAdd4, CustBCity, CustBState, CustBZip
	FROM 
		PreCustShipQ
	WHERE
		PreQID = @PreQID;

	
	/*****************************
		QUOTETEMPLATES
	******************************/
	IF EXISTS (SELECT * FROM PreQuoteTemplates WHERE PreQID = @PreQID)
		BEGIN
			INSERT INTO QuoteTemplates
				(SalesID, QID, QuoteTemplateName)
			SELECT
				SalesID, @QuoteID, PreQuoteTemplateName
			FROM
				PreQuoteTemplates
			WHERE
				PreQID = @PreQID;
		END

	/*****************************
		QUOTENUMS
	******************************/
	UPDATE QuoteNums SET 
		RefNum = CONVERT(INT, RefNum) + 1
	WHERE
		SPNumber = @SalesID;


	DELETE FROM PreQuote WHERE PreQID = @PreQID;
	DELETE FROM PreQuoteDetail WHERE PreQID = @PreQID;
	DELETE FROM PreCustShipQ WHERE PreQID = @PreQID;
	DELETE FROM PreQuoteTemplates WHERE PreQID = @PreQID;

	IF @@ERROR <> 0
		ROLLBACK TRAN TranQuote;
	ELSE
		COMMIT TRAN TranQuote;

	SELECT QID = @QuoteID;	
		
GO

--exec sp_Quote_insert '999', 7
