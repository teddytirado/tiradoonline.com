<script language="JavaScript">
<!--
	function SetDateTime()
	{
		todays_date = new Date();
		//alert(todays_date);
		//alert(todays_date.getDay());
		switch(todays_date.getDay())
		{
			case 0:
				WeekDayName = "Sunday";
				break;
			case 1:
				WeekDayName = "Monday";
				break;
			case 2:
				WeekDayName = "Tuesday";
				break;
			case 3:
				WeekDayName = "Wednesday";
				break;
			case 4:
				WeekDayName = "Thursday";
				break;
			case 5:
				WeekDayName = "Friday";
				break;
			case 6:
				WeekDayName = "Saturday";
				break;
		}
		switch(todays_date.getMonth())
		{
			case 0:
				MonthName = "January";
				break;
			case 1:
				MonthName = "February";
				break;
			case 2:
				MonthName = "March";
				break;
			case 3:
				MonthName = "April";
				break;
			case 4:
				MonthName = "May";
				break;
			case 5:
				MonthName = "June";
				break;
			case 6:
				MonthName = "July";
				break;
			case 7:
				MonthName = "August";
				break;
			case 8:
				MonthName = "September";
				break;
			case 9:
				MonthName = "October";
				break;
			case 10:
				MonthName = "November";
				break;
			case 11:
				MonthName = "December";
				break;
		}
		
		Day = todays_date.getDate() + ",";
		Year = todays_date.getYear();
		Year = 1900 + Year;
		Hours = todays_date.getHours();
		AMPM = "AM"		
		if(Hours > 12)
		{
			Hours = Hours - 12;
			AMPM = "PM";
		}
		else if(Hours == 0)
		{
			Hours = 12;
		}
		Minutes = todays_date.getMinutes();
		if(Minutes < 10) Minutes = "0" + Minutes 
		Seconds = todays_date.getSeconds();
		if(Seconds < 10) Seconds = "0" + Seconds
				
		TodaysDate.innerHTML = WeekDayName + " " + MonthName + " " + Day + " " + Year + " " + Hours + ":" + Minutes + ":" + Seconds + " " + AMPM
		setTimeout("SetDateTime()", 1000);
	}
//-->
</script>
