USE EDGE;
GO

SET NOCOUNT ON;

IF EXISTS (SELECT NAME FROM SYSOBJECTS WHERE NAME = 'sp_import_customer' AND type='P')
	DROP PROCEDURE sp_import_customer;
GO


CREATE PROCEDURE sp_import_customer
	@deleteTables		BIT = NULL

AS

	DECLARE @StartTime		DATETIME;
	SET @StartTime = GETDATE();

	DECLARE @EndTime		DATETIME;
	

	/* CHECK IF TABLEAUTONUMBER EXISTS, IF NOT CREATE IT AND POPULATE DATA */
	IF NOT EXISTS (SELECT NAME FROM SYSOBJECTS WHERE NAME = 'TableAutoNumber' AND type='U')
		BEGIN
			CREATE TABLE TableAutoNumber
			(
				[TableName] [varchar](50) NOT NULL,
				[CounterNumber] [varchar](50) NOT NULL,
				CONSTRAINT [PK_AutoNumber] PRIMARY KEY CLUSTERED 
				(
					[TableName] ASC
				)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
			) ON [PRIMARY]

			INSERT INTO TableAutoNumber VALUES ('Customer', '1');
			INSERT INTO TableAutoNumber VALUES ('Contact', '1');

		END

	/* CHECK IF TABLEAUTONUMBER EXISTS, IF NOT CREATE IT AND POPULATE DATA */
	IF NOT EXISTS (SELECT NAME FROM SYSOBJECTS WHERE NAME = 'LogImports' AND type='U')
		BEGIN
			CREATE TABLE LogImports
			(
				LogImportTypeID	INT IDENTITY(1001, 1) NOT NULL,
				[LogImportType] [varchar](50) NOT NULL,
				[StartTime]		DATETIME NOT NULL,
				[EndTime]		DATETIME NOT NULL,
				CONSTRAINT [PK_LogImports] PRIMARY KEY CLUSTERED 
				(
					[LogImportTypeID] ASC
				)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
			) ON [PRIMARY]


		END


	IF @deleteTables = 1
		BEGIN

			/* RESET TABLEAUTONUMBER TO 1 */
			UPDATE TableAutoNumber SET CounterNumber = '1';

			IF EXISTS (SELECT NAME FROM SYSOBJECTS WHERE NAME = 'Customer' AND type='U')
				BEGIN
					--DROP TABLE Customer;

					--SELECT TOP 1 * INTO Customer FROM Customer;

					DELETE FROM Customer;
					PRINT 'Customer deleted.. ' + CONVERT(VARCHAR, GETDATE());
				END
			
			IF EXISTS (SELECT NAME FROM SYSOBJECTS WHERE NAME = 'Address' AND type='U')
				BEGIN
					--DROP TABLE Address;

					--SELECT TOP 1 * INTO Address FROM Address;

					DELETE FROM Address;
					PRINT 'Address deleted.. ' + CONVERT(VARCHAR, GETDATE());
				END

			IF EXISTS (SELECT NAME FROM SYSOBJECTS WHERE NAME = 'Contact' AND type='U')
				BEGIN
					--DROP TABLE Contact;

					--SELECT TOP 1 * INTO Contact FROM Contact;

					DELETE FROM Contact;
					PRINT 'Contact deleted.. ' + CONVERT(VARCHAR, GETDATE());
				END


			IF EXISTS (SELECT NAME FROM SYSOBJECTS WHERE NAME = 'Contact_Customer' AND type='U')
				BEGIN
					--DROP TABLE Contact_Customer;

					--SELECT TOP 1 * INTO Contact_Customer FROM Contact_Customer;

					DELETE FROM Contact_Customer;
					PRINT 'Contact_Customer deleted.. ' + CONVERT(VARCHAR, GETDATE());
				END
		END

	BEGIN TRANSACTION

		DECLARE @UserID							VARCHAR(50);
		SET @UserID = '2bf323f1259b0c2f67e4302556bd72';

		DECLARE @AddressType					VARCHAR(50)
		SET @AddressType = 'Main ';

		DECLARE @CountryCode					VARCHAR(2)
		SET @CountryCode = 'US';

		DECLARE @OfficeID						UNIQUEIDENTIFIER;
		SET @OfficeID = 'BE726CC6-7FA1-4519-85FB-DE1B4E5BF8B6';

		DECLARE @PickupMethodTypeCodeID			UNIQUEIDENTIFIER;
		SET @PickupMethodTypeCodeID = '21D325A6-C743-4D7A-8DED-E2045659EFC9';

		DECLARE @PaymentTermID					UNIQUEIDENTIFIER;
		SET @PaymentTermID = 'BE726CC6-7FA1-4519-85FB-DE1B4E5BF8B6';

		DECLARE @AddressID						UNIQUEIDENTIFIER;

		SELECT 
			--TOP 1
			NEWID() AS ID,
			GETDATE() AS CreateDate,
			--CreateUserID = CONVERT(UNIQUEIDENTIFIER, @UserID),
			'' AS CreateSessionID,
			GETDATE() AS UpdateDate,
			@UserID AS UpdateUserID,
			'' AS UpdateSessionID,
			@OfficeID AS OfficeID,

			egl.fname AS FirstName,
			egl.mi AS MiddleName,
			egl.lname AS LastName,
			egl.Address AS Address1,
			egl.City AS City,
			egl.State AS StateCode,
			egl.Zip AS PostCode,
			egl.Lname AS CustomerName,
			CustomerTypeCodeID = (SELECT ID FROM Typecode WHERE CodeType = 'CustomerType' AND InternalDescription = CONVERT(VARCHAR, egl.customer_category)),
			egl.ExtendedName AS CustomerAlias,
			egl.ExtendedName AS ExtendedName,
			NEWID() AS AccountNumber,
			NULL AS RatingTypeCodeID,
			NULL AS RatingNote,
			0 AS BalanceNTE,
			0 AS CurrentBalance,
			NULL AS BillingGracePeriodID,
			NULL AS InventoryStorePeriodID,
			0 AS InventoryItems,
			0 AS InventoryItemPickupAvailable,
			0 AS TotalItemsSubmitted,
			0 AS TotalCertsOrdered,
			NULL AS TaxID,
			NULL AS URL,
			egl.Phone AS Phone1,
			egl.HomePhone AS Phone2,
			NULL AS Phone3,
			NULL AS Phone1Ext,
			NULL AS Phone2Ext,
			NULL AS Phone3Ext,
			egl.Fax AS Fax1,
			NULL AS Fax2,
			egl.email AS Email,
			DefaultCustomerRepID = (SELECT CONVERT(UNIQUEIDENTIFIER, AccountRepID) FROM AccountRepTemp WHERE accountrep = egl.accountrep),
			NULL AS BlockGradingInfo,
			@PickupMethodTypeCodeID AS PickupMethodTypeCodeID,
			egl.notes AS Notes,
			NULL AS SecurityAlerts,
			NULL AS DefaultAddressID,
			egl.Active AS IsActive,
			egl.is_locked AS IsLocked,
			NULL AS PrimaryContactID,
			@PaymentTermID AS PaymentTermID,
			egl.sendEmail AS ShouldEmailShortReportExport,
			NULL AS UserName,
			NULL AS Password,
			egl.Organization AS Organization,
			egl.mailbox AS OldMailbox,
			egl.ExtendedName AS OldExtendedName,
			egl.customer_category AS OldCustomerCategory,
			egl.id AS OldID
		INTO
			#Customer
		FROM
			EGL128.EGL.DBO.customer egl
		WHERE
			--egl.mailbox = 12283;
			egl.mailbox 
				NOT IN 
			(SELECT OldMailBox FROM EDGE..Customer);
		
		/* DECLARE CUSTOMER FIELDS */
		DECLARE @CustomerID						UNIQUEIDENTIFIER;
		DECLARE @AccountNumber					VARCHAR(6);
		DECLARE @FirstName						VARCHAR(30);
		DECLARE @MiddleName						VARCHAR(1);
		DECLARE @LastName						VARCHAR(30);
		DECLARE @Address1						VARCHAR(40);
		DECLARE @City							VARCHAR(40);
		DECLARE @StateCode						VARCHAR(2);
		DECLARE @PostCode						VARCHAR(50);
		
		DECLARE @CustomerName					VARCHAR(50);
		DECLARE @CustomerAlias					VARCHAR(50);
		DECLARE @CustomerTypeCodeID				UNIQUEIDENTIFIER;
		DECLARE @Organization					VARCHAR(50);
		DECLARE @ExtendedName					VARCHAR(50);
		DECLARE @BalanceNTE						MONEY;
		DECLARE @CurrentBalance					MONEY;
		DECLARE @InventoryItems					INT;
		DECLARE @InventoryItemPickupAvailable	INT;
		DECLARE @TotalItemsSubmitted			INT;
		DECLARE @TotalCertsOrdered				INT;
		DECLARE @Phone1							VARCHAR(50);
		DECLARE @Phone2							VARCHAR(50);
		DECLARE @Phone3							VARCHAR(50);
		DECLARE @Fax							VARCHAR(50);
		DECLARE @Email							VARCHAR(50);
		DECLARE @DefaultCustomerRepID			UNIQUEIDENTIFIER;
		DECLARE @Notes							VARCHAR(MAX);
		DECLARE	@IsActive						BIT;
		DECLARE @IsLocked						BIT;

		DECLARE @OldCustomerCategory			INT;
		DECLARE @OldMailBox						INT;
		DECLARE @OldID							INT;

		DECLARE @ContactID						UNIQUEIDENTIFIER;
		DECLARE @ContactNumber					VARCHAR(7);

		DECLARE @ContactCustomerID				UNIQUEIDENTIFIER;
		DECLARE @TodaysDate						DATETIME;
		
		SET @TodaysDate = GETDATE();
			
		DECLARE cursorNewCustomers CURSOR FOR 
			SELECT 
				AccountNumber, 
				FirstName,
				MiddleName,
				LastName,
				Address1,
				City,
				StateCode,
				PostCode,
				CustomerName, 
				CustomerAlias,
				CustomerTypeCodeID,
				Organization,
				ExtendedName,
				BalanceNTE,
				CurrentBalance,
				InventoryItems,
				InventoryItemPickupAvailable,
				TotalItemsSubmitted,
				TotalCertsOrdered,
				Phone1,
				Phone2,
				Phone3,
				Fax1,
				Email,
				DefaultCustomerRepID,
				PickupMethodTypeCodeID,
				Notes,
				IsActive,
				IsLocked,
				OldCustomerCategory,
				OldMailBox,
				OldID
			FROM #Customer

		OPEN cursorNewCustomers
		FETCH NEXT FROM cursorNewCustomers INTO 
			@CustomerID,
			@FirstName,
			@MiddleName,
			@LastName,
			@Address1,
			@City,
			@StateCode,
			@PostCode,
			@CustomerName,
			@CustomerAlias,
			@CustomerTypeCodeID,
			@Organization,
			@ExtendedName,
			@BalanceNTE,
			@CurrentBalance,
			@InventoryItems,
			@InventoryItemPickupAvailable,
			@TotalItemsSubmitted,
			@TotalCertsOrdered,
			@Phone1,
			@Phone2,
			@Phone3,
			@Fax,
			@Email,
			@DefaultCustomerRepID,
			@PickupMethodTypeCodeID,
			@Notes,
			@IsActive,
			@IsLocked,
			@OldCustomerCategory,
			@OldMailBox,
			@OldID
		
		PRINT 'Inserting Customers.. ' + CONVERT(VARCHAR, GETDATE());
		WHILE @@FETCH_STATUS = 0			
			BEGIN
				/***********************/
				/* INSERT NEW CUSTOMERS */
				/***********************/

					
				SET @AddressID = NEWID();
				SET @ContactID = NEWID();
				SET @ContactCustomerID = NEWID();


				/**** GET ACCOUNTNUMBER ******/
				SELECT @AccountNumber = CONVERT(VARCHAR(6), CounterNumber) FROM TableAutoNumber WHERE TableName = 'Customer';
				SET @AccountNumber = REPLICATE('0', 6 - LEN(@AccountNumber)) + @AccountNumber;
				UPDATE TableAutoNumber SET CounterNumber = REPLICATE(7 - LEN(@AccountNumber), '0') + CONVERT(VARCHAR(50), (ISNULL(CounterNumber, 0) + 1)) WHERE TableName = 'Customer'

				INSERT INTO Customer
				(
					ID,
					CreateDate, 
					UpdateDate, 
					OfficeID,
					CustomerName,
					CustomerAlias,
					CustomerTypeCodeID,
					Organization,
					OldExtendedName,
					AccountNumber,
					BalanceNTE,
					CurrentBalance,
					InventoryItems,
					InventoryItemPickupAvailable,
					TotalItemsSubmitted,
					TotalCertsOrdered,
					Phone1,
					Phone2,
					Phone3,
					Fax1,
					Email,
					PrimaryContactID,
					DefaultCustomerRepID,
					PickupMethodTypeCodeID,
					Notes,
					ShouldEmailShortReportExport,
					DefaultAddressID,
					IsActive,
					IsLocked,
					OldCustomerCategory,
					OldMailBox,
					OldID
				)
				VALUES
				(
					@CustomerID,
					@TodaysDate, 
					@TodaysDate, 
					@OfficeID, 
					@CustomerName,
					@CustomerAlias,
					@CustomerTypeCodeID,
					@Organization,
					@ExtendedName,
					@AccountNumber,
					@BalanceNTE,
					@CurrentBalance,
					@InventoryItems,
					@InventoryItemPickupAvailable,
					@TotalItemsSubmitted,
					@TotalCertsOrdered,
					@Phone1,
					@Phone2,
					@Phone3,
					@Fax,
					@Email,
					@ContactID,
					@DefaultCustomerRepID,
					@PickupMethodTypeCodeID,
					@Notes,
					1,
					@AddressID,
					@IsActive,
					CONVERT(BIT, @IsLocked),
					@OldCustomerCategory,
					@OldMailBox,
					@OldID
				)


				/***********************/
				/* INSERT NEW CONTACTS */
				/***********************/

				/**** GET CONTACTNUMBER ******/
				SELECT @ContactNumber = CONVERT(VARCHAR(7), CounterNumber) FROM TableAutoNumber WHERE TableName = 'Contact';
				SET @ContactNumber = REPLICATE('0', 7 - LEN(@ContactNumber)) + @ContactNumber;
				UPDATE TableAutoNumber SET CounterNumber = REPLICATE(7 - LEN(@AccountNumber), '0') + CONVERT(VARCHAR(50), (ISNULL(CounterNumber, 0) + 1)) WHERE TableName = 'Contact'

				INSERT INTO Contact
					--(ID, CreateDate, CreateUserID, UpdateDate, UpdateUserID, FirstName, LastName, Phone1, Phone2, Phone3, OldMailBox, OldID)
					(ID, CreateDate, UpdateDate, ContactNumber, FirstName, LastName, Phone1, Phone2, Phone3, Fax1, Email, DefaultAddressID, Notes, IsActive, IsLocked, OldMailBox, OldID)
				VALUES
					--(@ContactID, GETDATE(), @UserID, GETDATE(), @UserID, @FirstName, @LastName, @Phone1, @Phone2, @Phone3, OldMailBox, OldID);
					(@ContactID, @TodaysDate, @TodaysDate, @ContactNumber, @FirstName, @LastName, @Phone1, @Phone2, @Phone3, @Fax, @Email, @AddressID, @Notes, @IsActive, @IsLocked, @OldMailBox, @OldID);

				/***********************/
				/* INSERT NEW ADDRESSES */
				/***********************/
				INSERT INTO Address
					--(ID, CreateDate, CreateUserID, UpdateDate, UpdateUserID, AddressType, Address1, City, StateCode, PostCode, CountryCode, OldMailBox, OldID, ParentID)
					(ID, CreateDate, UpdateDate, AddressType, Address1, City, StateCode, PostCode, CountryCode, OldMailBox, OldID, ParentID)
				VALUES
					--(@AddressID, GETDATE(), @UserID, GETDATE(), @UserID, (@AddressType + @Address1), @Address1, @City, @StateCode, @PostCode, @CountryCode, @OldMailBox, @OldID, @CustomerID);
					--(@AddressID, (@AddressType + @Address1), @Address1, @City, @StateCode, @PostCode, @CountryCode, @OldMailBox, @OldID, @CustomerID);
					(@AddressID, @TodaysDate, @TodaysDate, @AddressType, @Address1, @City, @StateCode, @PostCode, @CountryCode, @OldMailBox, @OldID, @CustomerID);
					
				/***********************/
				/* INSERT NEW CONTACT_CUSTOMERS */
				/***********************/
				INSERT INTO Contact_Customer
					--(ID, CreateDate, CreateUserID, UpdateDate, UpdateUserID, ContactID, CustomerID)
					(ID, CreateDate, UpdateDate, ContactID, CustomerID)
				VALUES
					--(@ContactCustomerID, GETDATE(), @UserID, GETDATE(), @UserID, @ContactID, @CustomerID);
					(@ContactCustomerID, @TodaysDate, @TodaysDate, @ContactID, @CustomerID);

				FETCH NEXT FROM cursorNewCustomers INTO 
					@CustomerID,
					@FirstName,
					@MiddleName,
					@LastName,
					@Address1,
					@City,
					@StateCode,
					@PostCode,
					@CustomerName,
					@CustomerAlias,
					@CustomerTypeCodeID,
					@Organization,
					@ExtendedName,
					@BalanceNTE,
					@CurrentBalance,
					@InventoryItems,
					@InventoryItemPickupAvailable,
					@TotalItemsSubmitted,
					@TotalCertsOrdered,
					@Phone1,
					@Phone2,
					@Phone3,
					@Fax,
					@Email,
					@DefaultCustomerRepID,
					@PickupMethodTypeCodeID,
					@Notes,
					@IsActive,
					@IsLocked,
					@OldCustomerCategory,
					@OldMailBox,
					@OldID
			END

			CLOSE cursorNewCustomers
			DEALLOCATE cursorNewCustomers

			SET @EndTime = GETDATE();

			/* LOG Customer LogImport */
			INSERT INTO LogImports VALUES ('Customers', @StartTime, @EndTime);

		IF @@ERROR = 0
			COMMIT TRANSACTION
		ELSE
			ROLLBACK TRANSACTION

	
GO
 
EXEC sp_import_customer 1;
GO

SELECT TOP 1 TableName = 'EGL..Customer', TotalRows = (SELECT COUNT(*) FROM EGL128.EGL.DBO.customer), * FROM EGL128.EGL.DBO.customer;
	SELECT TOP 1 TableName = 'EDGE..Customer', TotalRows = (SELECT COUNT(*) FROM customer), CustomerTypeCodeID, * FROM customer;
	SELECT TOP 1 TableName = 'EDGE..Contact_Customer', TotalRows = (SELECT COUNT(*) FROM Contact_Customer), * FROM Contact_Customer;
	SELECT TOP 1 TableName = 'EDGE..Contact', TotalRows = (SELECT COUNT(*) FROM Contact), * FROM Contact;
	SELECT TOP 1 TableName = 'EDGE..Address', TotalRows = (SELECT COUNT(*) FROM Address), * FROM Address;

SELECT TableName = 'EDGE..TableAutoNumber', * FROM TableAutoNumber;

SELECT TableName = 'EDGE..LogImports', *, 
		--TotalTime = CONVERT(VARCHAR, (Select Datediff(second, StartTime, EndTime))) + ' SECONDS',
		CONVERT(VARCHAR,(Datediff(second, StartTime, EndTime))/3600%60) + ':' + RIGHT(CONVERT(VARCHAR,(Datediff(second, StartTime, EndTime))/60%60+100),2) + ':' + RIGHT(CONVERT(VARCHAR,(Datediff(second, StartTime, EndTime))%60+100),2)
 FROM LogImports ORDER BY EndTime DESC;
