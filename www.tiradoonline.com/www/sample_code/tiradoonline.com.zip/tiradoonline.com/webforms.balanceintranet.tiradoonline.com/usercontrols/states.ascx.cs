﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;

namespace webforms.balanceintranet.tiradoonline.com.usercontrols
{
    public partial class states : System.Web.UI.UserControl
    {
        private string _className;
        public string className
        {
            get { return _className; }
            set { _className = value; }
        }

        private int _stateid;
        public int StateID
        {
            get { return _stateid; }
            set { _stateid = value; }
        }

        private string _statename;
        public string StateName
        {
            get { return _statename; }
            set { _statename = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            StringBuilder sbStates = new StringBuilder();
            DBDataContext db = new DBDataContext();

            int stateid = StateID;
            if (stateid == null)
                stateid = 0;

            string statename = StateName;
            if (statename == null)
                statename = string.Empty;

            var states = db.sp_States_get();

            sbStates.AppendLine("<select id='" + this.ID + "' name='" + this.ID + "' class='" + className + "'>");
            foreach (var p in states)
            {

                if (Convert.ToInt32(p.StateID) == Convert.ToInt32(stateid) || p.State.ToString() == statename.ToString())
                    sbStates.AppendLine("<option value='" + p.StateID + "' SELECTED>" + p.State + "</option>");
                else
                    sbStates.AppendLine("<option value='" + p.StateID + "'>" + p.State + "</option>");
            }
            sbStates.AppendLine("</select>");

            Response.Write(sbStates.ToString());

        }
    }
}