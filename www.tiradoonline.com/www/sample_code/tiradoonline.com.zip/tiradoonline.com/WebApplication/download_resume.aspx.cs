using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;


namespace WebApplicationNameSpace
{
    public partial class _download_resume : System.Web.UI.Page
    {
        //protected tiradoonline.UserControls.ReferencedByControl uc_ReferencedByControl;

        protected System.Web.UI.WebControls.Label label_ErrorMessage;
        protected WebApplicationNameSpace.UserControls.PageHeader uc_PageHeader;
        protected System.Web.UI.WebControls.Panel panel_Login;
        protected System.Web.UI.WebControls.TextBox txt_FullName;
        protected System.Web.UI.WebControls.TextBox txt_Company;
        protected System.Web.UI.WebControls.TextBox txt_Phone;
        protected System.Web.UI.WebControls.TextBox txt_Email;
        protected System.Web.UI.WebControls.TextBox txt_Comments;
        protected System.Web.UI.WebControls.TextBox txt_Website;
        protected System.Web.UI.WebControls.PlaceHolder PlaceHolder1;
        protected System.Web.UI.WebControls.PlaceHolder PlaceHolder2;
        protected System.Web.UI.WebControls.DropDownList DropDownListReferencedBy;
        protected System.Web.UI.WebControls.DropDownList dropdownlist_ResumeTypeID;
        protected System.Web.UI.WebControls.Button Button_DownloadResume;
        protected System.Web.UI.WebControls.Label label_CoverLetter;
        protected System.Web.UI.WebControls.Label label_Email;
        protected System.Web.UI.WebControls.Panel panel_ThankYou;

        protected void Page_Load(object sender, EventArgs e)
        {
            SessionStart();

            if (!IsPostBack)
            {
                // CHANGE PAGE HEADER
                uc_PageHeader.PageHeaderText = "Download Resume";
                Bind_DropDownList_ReferencedBy();
                Bind_DropDownList_ResumeType();
            }
            //label_ErrorMessage.Visible = false;
            label_ErrorMessage.Text = string.Empty;
        }
        //Sessions objSession = new Sessions();
        //DataTable objSessionDataTable = objSession.GetRows();
        //objSession = null;


        private void Bind_DropDownList_ReferencedBy()
        {
            ReferencedBy objReferencedBy = new ReferencedBy();
            DataTable objReferencedByDataTable = objReferencedBy.GetRows();
            if (objReferencedByDataTable.Rows.Count > 0)
            {
                DropDownListReferencedBy.DataTextField = "ReferencedByName";
                DropDownListReferencedBy.DataValueField = "ReferencedByID";
                DropDownListReferencedBy.DataSource = objReferencedByDataTable;

                DropDownListReferencedBy.DataBind();
            }
            else
            {
                ListItem objListItem = new ListItem();
                objListItem.Text = "No records";
                objListItem.Value = "0";
                DropDownListReferencedBy.Items.Add(objListItem);
            }

            // SET DEFAULT TO CRAIGSLIST (CHANGE IN WEB CONFIG)
            DropDownListReferencedBy.SelectedValue = ConfigurationManager.AppSettings["defaultReferencedByID"].ToString();
        }

        protected void SessionStart()
        {
            string ip = Request.ServerVariables["REMOTE_ADDR"].ToString();

            Session["UserID"] = string.Empty;
            Session["PreviousPage"] = string.Empty;
            string stringReferer;
            try
            {

                if (Request.ServerVariables["HTTP_REFERER"].ToString() != "")
                    stringReferer = Request.ServerVariables["HTTP_REFERER"].ToString();
                else
                    stringReferer = "Email";
            }
            catch
            {
                stringReferer = "Email";
            }

            Session["PreviousPage"] = stringReferer;

            // LOG HIT IF FIRST TIME USER
            //Sessions objHit = new Sessions();
            //objHit.SessionID = Session.SessionID.ToString();
            //objHit.IPAddress = Request.ServerVariables["REMOTE_ADDR"].ToString();
            //objHit.Browser = Request.ServerVariables["HTTP_USER_AGENT"].ToString();
            //objHit.Referer = stringReferer;
            //objHit.Insert();
            //objHit = null;


        }

        private void Bind_DropDownList_ResumeType()
        {

            ResumeType objResumeType = new ResumeType();

            DataTable objResumeTypeDataTable = objResumeType.GetRows();
            dropdownlist_ResumeTypeID.DataSource = objResumeTypeDataTable;

            dropdownlist_ResumeTypeID.DataTextField = "ResumeTypeName";
            dropdownlist_ResumeTypeID.DataValueField = "ResumeTypeID";

            dropdownlist_ResumeTypeID.DataBind();
        }

        private string GetDocumentFile(string resume_type)
        {
            string documentfile = string.Empty;

            Settings objSettings = new Settings();
            objSettings.GetRows_UserID(ConfigurationManager.AppSettings["defaultUserID"].ToString());
            try
            {
                if (resume_type.Contains("Word"))
                {
                    documentfile = objSettings.ResumeDOC.ToString();
                }
                else
                {
                    documentfile = objSettings.ResumePDF.ToString();
                }
            }
            catch (SqlException objSqlException)
            {
                string errorstring = objSqlException.Errors[0].ToString();

            }
            return documentfile;
        }

        protected void Button_DownloadResume_Click(object sender, EventArgs e)
        {
            // INITIALIZED FORM VARIABLES
            string FullName = txt_FullName.Text;
            string Company = txt_Company.Text;
            string Email = txt_Email.Text;
            string Phone = txt_Phone.Text;
            string Comments = txt_Comments.Text;
            string Website = txt_Website.Text;
            int ReferencedByID = int.Parse(DropDownListReferencedBy.SelectedValue.ToString());
            int ResumeTypeID = int.Parse(dropdownlist_ResumeTypeID.SelectedValue.ToString());

            // get filename was uploaded.
            string DocumentFile = GetDocumentFile(dropdownlist_ResumeTypeID.SelectedItem.Text);

            string REFERER = Session["PreviousPage"].ToString();
            string SessionID = Session.SessionID.ToString();

            // CLEAR ERROR MESSAGE 
            label_ErrorMessage.Text = string.Empty;

            /*****************
                ERROR CHECK FORM
                FULLNAME, COMPANY & EMAIL ARE REQUIRED
            **************/

            if (FullName == string.Empty)
                label_ErrorMessage.Text += "<li>Invalid Name";
            if (Company == string.Empty)
                label_ErrorMessage.Text += "<li>Invalid Company";
            if (Email == string.Empty)
                label_ErrorMessage.Text += "<li>Invalid Email Address";
            if (!TextValidator.isEmailAddress(Email))
                label_ErrorMessage.Text += "<li>Invalid Email Format";


            // IF THERE ARE NO ERRRORS THEN INSERT INTO DATABASE
            if (label_ErrorMessage.Text == string.Empty)
            {
                //INITIALIZE SETTINGS.
                Settings objSettings = new Settings();
                string defaultUserID = ConfigurationManager.AppSettings["defaultUserID"].ToString();
                string EmailFromName = objSettings.EmailFromName;
                string EmailFromAddress = objSettings.EmailFromAddress;
                objSettings.GetRows_UserID(defaultUserID);

                ResumeDownload objResumeDownload = new ResumeDownload();
                objResumeDownload.UserID = ConfigurationManager.AppSettings["defaultUserID"].ToString();
                objResumeDownload.FullName = FullName;
                objResumeDownload.Company = Company;
                objResumeDownload.Email = Email;
                objResumeDownload.Phone = Phone;
                objResumeDownload.Comments = Comments;
                objResumeDownload.Website = Website;
                objResumeDownload.ReferencedByID = ReferencedByID;
                objResumeDownload.ResumeTypeID = ResumeTypeID;
                objResumeDownload.Referer = REFERER;
                objResumeDownload.SessionID = SessionID;
                objResumeDownload.Insert();
                objResumeDownload = null;

                // GET TYPE OF RESUME EXTENSION
                ResumeType objResumeType = new ResumeType();
                objResumeType.ResumeTypeID = ResumeTypeID;
                objResumeType.GetRows_ResumeTypeID();
                string stringFileExtension = objResumeType.ResumeTypeExt;
                objResumeType = null;

                SMTP objSMTP = new SMTP();
                StringBuilder stringBody = new StringBuilder();
                string toSubject = Company + " has downloaded your resume.";
                stringBody.Append("Someone has downloaded your resume\n\n");
                stringBody.Append("Date - Time:\n------------------\n" + DateTime.Now.ToString() + "\n\n");
                stringBody.Append("FullName:\n------------------\n" + FullName + "\n\n");
                stringBody.Append("Company:\n------------------\n" + Company + "\n\n");
                stringBody.Append("Email:\n------------------\n" + Email + "\n\n");
                stringBody.Append("Phone:\n------------------\n" + Phone + "\n\n");
                stringBody.Append("Comments:\n------------------\n" + Comments + "\n\n");
                stringBody.Append("Website:\n------------------\n" + Website + "\n\n");
                stringBody.Append("Reference:\n------------------\n" + DropDownListReferencedBy.SelectedItem.Text.ToString() + "\n\n");
                stringBody.Append("Resume:\n------------------\n" + dropdownlist_ResumeTypeID.SelectedItem.Text.ToString() + "\n\n");
                stringBody.Append("Referer:\n------------------\n" + REFERER + "\n\n");
                string string_BodyText = stringBody.ToString();
                string stringAttachment = Request.MapPath("/").ToString() + ConfigurationManager.AppSettings["ResumeDirectory"].ToString() + "\\" + DocumentFile;
                objSMTP.Attachments.Add((string)stringAttachment);
                objSMTP.SendEmail(ConfigurationManager.AppSettings["AdministratorName"].ToString(),
                                  ConfigurationManager.AppSettings["AdministratorEmail"].ToString(),
                                  ConfigurationManager.AppSettings["AdministratorName"].ToString(),
                                ConfigurationManager.AppSettings["AdministratorEmail"].ToString(), toSubject, string_BodyText); 

                Templates objTemplates = new Templates();
                objSMTP.ToName = FullName;
                objSMTP.ToEmail = Email;
                objSMTP.FromEmail = "teddy@tiradoonline.com";
                objSMTP.Subject = "Teddy Tirado - Thank you for downloading my resume";
                objSMTP.BodyText = objTemplates.EmailThankYou.ToString();
                objSMTP.Host = ConfigurationManager.AppSettings["AdministratorHost"].ToString();
                objSMTP.ToName = FullName;
                objSMTP.ToEmail = Email;
                objSMTP.FromEmail = "teddy@tiradoonline.com";
                toSubject = "tiradoonline.com - " + Company + " has downloaded your resume";
                objSMTP.UserID = ConfigurationManager.AppSettings["AdministratorEmail"].ToString();
                objSMTP.Attachments.Add((string)stringAttachment);
                objSMTP.SendEmail(FullName,Email,ConfigurationManager.AppSettings["AdministratorName"].ToString(),ConfigurationManager.AppSettings["AdministratorEmail"].ToString(), toSubject, stringBody.ToString());
                objSMTP = null;

                // DESTROY
                objSettings = null;
                objTemplates = null;
                stringBody = null;

                // REFRESH PANELS SHOW THANK YOU PANEL
                panel_Login.Visible = false;
                panel_ThankYou.Visible = true;

                label_Email.Text = "A copy of my resume has been sent to " + Email;
            }
            else
                label_ErrorMessage.Text += "<p />";
        }
    }
}
