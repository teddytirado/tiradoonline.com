﻿function openModal(v_url, v_width, v_height) {
    if (window.showModalDialog)
    {
        window.showModalDialog(v_url, "ServiceReportWindow", "dialogWidth:" + v_width + "px;dialogHeight:" + v_height + "px;center:yes;location:no;scroll:no;status:no;");
    }
    else
    {
        window.openDialog(v_url, 'ServiceReportWindow', 'width=' + v_width + ',height=' + v_height + ',location=no,toolbar=no,directories=no,status=no,menubar=yes,scrollbars=no,resizable=no,modal=yes,left=100,top=100');
    }

}