﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplicationNameSpace
{
    public partial class _default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ResumeIcon.Attributes.Add("onmouseover", "this.src='/images/desktop/icons/resume_on.gif'");
            ResumeIcon.Attributes.Add("onmouseout", "this.src='/images/desktop/icons/resume_off.gif'");
            ResumeIcon.Attributes.Add("onclick", "openModal('/download_resume.aspx', '650', '600')");
            ResumeIcon.Attributes.Add("alt", "Download My Resume");

            SamplesIcon.Attributes.Add("onmouseover", "this.src='/images/desktop/icons/samples_on.gif'");
            SamplesIcon.Attributes.Add("onmouseout", "this.src='/images/desktop/icons/samples_off.gif'");
            SamplesIcon.Attributes.Add("onclick", "alert('Under Construction')");
            SamplesIcon.Attributes.Add("alt", "View Sample Work");

            EmailIcon.Attributes.Add("onmouseover", "this.src='/images/desktop/icons/email_on.gif'");
            EmailIcon.Attributes.Add("onmouseout", "this.src='/images/desktop/icons/email_off.gif'");
            EmailIcon.Attributes.Add("onclick", "openModal('/email.aspx', '850', '660')");
            EmailIcon.Attributes.Add("alt", "Send Teddy an Email");

            MusicIcon.Attributes.Add("onmouseover", "this.src='/images/desktop/icons/music_on.gif'");
            MusicIcon.Attributes.Add("onmouseout", "this.src='/images/desktop/icons/music_off.gif'");
            MusicIcon.Attributes.Add("onclick", "alert('Under Construction')");
            MusicIcon.Attributes.Add("alt", "View Music Collection");

            TextTeddyIcon.Attributes.Add("onmouseover", "this.src='/images/desktop/icons/text_teddy_on.gif'");
            TextTeddyIcon.Attributes.Add("onmouseout", "this.src='/images/desktop/icons/text_teddy_off.gif'");
            TextTeddyIcon.Attributes.Add("onclick", "openModal('/text_teddy.aspx', '650', '660')");
            TextTeddyIcon.Attributes.Add("alt", "Text Teddy to his phone");

            AdminIcon.Attributes.Add("onmouseover", "this.src='/images/desktop/icons/admin_on.gif'");
            AdminIcon.Attributes.Add("onmouseout", "this.src='/images/desktop/icons/admin_off.gif'");
            AdminIcon.Attributes.Add("onclick", "openModal('/admin/login.aspx', '650', '660')");
            AdminIcon.Attributes.Add("alt", "Log in to tiradoonline.com Administration");
        }
    }
}