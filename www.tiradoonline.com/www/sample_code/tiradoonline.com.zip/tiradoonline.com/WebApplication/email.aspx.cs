﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplicationNameSpace
{
    public partial class email : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                HttpCookie objHttpCookieFrom = Request.Cookies["FromName"];
                if (objHttpCookieFrom != null)
                    txt_From.Text = objHttpCookieFrom.Value.ToString();

                HttpCookie objHttpCookieSubject = Request.Cookies["FromEmail"];
                if (objHttpCookieSubject != null)
                    txt_Subject.Text = objHttpCookieSubject.Value.ToString();
            }
                    
        }

        protected void button_SendTextMessage_Click(object sender, EventArgs e)
        {
            string v_From = txt_From.Text.Trim();
            string v_Email = txt_Email.Text.Trim();
            string v_Subject = txt_Subject.Text.Trim();
            string v_Message = txt_Message.Text.Trim();

            if (v_From == string.Empty)
                lbl_ErrorMessage.Text = "Please enter \"From:\"";
            else if (v_Message == string.Empty)
                lbl_ErrorMessage.Text = "Please enter \"Message\".";
            else
            {
                Emails objEmails = new Emails();

                if (objEmails.Emails_insert("", "", v_From, v_Email, v_Subject, v_Message) == true)
                {
                    // INSERT COOKIES
                    HttpCookie objHttpCookieFrom = new HttpCookie("FromName");
                    objHttpCookieFrom.Value = txt_From.Text;
                    Response.Cookies.Add(objHttpCookieFrom);
                    objHttpCookieFrom.Expires = DateTime.Now.AddDays(5);

                    HttpCookie objHttpCookieEmail = new HttpCookie("FromEmail");
                    objHttpCookieEmail.Value = txt_Email.Text;
                    Response.Cookies.Add(objHttpCookieEmail);
                    objHttpCookieEmail.Expires = DateTime.Now.AddDays(5);

                    txt_Subject.Text = string.Empty;
                    txt_Message.Text = string.Empty;
                    lbl_ErrorMessage.Text = "Email Sent to Teddy.";
                }
            }
        }
    }
}