using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
//using teddytirado.tiradoonline;

namespace WebApplicationNameSpace.UserControls
{
    public partial class ReferencedByControl : System.Web.UI.UserControl
    {
        protected DropDownList DropDownListReferencedBy;


        public int ReferencedByID
        {
            get
            {
                //return  i  .Parse((DropDownList)(DropDownListReferencedBy.SelectedValue.ToString()));
                //return  int objInt(new DropDownList());objResumeTypeDataTable;
                return  1;
         }
            set
            {
                DropDownListReferencedBy.SelectedValue = value.ToString();
            }

        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Bind_DropDownListReferencedBy();
            }
        }

        private void Bind_DropDownListReferencedBy()
        {

            ReferencedBy objReferencedBy = new ReferencedBy();
            DataTable objDataTable = objReferencedBy.GetRows();

            DropDownListReferencedBy.DataSource = objDataTable;
            DropDownListReferencedBy.DataTextField = "ReferencedByName";
            DropDownListReferencedBy.DataValueField = "ReferencedByID";

            DropDownListReferencedBy.DataBind();

            // SET DEFAULT TO CRAIGSLIST (CHANGE IN WEB CONFIG)
            DropDownListReferencedBy.SelectedValue = ConfigurationManager.AppSettings["defaultReferencedByID"].ToString();
        }
    }

}