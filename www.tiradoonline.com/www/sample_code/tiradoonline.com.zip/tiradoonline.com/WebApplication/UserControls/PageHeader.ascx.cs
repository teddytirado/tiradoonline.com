namespace WebApplicationNameSpace.UserControls
{
    using System;
    using System.Data;
    using System.Configuration;
    using System.Collections;
    using System.Web;
    using System.Web.Security;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using System.Web.UI.WebControls.WebParts;
    using System.Web.UI.HtmlControls;

    public partial class PageHeader : System.Web.UI.UserControl
    {
        protected Label Label_PageHeader;

        public string PageHeaderText
        {
            get
            {
                return Label_PageHeader.Text;
            }
            set
            {
                Label_PageHeader.Text = value;
            }

        }

        private void Page_Load(object sender, EventArgs e)
        {
        }

    }
}