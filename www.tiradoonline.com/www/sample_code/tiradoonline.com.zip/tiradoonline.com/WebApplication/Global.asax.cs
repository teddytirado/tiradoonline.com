﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;

namespace WebApplicationNameSpace
{
    public class Global : System.Web.HttpApplication
    {

        void Application_Start(object sender, EventArgs e)
        {
            // Code that runs on application startup

        }

        void Application_End(object sender, EventArgs e)
        {
            //  Code that runs on application shutdown

        }

        void Application_Error(object sender, EventArgs e)
        {
            // Code that runs when an unhandled error occurs

        }

        void Session_Start(object sender, EventArgs e)
        {
            // Code that runs when a new session is started
            // LOG HIT IF FIRST TIME USER

            string stringReferer;
            try
            {

                if (Request.ServerVariables["HTTP_REFERER"].ToString() != "")
                    stringReferer = Request.ServerVariables["HTTP_REFERER"].ToString();
                else
                    stringReferer = "Email";
            }
            catch
            {
                stringReferer = "Email";
            }

            Sessions objHit = new Sessions();
            objHit.SessionID = Session.SessionID.ToString();
            objHit.IPAddress = Request.ServerVariables["REMOTE_ADDR"].ToString();
            objHit.Browser = Request.ServerVariables["HTTP_USER_AGENT"].ToString();
            objHit.Referer = stringReferer;
            objHit.Insert();
            objHit = null;
        }

        void Session_End(object sender, EventArgs e)
        {
            // Code that runs when a session ends. 
            // Note: The Session_End event is raised only when the sessionstate mode
            // is set to InProc in the Web.config file. If session mode is set to StateServer 
            // or SQLServer, the event is not raised.

        }

    }
}
