﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace WebApplicationNameSpace
{
    public partial class _login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button_Login_Click(object sender, EventArgs e)
        {
            string stringUserName = txt_UserName.Text;
            string stringPassword = txt_Password.Text;

            Users objUser = new Users();
            if (objUser.ValidateUser(stringUserName, stringPassword))
            {
                // RECORD LOGIN

                Logins objLogins = new Logins();
                objLogins.UserID = stringUserName;
                objLogins.SessionID = Session.SessionID.ToString();
                objLogins.IPAddress = Request.ServerVariables["REMOTE_ADDR"].ToString();
                objLogins.Insert();
                objLogins = null;

                // CREATE COOKIE
                HttpContext.Current.Session["UserID"] = stringUserName;
                HttpCookie cookieUserID = new HttpCookie("UserID");
                cookieUserID.Value = stringUserName;
                cookieUserID.Expires = DateTime.Now.AddDays(10);
                HttpContext.Current.Response.Cookies.Add(cookieUserID);

                // AUTHENTICATE USER
                HttpContext.Current.Session["UserID"] = stringUserName;
                //FormsAuthentication.RedirectFromLoginPage(stringUserName, true);
                Response.Redirect(ConfigurationManager.AppSettings["defaultHomePage"].ToString());
            }
            else
            {
                // IF NOT A VALID LOGIN RECORD INVALID LOGIN
                InvalidLogins objInvalidLogin = new InvalidLogins();
                objInvalidLogin.SessionID = Session.SessionID.ToString();
                objInvalidLogin.IPAddress = Request.ServerVariables["REMOTE_ADDR"].ToString();
                objInvalidLogin.UserName = stringUserName;
                objInvalidLogin.Password = stringPassword;
                objInvalidLogin.Insert();
                objInvalidLogin = null;
                label_ErrorMessage.Text = "INVALID&nbsp;LOGIN";
            }
            objUser = null;

        }
    }
}