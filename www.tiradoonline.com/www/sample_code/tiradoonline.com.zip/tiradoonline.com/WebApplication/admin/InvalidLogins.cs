using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.Text;

namespace WebApplicationNameSpace
{
    public class InvalidLogins
    {
        public string SessionID;
        public string IPAddress;
        public string UserName;
        public string Password;

        public void Insert()
        {
            SqlConnection objSQLConnection = new SqlConnection();
            SqlCommand objSQLCommand = new SqlCommand("sp_InvalidLogins_insert", objSQLConnection);
            objSQLCommand.CommandType = CommandType.StoredProcedure;

            SqlParameter parameterSessionID = new SqlParameter("@SessionID", SqlDbType.VarChar);
            parameterSessionID.Value = this.SessionID;
            objSQLCommand.Parameters.Add(parameterSessionID);

            SqlParameter parameterUserName = new SqlParameter("@UserName", SqlDbType.VarChar);
            parameterUserName.Value = this.UserName;
            objSQLCommand.Parameters.Add(parameterUserName);

            SqlParameter parameterPassword = new SqlParameter("@Password", SqlDbType.VarChar);
            parameterPassword.Value = this.Password;
            objSQLCommand.Parameters.Add(parameterPassword);

            //SqlParameter parameterIPAddress = new SqlParameter("@IPAddress", SqlDbType.VarChar);
            //parameterIPAddress.Value = this.IPAddress;
            //objSQLCommand.Parameters.Add(parameterIPAddress);

            try
            {
                objSQLConnection.Open();
                objSQLCommand.ExecuteNonQuery();

                // Return Identity of Snippet
                //objMovieStruct.MovieDBReturnValue = int.Parse(parameterReturnValue.Value.ToString());
            }
            catch (SqlException objSqlException)
            {
                string errorstring = objSqlException.ToString();
            }
            finally
            {
                if (objSQLConnection.State == ConnectionState.Open)
                {
                    objSQLConnection.Close();
                    objSQLConnection = null;
                }
            }
            //return objMovieStruct;
        }

        public DataTable GetRows()
        {
            SqlConnection objSQLConnection = new SqlConnection();
            SqlCommand objSQLCommand = new SqlCommand("sp_InvalidLogins_get", objSQLConnection);
            objSQLCommand.CommandType = CommandType.StoredProcedure;

            //SqlParameter parameterUserID = new SqlParameter("@UserID", SqlDbType.VarChar);
            //parameterUserID.Value = this.UserID;
            //objSQLCommand.Parameters.Add(parameterUserID);

            try
            {
                SqlDataAdapter objSqlDataAdapter = new SqlDataAdapter(objSQLCommand);
                DataTable objDataTable = new DataTable();
                objSqlDataAdapter.Fill(objDataTable);
                return objDataTable;
            }
            catch (SqlException objSqlException)
            {
                string errorstring = objSqlException.ToString();
                return null;
            }
            finally
            {
                if (objSQLConnection.State == ConnectionState.Open)
                {
                    objSQLConnection.Close();
                    objSQLConnection = null;
                }
            }
        }

    }
}
