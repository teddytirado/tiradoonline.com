﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplicationNameSpace
{
    public partial class text_teddy : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                HttpCookie objHttpCookie = Request.Cookies["TextTeddyFrom"];
                if (objHttpCookie != null)
                    txt_From.Text = objHttpCookie.Value.ToString();
            }
                    
        }

        protected void button_SendTextMessage_Click(object sender, EventArgs e)
        {
            string v_From = txt_From.Text.Trim();
            string v_Message = txt_Message.Text.Trim();

            if (v_From == string.Empty)
                lbl_ErrorMessage.Text = "Please enter \"From:\"";
            else if (v_Message == string.Empty)
                lbl_ErrorMessage.Text = "Please enter \"Message\".";
            else
            {
                TextMessage objTextMessage = new TextMessage();

                if (objTextMessage.TextMessage_insert(v_From, v_Message) == true)
                {
                    SqlConnection objSQLConnection = new SqlConnection();
                    SqlCommand objSQLCommand = new SqlCommand("sp_TextMessages_insert", objSQLConnection);
                    objSQLCommand.CommandType = CommandType.StoredProcedure;

                    SqlParameter parameterTextMessageFrom= new SqlParameter("@TextMessageFrom", SqlDbType.VarChar);
                    parameterTextMessageFrom.Value = v_From;
                    objSQLCommand.Parameters.Add(parameterTextMessageFrom);

                    SqlParameter parameterTextMessageText = new SqlParameter("@TextMessageText", SqlDbType.VarChar);
                    parameterTextMessageText.Value = v_Message;
                    objSQLCommand.Parameters.Add(parameterTextMessageText);

                    try
                    {
                        objSQLConnection.Open();
                        objSQLCommand.ExecuteNonQuery();
                        // Return Identity of Snippet
                        //objMovieStruct.MovieDBReturnValue = int.Parse(parameterReturnValue.Value.ToString());
                    }
                    catch (SqlException objSqlException)
                    {
                        string errorstring = objSqlException.Errors[0].ToString();
                        string RedirectURL = "/ErrorPage.aspx?ErrorMessage=" + HttpContext.Current.Server.UrlEncode(errorstring);
                        //HttpContext.Current.Response.Redirect(RedirectURL);
                    }
                    finally
                    {
                        if (objSQLConnection.State == ConnectionState.Open)
                        {
                            objSQLConnection.Close();
                            objSQLConnection = null;
                        }
                    }

                    // INSERT COOKIES
                    HttpCookie objHttpCookie = new HttpCookie("TextTeddyFrom");
                    objHttpCookie.Value = txt_From.Text;
                    Response.Cookies.Add(objHttpCookie);
                    objHttpCookie.Expires = DateTime.Now.AddDays(5);

                    txt_Message.Text = string.Empty;
                    lbl_ErrorMessage.Text = "Text Message sent.";

                
                
                }
            }
        }
    }
}