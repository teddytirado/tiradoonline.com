﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Web;

namespace WebApplicationNameSpace
{
    public class Movies
    {
        public DataTable getMovies(string Location)
        {
            //string Location = @"d:\movies\avi\";

            //files in directory
            string[] filePaths = Directory.GetFiles(Location);

            //files in directory (with specified extension)
            //string[] filePaths = Directory.GetFiles(Location, "*.bmp");

            //files in directory (including all subdirectories)
            //string[] filePaths = Directory.GetFiles(Location, "*.bmp", SearchOption.AllDirectories);

            DataTable objDataTable = new DataTable();
            DataColumn column = new DataColumn();
            column.DataType = System.Type.GetType("System.String");
            column.ColumnName = "product_title";
            objDataTable.Columns.Add(column);

            try
            {
                // Declare DataColumn and DataRow variables.
                return objDataTable;
            }
            catch (Exception ex)
            {
                string error_string = ex.Message.ToString();
                string err = string.Empty;
                return null;
                //throw new Exception(ex.Message);
            }


            //filePaths = null;
        }
    }
}