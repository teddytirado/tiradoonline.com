﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplicationNameSpace
{
    public class Emails
    {
        public bool Emails_insert(string v_ToName, string v_ToEmail, string v_From, string v_Email, string v_Subject, string v_Message)
        {
                SMTP objSMTP = new SMTP();
                objSMTP.SendEmail(ConfigurationManager.AppSettings["AdministratorName"].ToString(),
                                  ConfigurationManager.AppSettings["AdministratorEmail"].ToString(),
                                  v_From,
                                  v_Email,
                                v_Subject,
                                v_Message);
                return true;
        }            
    }            
}
