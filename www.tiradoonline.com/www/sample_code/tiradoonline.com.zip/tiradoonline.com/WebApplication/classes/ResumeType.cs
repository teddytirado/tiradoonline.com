using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace WebApplicationNameSpace
{
    public class ResumeType
    {
        public int ResumeTypeID;
        public string ResumeTypeName;
        public string ResumeTypeExt;


        public DataTable GetRows()
        {
            SqlConnection objSQLConnection = null;
            SqlCommand objSQLCommand = null;

            // Create Instance of Connection and Command Object
            objSQLConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["SQLConnectionString"].ToString());
            objSQLCommand = new SqlCommand("sp_ResumeType_get", objSQLConnection);
            objSQLCommand.CommandType = CommandType.StoredProcedure;

            //SqlParameter parameterResumeType = new SqlParameter("@ResumeTypeID", SqlDbType.Int);
            //parameterResumeType.Value = this.ResumeTypeID;
            //objSQLCommand.Parameters.Add(parameterResumeType);


            try
            {
                SqlDataAdapter objSqlDataAdapter = new SqlDataAdapter(objSQLCommand);
                DataTable objDataTable = new DataTable();
                objSqlDataAdapter.Fill(objDataTable);
                return objDataTable;


                // Return Identity of Snippet
                //objMovieStruct.MovieDBReturnValue = int.Parse(parameterReturnValue.Value.ToString());
            }
            catch (SqlException objSqlException)
            {
                string errorstring = objSqlException.Errors[0].ToString();
                //string RedirectURL = "/ErrorPage.aspx?ErrorMessage=" + HttpContext.Current.Server.UrlEncode(errorstring);
                //HttpContext.Current.Response.Redirect(RedirectURL);
                return null;
            }
            finally
            {
                if (objSQLConnection.State == ConnectionState.Open)
                {
                    objSQLConnection.Close();
                    objSQLConnection = null;
                }
            }
            //return objMovieStruct;
        }


        public void GetRows_ResumeTypeID()
        {
            SqlConnection objSQLConnection = new SqlConnection();
            SqlCommand objSQLCommand = new SqlCommand("sp_ResumeType_ResumeTypeID_get", objSQLConnection);
            objSQLCommand.CommandType = CommandType.StoredProcedure;

            SqlParameter parameterResumeType = new SqlParameter("@ResumeTypeID", SqlDbType.Int);
            parameterResumeType.Value = this.ResumeTypeID;
            objSQLCommand.Parameters.Add(parameterResumeType);

            try
            {
                SqlDataAdapter objSqlDataAdapter = new SqlDataAdapter(objSQLCommand);
                DataTable objDataTable = new DataTable();
                objSqlDataAdapter.Fill(objDataTable);
                this.ResumeTypeName = objDataTable.Rows[0]["ResumeTypeName"].ToString();
                this.ResumeTypeExt = objDataTable.Rows[0]["ResumeTypeExt"].ToString();
            }
            catch (SqlException objSqlException)
            {
                string errorstring = objSqlException.Errors[0].ToString();
                string RedirectURL = "/ErrorPage.aspx?ErrorMessage=" + HttpContext.Current.Server.UrlEncode(errorstring);
                //HttpContext.Current.Response.Redirect(RedirectURL);
            }
            finally
            {
                if (objSQLConnection.State == ConnectionState.Open)
                {
                    objSQLConnection.Close();
                    objSQLConnection = null;
                }
            }
            //return objMovieStruct;
        }

    }
}
