using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace WebApplicationNameSpace
{
    public class ResumeDownload
    {
        public int JobID;
        public string UserID;
        public string FullName;
        public string Company;
        public string Email;
        public string Phone;
        public string Comments;
        public string Website;
        public string IPAddress;
        public string Browser;
        public int ResumeDownloadID;
        public int ReferencedByID;
        public int ResumeTypeID;
        public string ReferencedByName;
        public string ResumeTypeName;
        public string Referer;
        public string SessionID;
        public DateTime create_dt;

        public void Insert()
        {
            SqlConnection objSQLConnection = new SqlConnection();
            SqlCommand objSQLCommand = new SqlCommand("sp_ResumeDownloads_insert", objSQLConnection);
            objSQLCommand.CommandType = CommandType.StoredProcedure;

            SqlParameter parameterUserID = new SqlParameter("@UserID", SqlDbType.VarChar);
            parameterUserID.Value = this.UserID;
            objSQLCommand.Parameters.Add(parameterUserID);

            SqlParameter parameterFullName = new SqlParameter("@FullName", SqlDbType.VarChar);
            parameterFullName.Value = this.FullName;
            objSQLCommand.Parameters.Add(parameterFullName);

            SqlParameter parameterCompany = new SqlParameter("@Company", SqlDbType.VarChar);
            parameterCompany.Value = this.Company;
            objSQLCommand.Parameters.Add(parameterCompany);

            SqlParameter parameterPhone = new SqlParameter("@Phone", SqlDbType.VarChar);
            parameterPhone.Value = this.Phone;
            objSQLCommand.Parameters.Add(parameterPhone);

            SqlParameter parameterEmail = new SqlParameter("@Email", SqlDbType.VarChar);
            parameterEmail.Value = this.Email;
            objSQLCommand.Parameters.Add(parameterEmail);

            SqlParameter parameterComments = new SqlParameter("@Comments", SqlDbType.VarChar);
            parameterComments.Value = this.Comments;
            objSQLCommand.Parameters.Add(parameterComments);

            SqlParameter parameterWebsite = new SqlParameter("@Website", SqlDbType.VarChar);
            parameterWebsite.Value = this.Website;
            objSQLCommand.Parameters.Add(parameterWebsite);

            SqlParameter parameterReferencedBy = new SqlParameter("@ReferencedByID", SqlDbType.Int);
            parameterReferencedBy.Value = this.ReferencedByID;
            objSQLCommand.Parameters.Add(parameterReferencedBy);

            SqlParameter parameterResumeTypeID = new SqlParameter("@ResumeTypeID", SqlDbType.Int);
            parameterResumeTypeID.Value = this.ResumeTypeID;
            objSQLCommand.Parameters.Add(parameterResumeTypeID);

            SqlParameter parameterReferer = new SqlParameter("@Referer", SqlDbType.VarChar);
            parameterReferer.Value = this.Referer;
            objSQLCommand.Parameters.Add(parameterReferer);

            SqlParameter parameterSessionID = new SqlParameter("@SessionID", SqlDbType.VarChar);
            parameterSessionID.Value = this.SessionID;
            objSQLCommand.Parameters.Add(parameterSessionID);

            try
            {
                objSQLConnection.Open();
                objSQLCommand.ExecuteNonQuery();
                // Return Identity of Snippet
                //objMovieStruct.MovieDBReturnValue = int.Parse(parameterReturnValue.Value.ToString());
            }
            catch (SqlException objSqlException)
            {
                string errorstring = objSqlException.Errors[0].ToString();
                string RedirectURL = "/ErrorPage.aspx?ErrorMessage=" + HttpContext.Current.Server.UrlEncode(errorstring);
                //HttpContext.Current.Response.Redirect(RedirectURL);
            }
            finally
            {
                if (objSQLConnection.State == ConnectionState.Open)
                {
                    objSQLConnection.Close();
                    objSQLConnection = null;
                }
            }
            //return objMovieStruct;
        }

        public DataTable GetRows_UserID()
        {
            SqlConnection objSQLConnection = new SqlConnection();
            SqlCommand objSQLCommand = new SqlCommand("sp_ResumeDownloads_UserID_get", objSQLConnection);
            objSQLCommand.CommandType = CommandType.StoredProcedure;

            SqlParameter parameterUserID = new SqlParameter("@UserID", SqlDbType.VarChar);
            parameterUserID.Value = this.UserID;
            objSQLCommand.Parameters.Add(parameterUserID);

            try
            {
                SqlDataAdapter objSqlDataAdapter = new SqlDataAdapter(objSQLCommand);
                DataTable objDataTable = new DataTable();
                objSqlDataAdapter.Fill(objDataTable);
                return objDataTable;
            }
            catch (SqlException objSqlException)
            {
                string errorstring = objSqlException.Errors[0].ToString();
                string RedirectURL = "/ErrorPage.aspx?ErrorMessage=" + HttpContext.Current.Server.UrlEncode(errorstring);
                //HttpContext.Current.Response.Redirect(RedirectURL);
                return null;
            }
            finally
            {
                if (objSQLConnection.State == ConnectionState.Open)
                {
                    objSQLConnection.Close();
                    objSQLConnection = null;
                }
            }
        }

        public void GetRows_ResumeDownloadID()
        {
            SqlConnection objSQLConnection = new SqlConnection();
            SqlCommand objSQLCommand = new SqlCommand("sp_ResumeDownloads_ResumeDownloadID_get", objSQLConnection);
            objSQLCommand.CommandType = CommandType.StoredProcedure;

            SqlParameter parameterResumeDownloadID = new SqlParameter("@ResumeDownloadID", SqlDbType.VarChar);
            parameterResumeDownloadID.Value = this.ResumeDownloadID;
            objSQLCommand.Parameters.Add(parameterResumeDownloadID);

            try
            {
                SqlDataAdapter objSqlDataAdapter = new SqlDataAdapter(objSQLCommand);
                DataTable objDataTable = new DataTable();
                objSqlDataAdapter.Fill(objDataTable);
                this.JobID = int.Parse(objDataTable.Rows[0]["JobID"].ToString());
                this.FullName = objDataTable.Rows[0]["FullName"].ToString();
                this.Company = objDataTable.Rows[0]["Company"].ToString();
                this.Phone = objDataTable.Rows[0]["Phone"].ToString();
                this.Email = objDataTable.Rows[0]["Email"].ToString();
                this.Comments = objDataTable.Rows[0]["Comments"].ToString();
                this.Website = objDataTable.Rows[0]["Website"].ToString();
                this.ReferencedByName = objDataTable.Rows[0]["ReferencedByName"].ToString();
                this.ResumeTypeName = objDataTable.Rows[0]["ResumeTypeName"].ToString();
                this.Referer = objDataTable.Rows[0]["Referer"].ToString();
                this.SessionID = objDataTable.Rows[0]["SessionID"].ToString();
                this.IPAddress = objDataTable.Rows[0]["IPAddress"].ToString();
                this.Browser = objDataTable.Rows[0]["Browser"].ToString();
                this.create_dt = DateTime.Parse(objDataTable.Rows[0]["create_dt"].ToString());
                //return objDataTable;
            }
            catch (SqlException objSqlException)
            {
                string errorstring = objSqlException.Errors[0].ToString();
                string RedirectURL = "/ErrorPage.aspx?ErrorMessage=" + HttpContext.Current.Server.UrlEncode(errorstring);
                //HttpContext.Current.Response.Redirect(RedirectURL);
            }
            finally
            {
                if (objSQLConnection.State == ConnectionState.Open)
                {
                    objSQLConnection.Close();
                    objSQLConnection = null;
                }
            }
        }

        public void Delete()
        {
            SqlConnection objSQLConnection = new SqlConnection();
            SqlCommand objSQLCommand = new SqlCommand("sp_ResumeDownloads_delete", objSQLConnection);
            objSQLCommand.CommandType = CommandType.StoredProcedure;

            SqlParameter parameterResumeDownloadID = new SqlParameter("@ResumeDownloadID", SqlDbType.Int);
            parameterResumeDownloadID.Value = this.ResumeDownloadID;
            objSQLCommand.Parameters.Add(parameterResumeDownloadID);
            string sqlstring = objSQLCommand.CommandText;

            try
            {
                objSQLConnection.Open();
                objSQLCommand.ExecuteNonQuery();
                // Return Identity of Snippet
                //objMovieStruct.MovieDBReturnValue = int.Parse(parameterReturnValue.Value.ToString());
            }
            catch (SqlException objSqlException)
            {
                string errorstring = objSqlException.Errors[0].ToString();
                string RedirectURL = "/ErrorPage.aspx?ErrorMessage=" + HttpContext.Current.Server.UrlEncode(errorstring);
                //HttpContext.Current.Response.Redirect(RedirectURL);
            }
            finally
            {
                if (objSQLConnection.State == ConnectionState.Open)
                {
                    objSQLConnection.Close();
                    objSQLConnection = null;
                }
            }
            //return objMovieStruct;
        }
    }
}
