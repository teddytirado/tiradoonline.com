using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace WebApplicationNameSpace
{
    public class Sessions
    {
        public string SessionID;
        public string IPAddress;
        public string Browser;
        public string Referer;
        public DateTime CurrentDate;

        public void Insert()
        {
            SqlConnection objSQLConnection = new SqlConnection();
            SqlCommand objSQLCommand = new SqlCommand("sp_Sessions_insert", objSQLConnection);
            objSQLCommand.CommandType = CommandType.StoredProcedure;

            SqlParameter parameterSessionID = new SqlParameter("@SessionID", SqlDbType.VarChar);
            parameterSessionID.Value = this.SessionID;
            objSQLCommand.Parameters.Add(parameterSessionID);

            SqlParameter parameterIPAddress = new SqlParameter("@IPAddress", SqlDbType.VarChar);
            parameterIPAddress.Value = this.IPAddress;
            objSQLCommand.Parameters.Add(parameterIPAddress);

            SqlParameter parameterBrowser = new SqlParameter("@Browser", SqlDbType.VarChar);
            parameterBrowser.Value = this.Browser;
            objSQLCommand.Parameters.Add(parameterBrowser);

            SqlParameter parameterReferer = new SqlParameter("@Referer", SqlDbType.VarChar);
            parameterReferer.Value = this.Referer;
            objSQLCommand.Parameters.Add(parameterReferer);

            try
            {
                objSQLConnection.Open();
                objSQLCommand.ExecuteNonQuery();

                // Return Identity of Snippet
                //objMovieStruct.MovieDBReturnValue = int.Parse(parameterReturnValue.Value.ToString());
            }
            catch (SqlException objSqlException)
            {
                string errorstring = objSqlException.Errors[0].ToString();
                string RedirectURL = "/ErrorPage.aspx?ErrorMessage=" + HttpContext.Current.Server.UrlEncode(errorstring);
                //HttpContext.Current.Response.Redirect(RedirectURL);
            }
            finally
            {
                if (objSQLConnection.State == ConnectionState.Open)
                {
                    objSQLConnection.Close();
                    objSQLConnection = null;
                }
            }
            //return objMovieStruct;
        }

        public DataTable GetRows()
        {
            SqlConnection objSQLConnection = new SqlConnection();
            SqlCommand objSQLCommand = new SqlCommand("sp_Sessions_get", objSQLConnection);
            objSQLCommand.CommandType = CommandType.StoredProcedure;

            SqlParameter parameterCurrentDate = new SqlParameter("@CurrentDate", SqlDbType.DateTime);
            parameterCurrentDate.Value = this.CurrentDate;
            objSQLCommand.Parameters.Add(parameterCurrentDate);

            try
            {
                SqlDataAdapter objSqlDataAdapter = new SqlDataAdapter(objSQLCommand);
                DataTable objDataTable = new DataTable();
                objSqlDataAdapter.Fill(objDataTable);
                return objDataTable;
            }
            catch (SqlException objSqlException)
            {
                string errorstring = objSqlException.Errors[0].ToString();
                string RedirectURL = "/ErrorPage.aspx?ErrorMessage=" + HttpContext.Current.Server.UrlEncode(errorstring);
                //HttpContext.Current.Response.Redirect(RedirectURL);
                return null;
            }
            finally
            {
                if (objSQLConnection.State == ConnectionState.Open)
                {
                    objSQLConnection.Close();
                    objSQLConnection = null;
                }
            }
        }

    }
}
