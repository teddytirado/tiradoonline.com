using System;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace WebApplicationNameSpace
{
    public class SMTP
    {
        public string Host;
        public string UserID;
        public string ToName;
        public string ToEmail;
        public string FromEmail;
        public string Subject;
        public string BodyText;
        public string Password;
        public ArrayList Attachments = new ArrayList();

        public void SendEmail(string toName, string toAddress, string fromName, string fromEmail, string toSubject, string toBodyText)
        {
            MailMessage objMailMessage = new MailMessage();

            // GET USERS SMTP SETTINGS
            Settings objSettings = new Settings();
            objSettings.GetRows_UserID("teddytirado");
            string SMTPServer = objSettings.SMTPHost;
            string SMTPPort = objSettings.SMTPPort;
            string SMTPUserName = objSettings.SMTPUserName;
            string SMTPPassword = objSettings.SMTPPassword;
            System.Net.NetworkCredential SMTPUserInfo = new System.Net.NetworkCredential(SMTPUserName, SMTPPassword);
            SmtpClient objSmtpClient = new SmtpClient(SMTPServer, System.Convert.ToInt32(SMTPPort));
            //SMTPUserInfo.Domain = SMTPServer;
            objSmtpClient.UseDefaultCredentials = false;
            objSmtpClient.Credentials = SMTPUserInfo;

            //Attachment objAttachment = new Attachment("");
            objMailMessage.From = new MailAddress(fromEmail);
            objMailMessage.To.Add(new MailAddress(toAddress));
    
            objMailMessage.Subject = toSubject;
            objMailMessage.Body = toBodyText;
            for (int counter = 0; counter < Attachments.Count; counter++)
            {
                string stringAttachment = Attachments[counter].ToString();
                Attachment objAttachment = new Attachment(stringAttachment);
                objMailMessage.Attachments.Add(objAttachment);
            }

            try
            {
                objSmtpClient.Send(objMailMessage);
            }
            catch (SmtpException ex)
            {
                string error_string = ex.ToString();
                string e = error_string;
            }

            objSettings = null;

            objMailMessage = null;
            objSmtpClient = null;
        }
    }
}
