using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace WebApplicationNameSpace
{
    public class Logins
    {
        public string UserID;
        public string SessionID;
        public string IPAddress;

        public void Insert()
        {
            SqlConnection objSQLConnection = new SqlConnection();
            SqlCommand objSQLCommand = new SqlCommand("sp_Logins_insert", objSQLConnection);
            objSQLCommand.CommandType = CommandType.StoredProcedure;

            SqlParameter parameterUserID = new SqlParameter("@UserID", SqlDbType.VarChar);
            parameterUserID.Value = this.UserID;
            objSQLCommand.Parameters.Add(parameterUserID);

            SqlParameter parameterSessionID = new SqlParameter("@SessionID", SqlDbType.VarChar);
            parameterSessionID.Value = this.SessionID;
            objSQLCommand.Parameters.Add(parameterSessionID);

            //SqlParameter parameterIPAddress = new SqlParameter("@IPAddress", SqlDbType.VarChar);
            //parameterIPAddress.Value = this.IPAddress;
            //objSQLCommand.Parameters.Add(parameterIPAddress);

            try
            {
                objSQLConnection.Open();
                objSQLCommand.ExecuteNonQuery();

            }
            catch (SqlException objSqlException)
            {
                string errorstring = objSqlException.Errors[0].ToString();
                string RedirectURL = "/ErrorPage.aspx?ErrorMessage=" + HttpContext.Current.Server.UrlEncode(errorstring);
                //HttpContext.Current.Response.Redirect(RedirectURL);
            }
            finally
            {
                if (objSQLConnection.State == ConnectionState.Open)
                {
                    objSQLConnection.Close();
                    objSQLConnection = null;
                }
            }
            //return objMovieStruct;
        }

        public DataTable GetRows()
        {
            SqlConnection objSQLConnection = new SqlConnection();
            SqlCommand objSQLCommand = new SqlCommand("sp_Logins_get", objSQLConnection);
            objSQLCommand.CommandType = CommandType.StoredProcedure;

            //SqlParameter parameterUserID = new SqlParameter("@UserID", SqlDbType.VarChar);
            //parameterUserID.Value = this.UserID;
            //objSQLCommand.Parameters.Add(parameterUserID);

            try
            {
                SqlDataAdapter objSqlDataAdapter = new SqlDataAdapter(objSQLCommand);
                DataTable objDataTable = new DataTable();
                objSqlDataAdapter.Fill(objDataTable);
                return objDataTable;
            }
            catch (SqlException objSqlException)
            {
                string errorstring = objSqlException.Errors[0].ToString();
                string RedirectURL = "/ErrorPage.aspx?ErrorMessage=" + HttpContext.Current.Server.UrlEncode(errorstring);
                //HttpContext.Current.Response.Redirect(RedirectURL);
                return null;
            }
            finally
            {
                if (objSQLConnection.State == ConnectionState.Open)
                {
                    objSQLConnection.Close();
                    objSQLConnection = null;
                }
            }
        }

    }
}
