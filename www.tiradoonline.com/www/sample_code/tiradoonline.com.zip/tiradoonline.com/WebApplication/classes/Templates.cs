using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace WebApplicationNameSpace
{
    public class Templates
    {
        public string CoverLetter
        {
            get
            {
                string templateText = GetTemplate("Cover Letter");
                templateText = templateText.Replace("\n\n", "<p />");
                templateText = templateText.Replace("\n", "<br />");
                return templateText;
            }
            set
            {
                string coverlettertext = value;
                SaveTemplate("Cover Letter", coverlettertext);
            }
        }

        public string Craigslist
        {
            get
            {
                return GetTemplate("Craigslist");
            }
            set
            {
                SaveTemplate("Craigslist", value);
            }

        }

        public string EmailThankYou
        {
            get
            {
                string templateText = GetTemplate("EmailThankYou");
                //templateText = templateText.Replace("\n\n", "<p />");
                //templateText = templateText.Replace("\n", "<br />");
                return templateText;
            }
            set
            {
                string templateText = value;
                SaveTemplate("EmailThankYou", templateText);
            }
        }

        public string EmailResume
        {
            get
            {
                return GetTemplate("EmailResume");
            }
            set
            {
                SaveTemplate("EmailResume", value);
            }

        }

        public string Resume
        {
            get
            {
                return GetTemplate("Resume");
            }
            set
            {
                SaveTemplate("Resume", value);
            }

        }

        private string GetTemplate(string templateName)
        {
            // Create Instance of Connection and Command Object
            SqlConnection objSQLConnection = new SqlConnection();
            SqlCommand objSQLCommand = new SqlCommand("sp_Templates_TemplateName_get", objSQLConnection);
            objSQLCommand.CommandType = CommandType.StoredProcedure;

            SqlParameter parameterTemplateName = new SqlParameter("@TemplateName", SqlDbType.VarChar);
            parameterTemplateName.Value = templateName;
            objSQLCommand.Parameters.Add(parameterTemplateName);

            try
            {
                SqlDataAdapter objSqlDataAdapter = new SqlDataAdapter(objSQLCommand);
                DataTable objDataTable = new DataTable();
                objSqlDataAdapter.Fill(objDataTable);
                return objDataTable.Rows[0][0].ToString();


                // Return Identity of Snippet
                //objMovieStruct.MovieDBReturnValue = int.Parse(parameterReturnValue.Value.ToString());
            }
            catch (SqlException objSqlException)
            {
                string errorstring = objSqlException.Errors[0].ToString();
                string RedirectURL = "/ErrorPage.aspx?ErrorMessage=" + HttpContext.Current.Server.UrlEncode(errorstring);
                //HttpContext.Current.Response.Redirect(RedirectURL);
                return null;
            }
            finally
            {
                if (objSQLConnection.State == ConnectionState.Open)
                {
                    objSQLConnection.Close();
                    objSQLConnection = null;
                }
            }
        }

        private void SaveTemplate(string templateName, string templateText)
        {
            // Create Instance of Connection and Command Object
            SqlConnection objSQLConnection = new SqlConnection();
            SqlCommand objSQLCommand = new SqlCommand("sp_Templates_TemplateName_update", objSQLConnection);
            objSQLCommand.CommandType = CommandType.StoredProcedure;

            SqlParameter parameterTemplateName = new SqlParameter("@TemplateName", SqlDbType.VarChar);
            parameterTemplateName.Value = templateName;
            objSQLCommand.Parameters.Add(parameterTemplateName);

            SqlParameter parameterTemplateText = new SqlParameter("@TemplateText", SqlDbType.VarChar);
            parameterTemplateText.Value = templateText;
            objSQLCommand.Parameters.Add(parameterTemplateText);

            try
            {
                objSQLConnection.Open();
                objSQLCommand.ExecuteNonQuery();
            }
            catch (SqlException objSqlException)
            {
                string errorstring = objSqlException.Errors[0].ToString();
                string RedirectURL = "/ErrorPage.aspx?ErrorMessage=" + HttpContext.Current.Server.UrlEncode(errorstring);
                //HttpContext.Current.Response.Redirect(RedirectURL);
            }
            finally
            {
                if (objSQLConnection.State == ConnectionState.Open)
                {
                    objSQLConnection.Close();
                    objSQLConnection = null;
                }
            }
            
        }

    }
}