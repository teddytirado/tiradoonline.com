﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplicationNameSpace
{
    public class TextMessage
    {
        public bool TextMessage_insert(string v_From, string v_Message)
        {
            v_Message = "From: " + v_From + " ----- " + v_Message;
            SqlConnection objSQLConnection = new SqlConnection();
            SqlCommand objSQLCommand = new SqlCommand("sp_TextMessages_insert", objSQLConnection);
            objSQLCommand.CommandType = CommandType.StoredProcedure;

            SqlParameter parameterTextMessageFrom = new SqlParameter("@TextMessageFrom", SqlDbType.VarChar);
            parameterTextMessageFrom.Value = v_From;
            objSQLCommand.Parameters.Add(parameterTextMessageFrom);

            SqlParameter parameterTextMessageText = new SqlParameter("@TextMessageText", SqlDbType.VarChar);
            parameterTextMessageText.Value = v_Message;
            objSQLCommand.Parameters.Add(parameterTextMessageText);

            try
            {
                objSQLConnection.Open();
                objSQLCommand.ExecuteNonQuery();
                // Return Identity of Snippet
                //objMovieStruct.MovieDBReturnValue = int.Parse(parameterReturnValue.Value.ToString());

                SMTP objSMTP = new SMTP();
                objSMTP.SendEmail(ConfigurationManager.AppSettings["AdministratorName"].ToString(),
                                  ConfigurationManager.AppSettings["MobilePhone"].ToString(),
                                  v_From,
                                ConfigurationManager.AppSettings["AdministratorEmail"].ToString(),
                                "Text Message from " + v_From, v_Message);
                return true;
            }
            catch (SqlException objSqlException)
            {
                string errorstring = objSqlException.Errors[0].ToString();
                string RedirectURL = "/ErrorPage.aspx?ErrorMessage=" + HttpContext.Current.Server.UrlEncode(errorstring);
                //HttpContext.Current.Response.Redirect(RedirectURL);
                return false;
            }
            finally
            {
                if (objSQLConnection.State == ConnectionState.Open)
                {
                    objSQLConnection.Close();
                    objSQLConnection = null;
                }
            }
        }
    }
}