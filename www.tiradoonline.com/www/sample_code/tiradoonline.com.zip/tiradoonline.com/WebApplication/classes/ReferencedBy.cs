using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace WebApplicationNameSpace
{
    public class ReferencedBy
    {
        public int ReferencedByID;

        public DataTable GetRows()
        {
            // Create Instance of Connection and Command Object
            string stringConnection = ConfigurationManager.ConnectionStrings["SQLConnectionString"].ToString();
            SqlConnection objSQLConnection = new SqlConnection(stringConnection);
            SqlCommand objSQLCommand = new SqlCommand("sp_ReferencedBy_get", objSQLConnection);
            objSQLCommand.CommandType = CommandType.StoredProcedure;

            try
            {
                SqlDataAdapter objSqlDataAdapter = new SqlDataAdapter(objSQLCommand);
                DataTable objDataTable = new DataTable();
                objSqlDataAdapter.Fill(objDataTable);
                return objDataTable;
            }
            catch (SqlException objSqlException)
            {
                string errorstring = objSqlException.Errors[0].ToString();
                string RedirectURL = "/ErrorPage.aspx?ErrorMessage=" + HttpContext.Current.Server.UrlEncode(errorstring);
                //HttpContext.Current.Response.Redirect(RedirectURL);
                return null;
            }
            finally
            {
                if (objSQLConnection.State == ConnectionState.Open)
                {
                    objSQLConnection.Close();
                    objSQLConnection = null;
                }
            }
            //return objMovieStruct;
        }

    }
}
