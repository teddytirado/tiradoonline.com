﻿namespace BackupNameSpace
{
    partial class BackupMainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BackupMainForm));
            this.groupBoxSourceDestination = new System.Windows.Forms.GroupBox();
            this.lblSourceDestination = new System.Windows.Forms.Label();
            this.btnSourceDestination = new System.Windows.Forms.Button();
            this.groupBoxTargetDestionation = new System.Windows.Forms.GroupBox();
            this.lblTargetDestination = new System.Windows.Forms.Label();
            this.btnTargetDestination = new System.Windows.Forms.Button();
            this.lblProgress = new System.Windows.Forms.Label();
            this.btnBackup = new System.Windows.Forms.Button();
            this.progressBarBackup = new System.Windows.Forms.ProgressBar();
            this.folderBrowserDialogSourceDestination = new System.Windows.Forms.FolderBrowserDialog();
            this.folderBrowserDialogTargetDestination = new System.Windows.Forms.FolderBrowserDialog();
            this.timerBackup = new System.Windows.Forms.Timer(this.components);
            this.groupBoxSourceDestination.SuspendLayout();
            this.groupBoxTargetDestionation.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxSourceDestination
            // 
            this.groupBoxSourceDestination.Controls.Add(this.btnSourceDestination);
            this.groupBoxSourceDestination.Controls.Add(this.lblSourceDestination);
            this.groupBoxSourceDestination.Location = new System.Drawing.Point(26, 17);
            this.groupBoxSourceDestination.Name = "groupBoxSourceDestination";
            this.groupBoxSourceDestination.Size = new System.Drawing.Size(287, 94);
            this.groupBoxSourceDestination.TabIndex = 0;
            this.groupBoxSourceDestination.TabStop = false;
            this.groupBoxSourceDestination.Text = "Source Destination";
            // 
            // lblSourceDestination
            // 
            this.lblSourceDestination.AutoSize = true;
            this.lblSourceDestination.Location = new System.Drawing.Point(15, 25);
            this.lblSourceDestination.Name = "lblSourceDestination";
            this.lblSourceDestination.Size = new System.Drawing.Size(104, 13);
            this.lblSourceDestination.TabIndex = 0;
            this.lblSourceDestination.Text = "lblSourceDestination";
            // 
            // btnSourceDestination
            // 
            this.btnSourceDestination.Location = new System.Drawing.Point(18, 51);
            this.btnSourceDestination.Name = "btnSourceDestination";
            this.btnSourceDestination.Size = new System.Drawing.Size(119, 25);
            this.btnSourceDestination.TabIndex = 2;
            this.btnSourceDestination.Text = "&Source Destination";
            this.btnSourceDestination.UseVisualStyleBackColor = true;
            this.btnSourceDestination.Click += new System.EventHandler(this.btnSourceDestination_Click);
            // 
            // groupBoxTargetDestionation
            // 
            this.groupBoxTargetDestionation.Controls.Add(this.btnTargetDestination);
            this.groupBoxTargetDestionation.Controls.Add(this.lblTargetDestination);
            this.groupBoxTargetDestionation.Location = new System.Drawing.Point(340, 17);
            this.groupBoxTargetDestionation.Name = "groupBoxTargetDestionation";
            this.groupBoxTargetDestionation.Size = new System.Drawing.Size(287, 94);
            this.groupBoxTargetDestionation.TabIndex = 1;
            this.groupBoxTargetDestionation.TabStop = false;
            this.groupBoxTargetDestionation.Text = "Target Destination";
            // 
            // lblTargetDestination
            // 
            this.lblTargetDestination.AutoSize = true;
            this.lblTargetDestination.Location = new System.Drawing.Point(12, 26);
            this.lblTargetDestination.Name = "lblTargetDestination";
            this.lblTargetDestination.Size = new System.Drawing.Size(101, 13);
            this.lblTargetDestination.TabIndex = 1;
            this.lblTargetDestination.Text = "lblTargetDestination";
            // 
            // btnTargetDestination
            // 
            this.btnTargetDestination.Enabled = false;
            this.btnTargetDestination.Location = new System.Drawing.Point(14, 51);
            this.btnTargetDestination.Name = "btnTargetDestination";
            this.btnTargetDestination.Size = new System.Drawing.Size(119, 25);
            this.btnTargetDestination.TabIndex = 3;
            this.btnTargetDestination.Text = "&Target Destination";
            this.btnTargetDestination.UseVisualStyleBackColor = true;
            this.btnTargetDestination.Click += new System.EventHandler(this.btnTargetDestination_Click);
            // 
            // lblProgress
            // 
            this.lblProgress.AutoSize = true;
            this.lblProgress.Location = new System.Drawing.Point(31, 160);
            this.lblProgress.Name = "lblProgress";
            this.lblProgress.Size = new System.Drawing.Size(0, 13);
            this.lblProgress.TabIndex = 2;
            // 
            // btnBackup
            // 
            this.btnBackup.Location = new System.Drawing.Point(507, 117);
            this.btnBackup.Name = "btnBackup";
            this.btnBackup.Size = new System.Drawing.Size(120, 29);
            this.btnBackup.TabIndex = 3;
            this.btnBackup.Text = "&Backup";
            this.btnBackup.UseVisualStyleBackColor = true;
            this.btnBackup.Click += new System.EventHandler(this.btnBackup_Click);
            // 
            // progressBarBackup
            // 
            this.progressBarBackup.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.progressBarBackup.Location = new System.Drawing.Point(0, 194);
            this.progressBarBackup.Name = "progressBarBackup";
            this.progressBarBackup.Size = new System.Drawing.Size(650, 22);
            this.progressBarBackup.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.progressBarBackup.TabIndex = 4;
            // 
            // timerBackup
            // 
            this.timerBackup.Enabled = true;
            this.timerBackup.Interval = 1000;
            this.timerBackup.Tick += new System.EventHandler(this.timerBackup_Tick);
            // 
            // BackupMainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(650, 216);
            this.Controls.Add(this.progressBarBackup);
            this.Controls.Add(this.btnBackup);
            this.Controls.Add(this.lblProgress);
            this.Controls.Add(this.groupBoxTargetDestionation);
            this.Controls.Add(this.groupBoxSourceDestination);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "BackupMainForm";
            this.Text = "BackupMainForm";
            this.groupBoxSourceDestination.ResumeLayout(false);
            this.groupBoxSourceDestination.PerformLayout();
            this.groupBoxTargetDestionation.ResumeLayout(false);
            this.groupBoxTargetDestionation.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxSourceDestination;
        private System.Windows.Forms.Button btnSourceDestination;
        private System.Windows.Forms.Label lblSourceDestination;
        private System.Windows.Forms.GroupBox groupBoxTargetDestionation;
        private System.Windows.Forms.Button btnTargetDestination;
        private System.Windows.Forms.Label lblTargetDestination;
        private System.Windows.Forms.Label lblProgress;
        private System.Windows.Forms.Button btnBackup;
        private System.Windows.Forms.ProgressBar progressBarBackup;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialogSourceDestination;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialogTargetDestination;
        private System.Windows.Forms.Timer timerBackup;
    }
}