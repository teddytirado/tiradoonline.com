﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using clsFileIO = System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ClassLibraryNameSpace;
using Microsoft.Win32;
using System.Data.Sql;
using System.Data.SqlClient;

namespace BackupNameSpace
{
    public partial class BackupMainForm : Form
    {
        ClassLibraryFileIO objFileIO = new ClassLibraryFileIO();
        ClassLibraryRegistry objRegistry = new ClassLibraryRegistry();
        string RegistryBackupFolder = string.Empty;
        int totalRecords = 0;
        bool BackupRunning = false;

        public BackupMainForm()
        {
            InitializeComponent();
            RegistryBackupFolder = objRegistry.registryFolder + @"\Backup";

            lblSourceDestination.Text = (string)Registry.GetValue(RegistryBackupFolder, "SourceDestination", "");
            lblTargetDestination.Text = (string)Registry.GetValue(RegistryBackupFolder, "TargetDestination", "");


        }

        private void btnSourceDestination_Click(object sender, EventArgs e)
        {
            DialogResult result = folderBrowserDialogSourceDestination.ShowDialog();
            if (result == DialogResult.OK)
            {
                lblSourceDestination.Text = folderBrowserDialogSourceDestination.SelectedPath;
                btnTargetDestination.Enabled = true;
            }
        }

        private void btnTargetDestination_Click(object sender, EventArgs e)
        {
            DialogResult result = folderBrowserDialogTargetDestination.ShowDialog();
            if (result == DialogResult.OK)
            {
                lblTargetDestination.Text = folderBrowserDialogTargetDestination.SelectedPath;
            }
        }

        private void btnBackup_Click(object sender, EventArgs e)
        {
            BackupRunning = true;
            btnBackup.Enabled = false;
            btnSourceDestination.Enabled = false;
            btnTargetDestination.Enabled = false;
            string SourceDestination = lblSourceDestination.Text;
            string TargetDestination = lblTargetDestination.Text;

            Registry.SetValue(RegistryBackupFolder, "SourceDestination", SourceDestination);
            Registry.SetValue(RegistryBackupFolder, "TargetDestination", TargetDestination);

            DataTable objDataTable = new DataTable();
            objDataTable.Columns.Add("FileName", typeof(string));
            totalRecords = objFileIO.GetDirectoryListCount(SourceDestination, ref objDataTable);
            objDataTable.Clear();
            objFileIO.GetDirectoryList(SourceDestination, ref objDataTable);

            progressBarBackup.Minimum = 1;
            progressBarBackup.Value = 1;
            progressBarBackup.Maximum = totalRecords;

            string error_string = string.Empty;

            for (int x = 0; x < objDataTable.Rows.Count; x++)
            {
                string strFileName = clsFileIO.Path.GetFileName((string)objDataTable.Rows[x][0]);
                string SourceFileName = SourceDestination + @"\" + strFileName;
                string TargetFileName = TargetDestination + @"\" + strFileName;
                try
                {
                    string label = "Copying " + SourceFileName + "....";
                    lblProgress.Text = label;
                    Console.WriteLine(label);
                    lblProgress.Refresh();
                    if (!clsFileIO.Directory.Exists(clsFileIO.Path.GetDirectoryName(TargetFileName)))
                        clsFileIO.Directory.CreateDirectory(clsFileIO.Path.GetDirectoryName(TargetFileName));

                    clsFileIO.File.Copy(SourceFileName, TargetFileName);
                    progressBarBackup.Value += 1;
                    progressBarBackup.Refresh();
                    this.Refresh();
                }
                catch (Exception ex)
                {
                    error_string += ex.Message + Environment.NewLine;
                }
        
                    
            }

            string s = error_string;
            BackupRunning = false;
        }

        private void timerBackup_Tick(object sender, EventArgs e)
        {
            if (BackupRunning == false)
            {
                string SourceDestination = lblSourceDestination.Text;
                string TargetDestination = lblTargetDestination.Text;

                btnSourceDestination.Enabled = true;
                if (clsFileIO.Directory.Exists(SourceDestination))
                {
                    btnTargetDestination.Enabled = true;
                }
                else
                {
                    btnTargetDestination.Enabled = false;
                }


                if ((!clsFileIO.Directory.Exists(SourceDestination) || !clsFileIO.Directory.Exists(TargetDestination)) || (SourceDestination == TargetDestination))
                    btnBackup.Enabled = false;
                else
                    btnBackup.Enabled = true;
            }

        }
    }
}
