﻿using System.Runtime.Serialization;
using System.ServiceModel;

namespace WcfMathServLib
{
    [ServiceContract] //System.ServiceModel
    public interface IMath
    {
        [OperationContract]
        double Add(double i, double j);
        [OperationContract]
        double Sub(double i, double j);
        [OperationContract]
        Complex AddComplexNo(Complex i, Complex j);
        [OperationContract]
        Complex SubComplexNo(Complex i, Complex j);
    }

    // Use a data contract
    [DataContract] //using System.Runtime.Serialization
    public class Complex
    {
        private int real;
        private int imaginary;

        [DataMember]
        public int Real { get; set; }

        [DataMember]
        public int Imaginary { get; set; }
    }
}